import AuthLayout from "@/layout/authlayout";
import { useForm, FormProvider } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import { useEffect, useState } from "react";
import { NormalButton } from "@/components/common/Inputs/NormalButton";
import { ForgotFormValues } from "@/types/Admin";
import { forgotSchema } from "@/validations/auth.schema";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import { ForgotPasswordApi } from "@/redux/actions/AuthApiAct";
import Image from "next/image";
import Logo from "@/assets/Logo.svg";
import { NormalInput } from "@/components/common/Inputs/NormalInput";
import { useRouter } from "next/router";
import { LoadingScreen } from "@/components/common/Loader";

const ForgotPassword = ({ ForgotPasswordApi }: any) => {
  const [isMounted, setIsMounted] = useState(false);
  const [isSented, setIsSented] = useState(false);
  const [loadingFetch, setLoadingFetch] = useState(false);
  const router = useRouter();
  const methods = useForm<ForgotFormValues>({
    defaultValues: { emailOrMobile: "" },
    resolver: yupResolver(forgotSchema),
  });

  const onSubmit = async (data: any) => {
    let body = {
      emailOrMobile: data?.emailOrMobile,
      isForgotPassword: true,
      userType: 1,
    };
    setIsSented(true);
    setLoadingFetch(true);
    await ForgotPasswordApi(body)
      .then(({ data }: any) => {
        router.push("/auth/otp");
        setLoadingFetch(false);
      })
      .catch((e: any) => {
        console.log(e);
        setIsSented(false);
        setLoadingFetch(false);
      });
  };

  useEffect(() => {
    setIsMounted(true);
  }, []);

  if (!isMounted) return null;

  return (
    <AuthLayout>
      <div className="absolute top-0  bg-white rounded-3xl md:ml-24 lg:my-20 max-w-lg">
        {loadingFetch && <LoadingScreen />}
        <div className="flex items-center justify-center">
          <Image
            className="mx-64 mb-12 mt-16"
            src={Logo}
            width={163}
            height={46}
            alt="Admin Banner"
            priority
          />
        </div>
        <div className="px-10 md:px-20 mt-10">
          <h3 className="text-4xl font-extrabold font-Inter text-black">
            Forgot Password
          </h3>
          <FormProvider {...methods}>
            <form onSubmit={methods.handleSubmit(onSubmit)}>
              <div className="mt-10">
                <NormalInput
                  name="emailOrMobile"
                  type="text"
                  label="Email or Phone Number"
                  placeholder="Please Enter Your Email or Phone Number"
                  isrequired={true}
                  error={methods.formState.errors.emailOrMobile?.message}
                />
              </div>
              <div className="mt-10 mb-32">
                <NormalButton
                  btnType="submit"
                  isDisabled={isSented}
                  title="Send OTP"
                  inputStyles="font-[400] py-3 whitespace-nowrap w-full text-white  border justify-center font-Inter bg-primary_color"
                />
              </div>
            </form>
          </FormProvider>
        </div>
      </div>
    </AuthLayout>
  );
};

const mapDispatchToProps = (dispatch: any) => {
  return bindActionCreators({ ForgotPasswordApi }, dispatch);
};
export default connect(null, mapDispatchToProps)(ForgotPassword);

import AuthLayout from "@/layout/authlayout";
import { useForm, FormProvider } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import { useEffect, useState } from "react";
import { NormalButton } from "@/components/common/Inputs/NormalButton";
import { ResetFormValues } from "@/types/Admin";
import { resetSchema } from "@/validations/auth.schema";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import { useRouter } from "next/router";
import {
  ResetPasswordApi,
  EmployeePasswordApi,
} from "@/redux/actions/AuthApiAct";
import Image from "next/image";
import Logo from "@/assets/Logo.svg";
import { NormalInput } from "@/components/common/Inputs/NormalInput";
import { LoadingScreen } from "@/components/common/Loader";
const ResetPassword = ({ ResetPasswordApi, EmployeePasswordApi }: any) => {
  const router = useRouter();
  const { hash = "" } = router.query;
  const Hash =
    typeof window !== "undefined" ? localStorage?.getItem("resetHash") : "";
  const [isMounted, setIsMounted] = useState(false);
  const [isSented, setIsSented] = useState(false);
  const [loadingFetch, setLoadingFetch] = useState(false);
  const methods = useForm<ResetFormValues>({
    defaultValues: { password: "", confirmPassword: "" },
    resolver: yupResolver(resetSchema),
  });
  const onSubmit = async (data: any) => {
    setIsSented(true);
    setLoadingFetch(true);
    if (hash) {
      let body = {
        resetHash: hash,
        password: data?.password,
      };
      await EmployeePasswordApi(body)
        .then(({ data }: any) => {
          setLoadingFetch(false);
          router.push("/auth/login");
        })
        .catch((e: any) => {
          setIsSented(false);
          setLoadingFetch(false);
          console.log(e);
        });
    } else {
      let body = {
        resetHash: Hash,
        password: data?.password,
      };
      await ResetPasswordApi(body)
        .then(({ data }: any) => {
          setLoadingFetch(false);
          router.push("/auth/login");
        })
        .catch((e: any) => {
          setIsSented(false);
          setLoadingFetch(false);
          console.log(e);
        });
    }
  };
  useEffect(() => {
    setIsMounted(true);
  }, []);
  if (!isMounted) return null;

  return (
    <AuthLayout>
      <div className="absolute top-0  bg-white rounded-3xl md:ml-24 md:my-20 max-w-lg">
        {loadingFetch && <LoadingScreen />}
        <div className="flex items-center justify-center">
          <Image
            className="mx-64 mb-12 mt-16"
            src={Logo}
            width={163}
            height={46}
            alt="Admin Banner"
            priority
          />
        </div>
        <div className="px-10 md:px-20">
          <h3 className="text-4xl font-extrabold font-Inter text-black">
            Reset Password
          </h3>
          <FormProvider {...methods}>
            <form onSubmit={methods.handleSubmit(onSubmit)}>
              <div className="mt-10">
                <NormalInput
                  name="password"
                  type="password"
                  label="New Password"
                  placeholder="Please Enter Your New Password"
                  isrequired={true}
                  icon={true}
                  error={methods.formState.errors.password?.message}
                />
              </div>
              <div className="mt-5">
                <NormalInput
                  name="confirmPassword"
                  type="password"
                  label="Confirm Password"
                  placeholder="Please Enter Confirm Password"
                  isrequired={true}
                  icon={true}
                  error={methods.formState.errors.confirmPassword?.message}
                />
              </div>
              <div className="mt-10 mb-16">
                <NormalButton
                  btnType="submit"
                  isDisabled={isSented}
                  title="Submit"
                  inputStyles="font-[400] py-3 whitespace-nowrap w-full text-white  border justify-center font-Inter bg-primary_color"
                />
              </div>
            </form>
          </FormProvider>
        </div>
      </div>
    </AuthLayout>
  );
};

const mapDispatchToProps = (dispatch: any) => {
  return bindActionCreators(
    { ResetPasswordApi, EmployeePasswordApi },
    dispatch
  );
};

export default connect(null, mapDispatchToProps)(ResetPassword);

import AuthLayout from "@/layout/authlayout";
import { useEffect, useState } from "react";
import { NormalButton } from "@/components/common/Inputs/NormalButton";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import { ForgotPasswordApi, VerifyOTPApi } from "@/redux/actions/AuthApiAct";
import { useRouter } from "next/router";
import Image from "next/image";
import Logo from "@/assets/Logo.svg";
import { NormalOTP } from "@/components/common/Inputs/NormalOTP";
import { localStorageHelper } from "@/service/utilities";
import { LoadingScreen } from "@/components/common/Loader";

const OTP = ({ VerifyOTPApi, ForgotPasswordApi }: any) => {
  const router = useRouter();
  const userDetails = localStorageHelper("userdetails");
  const [isMounted, setIsMounted] = useState(false);
  const [isSented, setIsSented] = useState(false);
  const [mobileOTP, setMobileOTP] = useState("");
  const [errorOtp, setErrorOtp] = useState(false);
  const [loadingFetch, setLoadingFetch] = useState(false);

  const onSubmit = async (e: any) => {
    e.preventDefault();
    if (mobileOTP.length !== 4) {
      setErrorOtp(true);
      return;
    }
    setErrorOtp(false);
    setIsSented(true);
    setLoadingFetch(true);
    let body = {
      emailOrMobile: userDetails?.emailOrMobile,
      otp: mobileOTP,
      isForgotPassword: true,
      userType: 1,
    };
    await VerifyOTPApi(body)
      .then(({ data }: any) => {
        router.push("/auth/reset-password");
        setLoadingFetch(false);
      })
      .catch(() => {
        setIsSented(false);
        setLoadingFetch(false);
      });
  };

  const onResentOTP = async () => {
    setMobileOTP("");
    setErrorOtp(false);
    setIsSented(true);
    let body = {
      emailOrMobile: userDetails?.emailOrMobile,
      isForgotPassword: true,
      userType: 1,
    };
    setLoadingFetch(true);
    await ForgotPasswordApi(body)
      .then(({ data }: any) => { setLoadingFetch(false);  setIsSented(false); })
      .catch((e: any) => {
        console.log(e);
        setLoadingFetch(false);
        setIsSented(false);
      });
  };

  useEffect(() => {
    setIsMounted(true);
  }, []);
  if (!isMounted) return null;

  return (
    <AuthLayout>
      <div className="absolute top-0  bg-white rounded-3xl md:ml-24 lg:my-20 max-w-lg">
        {loadingFetch && <LoadingScreen />}
        <div className="flex items-center justify-center">
          <Image
            className="mx-64 mb-12 mt-16"
            src={Logo}
            width={163}
            height={46}
            alt="Admin Banner"
            priority
          />
        </div>
        <div className="px-10 md:px-20">
          <h3 className="text-4xl font-extrabold font-Inter text-black">
            Enter OTP
          </h3>
          <p className="mt-2 font-Inter">
            Please Enter the 4 digit OTP sent to your Email Id / Mobile : <br />
            {userDetails?.emailOrMobile}
          </p>
          <form onSubmit={onSubmit}>
            <div className="mt-12">
              <NormalOTP
                value={mobileOTP}
                HandleChangeOtp={setMobileOTP}
                error={errorOtp}
                setErrorOtp={setErrorOtp}
              />
            </div>
            <div className="mt-10">
              <button
                onClick={onResentOTP}
                type="button"
                className="text-primary_color font-Inter underline underline-offset-1 cursor-pointer"
              >
                Resend OTP?
              </button>
            </div>
            <div className="mt-10 mb-20">
              <NormalButton
                btnType="submit"
                isDisabled={isSented}
                title="Verify"
                inputStyles="font-[400] py-3 whitespace-nowrap w-full text-white  border justify-center font-Inter bg-primary_color"
              />
            </div>
          </form>
        </div>
      </div>
    </AuthLayout>
  );
};

const mapDispatchToProps = (dispatch: any) => {
  return bindActionCreators({ VerifyOTPApi, ForgotPasswordApi }, dispatch);
};
export default connect(null, mapDispatchToProps)(OTP);

import AuthLayout from "@/layout/authlayout";
import { useForm, FormProvider } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import { useEffect, useState } from "react";
import { NormalButton } from "@/components/common/Inputs/NormalButton";
import Link from "next/link";
import { NormalCheckbox } from "@/components/common/Inputs/NormalCheckbox";
import { LoginFormValues } from "@/types/Admin";
import { loginSchema } from "@/validations/auth.schema";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import { LoginApi } from "@/redux/actions/AuthApiAct";
import { useRouter } from "next/router";
import Image from "next/image";
import Logo from "@/assets/Logo.svg";
import { NormalInput } from "@/components/common/Inputs/NormalInput";
import { LoadingScreen } from "@/components/common/Loader";
import { localVariables } from "@/helpers/constants";

const Login = ({ LoginApi }: any) => {
  const router = useRouter();
  const [isMounted, setIsMounted] = useState(false);
  const [isSent, setIsSent] = useState(false);
  const [loadingFetch, setLoadingFetch] = useState(false);
  const buildDate = process.env.NEXT_PUBLIC_BUILDDATE;
  const buildId = process.env.NEXT_PUBLIC_BUILDID;
  const methods = useForm<LoginFormValues>({
    defaultValues: { email: "", password: "", rememberMe: true },
    resolver: yupResolver(loginSchema),
  });

  useEffect(() => {
    const storedData = localStorage.getItem(localVariables.userCredentials);
    if (storedData) {
      const decodedData = Buffer.from(storedData, "base64").toString("utf-8");
      const decryptedData = JSON.parse(decodedData);
      methods.setValue("email", decryptedData.email || "");
      methods.setValue("password", decryptedData.password || "");
    }
  }, [methods]);

  const onSubmit = async (user: any) => {
    setIsSent(true);
    setLoadingFetch(true);
    let body = {
      email: user?.email,
      password: user?.password,
    };
    await LoginApi(body)
      .then((data: any) => {
        if (user?.rememberMe) {
          const encodedData = Buffer.from(JSON.stringify(user));
          const base64Data = encodedData.toString('base64');
          localStorage.setItem(localVariables.userCredentials, base64Data);
        } else {
          localStorage.removeItem(localVariables.userCredentials);
        }
        
        router.push("/dashboard/owner");
        setLoadingFetch(false);
      })
      .catch(() => {
        setIsSent(false);
        setLoadingFetch(false);
      });
  };
  useEffect(() => {
    setIsMounted(true);
  }, []);

  if (!isMounted) return null;

  return (
    <AuthLayout>
      <div className="absolute top-0  bg-white rounded-3xl md:ml-24 lg:my-20 max-w-lg">
        {loadingFetch && <LoadingScreen />}
        <div className="flex items-center justify-center">
          <Image
            className="mx-64 mb-12 mt-16"
            src={Logo}
            width={163}
            height={46}
            alt="Admin Banner"
            priority
          />
        </div>
        <div className="px-10 md:px-20">
          <h3 className="text-4xl font-extrabold font-Inter text-black">
            Login
          </h3>
          <FormProvider {...methods}>
            <form onSubmit={methods.handleSubmit(onSubmit)}>
              <div className="mt-10">
                <NormalInput
                  name="email"
                  type="email"
                  label="Email Id"
                  placeholder="Please Enter Your Email ID"
                  isrequired={true}
                  error={methods.formState.errors.email?.message}
                />
              </div>
              <div className="mt-5">
                <NormalInput
                  name="password"
                  type="password"
                  label="Password"
                  placeholder="Please Enter Your Password"
                  isrequired={true}
                  icon={true}
                  error={methods.formState.errors.password?.message}
                />
              </div>
              <div className="mt-10 flex justify-between">
                <div className="ps-6">
                  <NormalCheckbox
                    name="rememberMe"
                    label="Remember me"
                    isChecked={false}
                  />
                </div>

                <Link
                  href={"/auth/forgot-password"}
                  className="text-primary_color font-Inter underline underline-offset-1"
                >
                  Forgot password?
                </Link>
              </div>
              <div className="mt-10 mb-12">
                <NormalButton
                  btnType="submit"
                  isDisabled={isSent}
                  title="Login"
                  inputStyles="font-[400] py-2 whitespace-nowrap w-full text-white  border justify-center font-Inter bg-primary_color"
                />
              </div>
            </form>
          </FormProvider>
        </div>
        <span className="mx-4" style={{ fontSize: "smaller" }}>
          rev {buildDate}.{buildId}
        </span>
      </div>
    </AuthLayout>
  );
};

const mapDispatchToProps = (dispatch: any) => {
  return bindActionCreators({ LoginApi }, dispatch);
};
export default connect(null, mapDispatchToProps)(Login);

import MainLayout from "@/layout/mainlayout";
import ArrowLeft from "@/assets/icon/Arrow_left.svg";
import Image from "next/image";
import { useRouter } from "next/router";
import UserView from "@/components/User/View/index";

const ManageView = () => {
  const router = useRouter();
  return (
    <MainLayout>
      <div className="mx-2 mt-4">
        <div className="flex gap-4">
          <Image
            className="cursor-pointer"
            src={ArrowLeft}
            alt="arrow"
            width={25}
            height={25}
            onClick={() => router.back()}
          />
          <div className="text-primary_color text-xl font-extrabold font-Inter capitalize">
            Customer Information
          </div>
        </div>
        <div className="border-grey-line border-b my-6" />
        <div className="h-screen">
          <UserView />
        </div>
      </div>
    </MainLayout>
  );
};

export default ManageView;

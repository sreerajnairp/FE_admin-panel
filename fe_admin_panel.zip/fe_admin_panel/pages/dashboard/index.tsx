import MainLayout from "@/layout/mainlayout";
import Dashboardbarchart from "./dashboardui/dashboardbarchart";


const Dashboard = () => {
  return (
    <MainLayout>
      <h3 className="text-primary_color font-Inter capitalize flex items-center text-xl font-extrabold mb-2 mt-2">
        Dashboard
      </h3>
      <div className="grid grid-rows-1 grid-flow-col md:grid-col md:grid-flow-col gap-0 mb-5">
        <div className="rounded-lg overflow-hidden border flex items-end text-end p-3">
          <div className="rounded-2xl overflow-hidden border border-light-blue bg-light-blue p-5"></div>
          <div className="text-4xl text-blue font-extrabold ml-2">200</div>
          <div className="italic font-light text-base">Total Trucks</div>
        </div>
        <div className="rounded-lg overflow-hidden border flex items-end text-end ml-3 p-3">
          <div className="rounded-2xl overflow-hidden border border-light-pink bg-light-pink p-5"></div>
          <div className="text-4xl text-pink font-extrabold ml-2">180</div>
          <div className="italic font-light text-base">Ongoing Trucks</div>
        </div>
        <div className="rounded-lg overflow-hidden border flex items-end text-end ml-3 p-3">
          <div className="rounded-2xl overflow-hidden border border-purple bg-purple p-5"></div>
          <div className="text-4xl text-purple font-extrabold ml-2">30</div>
          <div className="italic font-light text-base ">Assigned Trucks</div>
        </div>
        <div className="rounded-lg overflow-hidden border flex items-end text-end ml-3 p-3">
          <div className="rounded-2xl overflow-hidden border border-light-green-green bg-light-green-green p-5"></div>
          <div className="text-4xl text-green-green font-extrabold ml-2">
            50
          </div>
          <div className="italic font-light text-base">UnAssigned Trucks</div>
        </div>
        <div className="rounded-lg overflow-hidden border flex items-end text-end ml-3 p-3">
          <div className="rounded-2xl overflow-hidden border border-light-green-green bg-light-green-green p-5"></div>
          <div className="text-4xl text-green-green font-extrabold ml-2">
            50
          </div>
          <div className="italic font-light text-base">InActive Trucks</div>
        </div>
      </div>
      <div className="flex justify-between">
        <div>
          <button className="border px-10 py-3">Truck</button>
          <button className="border px-10 py-3">Vendor</button>
          <button className="border px-10 py-3">Customer</button>
        </div>
        <div>
          {/* <NormalSelect
              options={statusOptions}
              placeholder="Please Select City / Town"
              label="City / Town"
              name="city"
              isrequired={true}
              error={methods.formState.errors.city?.message}
            /> */}
        </div>
      </div>
      <div className="flex">
        <Dashboardbarchart />
        <div className="mt-5 ml-5">
          <div className="flex">
            <div className="rounded-lg overflow-hidden border border-pink px-4 w-64">
              <div className="flex justify-between my-4">
                <div>
                  <div className="font-bold text-2xl text-text-color">
                    Total Sales
                  </div>
                  <div className="italic font-light text-base">Gross Sales</div>
                </div>
                <div className="rounded-2xl overflow-hidden border border-light-blue bg-light-blue p-5" />
              </div>
              <div className="font-bold text-6xl ml-2 text-text-number">
                100.00
              </div>
            </div>
            <div className="rounded-lg overflow-hidden border border-pink px-4 ml-5 w-64">
              <div className="flex justify-between my-4">
                <div>
                  <div className="font-bold text-2xl text-text-color">
                    Total Bookings
                  </div>
                  <div className="italic font-light text-base">
                    Transaction quantity
                  </div>
                </div>
                <div className="rounded-2xl overflow-hidden border border-light-blue bg-light-blue p-5" />
              </div>
              <div className="font-bold text-6xl ml-2 text-text-number mb-8">
                00
              </div>
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
};

export default Dashboard;

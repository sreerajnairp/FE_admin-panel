import { TitleCard } from "@/components/common/TitleCard";
import MainLayout from "@/layout/mainlayout";
import { useRouter } from "next/router";
import { useEffect, useState, useCallback } from "react";
import TableWrapper from "@/components/common/TableWrapper";
import Pagination from "@/components/common/Pagination";
import trash from "@/assets/icon/trash.svg";
import view from "@/assets/icon/view.svg";
import edit from "@/assets/icon/edit.svg";
import Image from "next/image";
import { PageMeta } from "@/types/common";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import {
  getTruckListApi,
  TruckUpdateStatusApi,
  TruckDeleteApi,
} from "@/redux/actions/TruckApiAct";
import { truckTableHeader } from "@/helpers/constants";
import { DeleteModal } from "@/components/common/DeleteModal";
import { LoadingScreen } from "@/components/common/Loader";

const Truck = ({
  getTruckListApi,
  TruckUpdateStatusApi,
  TruckDeleteApi,
}: any) => {
  const router = useRouter();
  const [deleteModal, setDeleteModal] = useState(false);
  const [userData, setUserData] = useState([]);
  const [pageMeta, setPageMeta] = useState<PageMeta>();
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [page, setPage] = useState(1);
  const [id, setId] = useState("");
  const [searchValue, setSearchValue] = useState("");
  const [loadingFetch, setLoadingFetch] = useState(true);

  const getAllUserApiFunc = useCallback(
    (search: string = "") => {
      let query = {
        page: search ? 1 : page,
        search,
        size: rowsPerPage,
      };
      getTruckListApi(query, "Sidebar screen")
        .then(({ data }: any) => {
          setUserData(data.list);
          setPageMeta(data.pageMeta);
          setLoadingFetch(false);
        })
        .catch((e: any) => {
          console.log(e);
        });
    },
    [page, rowsPerPage]
  );

  useEffect(() => {
    getAllUserApiFunc();
  }, [page, rowsPerPage]);

  const handleOpen = (id: string) => {
    setId(id);
    setDeleteModal(true);
  };

  const StatusUpdate = (status: boolean, id: string) => {
    let body = {
      id,
      status: status ? 1 : 0,
    };
    setLoadingFetch(true);
    TruckUpdateStatusApi(body)
      .then(({ data }: any) => {
        getAllUserApiFunc();
      })
      .catch((e: any) => {
        console.log(e);
        setLoadingFetch(false);
      });
  };

  const handleDeleteModalSumbit = () => {
    let body = {
      id: [id],
    };
    setLoadingFetch(true);
    TruckDeleteApi(body)
      .then(({ data }: any) => {
        getAllUserApiFunc();
        setDeleteModal(false);
      })
      .catch((e: any) => {
        console.log(e);
        setLoadingFetch(false);
      });
  };

  const handleSearch = () => {
    if (searchValue.length > 0) {
      setLoadingFetch(true);
      getAllUserApiFunc(searchValue);
    }
  };

  const handleEmptySearch = () => {
    setSearchValue("");
    setLoadingFetch(true);
    getAllUserApiFunc("");
  };

  return (
    <MainLayout>
      <div className="relative z-0 overflow-x-auto my-3">
        {loadingFetch && <LoadingScreen />}
        <TitleCard
          title="manage truck"
          searchText="Search by Name,Company,Reg.No,Model,Type,Capacity or Ph.No..."
          placeholder="Filter by"
          buttonText="add truck"
          handleClick={() => router.push("/dashboard/truck/add")}
          value={searchValue}
          onChange={({
            target: { value },
          }: React.ChangeEvent<HTMLInputElement>) =>
            value?.length === 0 ? handleEmptySearch() : setSearchValue(value)
          }
          onButtonClick={() => handleSearch()}
          onSearchClear={handleEmptySearch}
        />
        <TableWrapper
          headers={truckTableHeader}
          listData={userData}
          isStatus={true}
          isAction={true}
        >
          {userData?.length !== 0 ? (
            userData?.map((user: any, index: number) => {
              return (
                <tr
                  key={user.id}
                  className="bg-white border-b  hover:bg-gray-50"
                >
                  <td className="px-4 py-3">
                    <p className="w-28 break-all font-xl font-Inter font-normal text-grey">
                      {user?.ownerFirstName || "N/A"}{" "}
                      {user?.ownerLastName || "N/A"}
                    </p>
                  </td>
                  <td className="px-6 py-3">
                    <p className="w-32 break-all font-xl font-Inter font-normal text-grey">
                      {user?.companyName || "N/A"}
                    </p>
                  </td>
                  <td className="px-4 py-3">
                    <p className=" font-xl font-Inter font-normal text-grey whitespace-nowrap">
                      {user?.mobile || "N/A"}
                    </p>
                  </td>
                  <td className="px-6 py-3">
                    <p className=" font-xl font-Inter font-normal text-grey whitespace-nowrap">
                      {user?.registrationNumber || "N/A"}
                    </p>
                  </td>
                  <td className="px-4 py-3">
                    <p className=" font-xl font-Inter font-normal text-grey whitespace-nowrap">
                      {user?.vehicleModelName || "N/A"}
                    </p>
                  </td>
                  <td className="px-4 py-3">
                    <p className="w-24 font-xl font-Inter font-normal text-grey">
                      {user?.vehicleTypeName || "N/A"}
                    </p>
                  </td>
                  <td className="px-6 py-3">
                    <p className=" font-xl font-Inter font-normal text-grey whitespace-nowrap">
                      {user?.vehicleCapacityName || "N/A"}
                    </p>
                  </td>
                  <td className="px-4 py-4">
                    <label
                      className="relative inline-flex items-center cursor-pointer"
                      htmlFor={user?.id}
                    >
                      <input
                        id={user?.id}
                        type="checkbox"
                        name="checkbox"
                        checked={user?.status}
                        onChange={() => StatusUpdate(!user?.status, user?.id)}
                        className="sr-only peer"
                      />
                      <p className="hidden">check</p>
                      <div
                        className="w-11 h-6 flex items-center bg-gray-300 rounded-full peer peer-checked:after:translate-x-full
                        after:absolute after:left-0 peer-checked:after:-left-1 after:bg-gray-300 peer-checked:after:border-white
                        peer-checked:after:border-8 peer-checked:after:bg-green after:border-gray-300 after:rounded-full after:h-7
                        after:w-7 after:transition-all peer-checked:bg-green"
                      />
                      <span className="ms-3 text-sm font-medium text-gray-900 dark:text-gray-300"></span>
                    </label>
                  </td>
                  <td className="p-1">
                    <div className="flex justify-between gap-1">
                      <div className="group flex relative">
                        <button
                          onClick={() =>
                            router.push(`/dashboard/truck/view?_id=${user?.id}`)
                          }
                          className="rounded-full bg-light-grey p-1"
                        >
                          <Image src={view} alt="view" />
                        </button>
                        <div
                          className="group-hover:opacity-100 transition-opacity bg-light-grey px-2  text-sm text-gray-black rounded-md 
                          absolute left-1/2 -translate-x-1/2 translate-y-full opacity-0 m-4 mx-auto"
                        >
                          View
                        </div>
                      </div>
                      <div className="group flex relative">
                        <button
                          onClick={() =>
                            router.push(`/dashboard/truck/edit?_id=${user?.id}`)
                          }
                          className="rounded-full bg-light-grey p-1"
                        >
                          <Image src={edit} alt="edit" />
                        </button>
                        <div
                          className="group-hover:opacity-100 transition-opacity bg-light-grey px-2  text-sm text-gray-black rounded-md 
                          absolute left-1/2 -translate-x-1/2 translate-y-full opacity-0 m-4 mx-auto"
                        >
                          Edit
                        </div>
                      </div>
                      <div className="group flex relative">
                        <button
                          onClick={() => handleOpen(user?.id)}
                          className="rounded-full bg-light-grey p-1"
                        >
                          <Image src={trash} alt="trash" />
                        </button>
                        <div
                          className="group-hover:opacity-100 transition-opacity bg-light-grey px-2  text-sm text-gray-black rounded-md 
                          absolute left-1/2 -translate-x-1/2 translate-y-full opacity-0 m-4 mx-auto"
                        >
                          Delete
                        </div>
                      </div>
                    </div>
                  </td>
                </tr>
              );
            })
          ) : (
            <tr className="text-center">
              <td
                colSpan={12}
                className="font-Inter font-normal px-4 py-3 font-lg text-center"
              >
                No records found !!!
              </td>
            </tr>
          )}
        </TableWrapper>
        {userData?.length !== 0 && (
          <Pagination
            pageMeta={pageMeta}
            page={page}
            rowsPerPage={rowsPerPage}
            handlePageChange={({ value }: any) => setPage(value)}
            handleSizeChange={({ value }: any) => setRowsPerPage(value)}
            handleNextPage={() => {
              pageMeta?.totalPages &&
                (pageMeta?.totalPages > page
                  ? setPage(page + 1)
                  : setPage(pageMeta?.totalPages));
            }}
            handlePrevPage={() => {
              setPage(page > 1 ? page - 1 : 1);
            }}
          />
        )}
        {deleteModal === true && (
          <DeleteModal
            title="Are you Sure?"
            success="Are you sure you want to delete the truck ?"
            handleModalClose={() => {
              setDeleteModal(false);
            }}
            handleModalSubmit={handleDeleteModalSumbit}
          />
        )}
      </div>
    </MainLayout>
  );
};

const mapDispatchToProps = (dispatch: any) => {
  return bindActionCreators(
    { getTruckListApi, TruckUpdateStatusApi, TruckDeleteApi },
    dispatch
  );
};
export default connect(null, mapDispatchToProps)(Truck);

import { TitleCard } from "@/components/common/TitleCard";
import MainLayout from "@/layout/mainlayout";
import { useRouter } from "next/router";
import { useEffect, useState, useCallback } from "react";
import { DeleteModal } from "@/components/common/DeleteModal";
import TableWrapper from "@/components/common/TableWrapper";
import Pagination from "@/components/common/Pagination";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import { PageMeta } from "@/types/common";
import { driverTableHeader } from "@/helpers/constants";
import trash from "@/assets/icon/trash.svg";
import view from "@/assets/icon/view.svg";
import edit from "@/assets/icon/edit.svg";
import Image from "next/image";
import {
  DriverDeleteApi,
  DriverUpdateStatusApi,
  getDriverListApi,
} from "@/redux/actions/DriverApiAct";
import moment from "moment";
import { LoadingScreen } from "@/components/common/Loader";

const Driver = ({
  getDriverListApi,
  DriverDeleteApi,
  DriverUpdateStatusApi,
}: any) => {
  const [deleteModal, setDeleteModal] = useState(false);
  const router = useRouter();
  const [driverData, setDriverData] = useState([]);
  const [pageMeta, setPageMeta] = useState<PageMeta>();
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [page, setPage] = useState(1);
  const [id, setId] = useState("");
  const [searchValue, setSearchValue] = useState("");
  const [loadingFetch, setLoadingFetch] = useState(true);

  useEffect(() => {
    getAllDriverApiFunc();
  }, [page, rowsPerPage]);

  const getAllDriverApiFunc = useCallback(
    (search: string = "") => {
      let query = {
        page: search ? 1 : page,
        search,
        size: rowsPerPage,
      };
      getDriverListApi(query)
        .then(({ data }: any) => {
          setDriverData(data.list);
          setPageMeta(data.pageMeta);
          setLoadingFetch(false);
        })
        .catch((e: any) => {
          console.log(e);
        });
    },
    [page, rowsPerPage]
  );

  const handleOpen = (id: string) => {
    setId(id);
    setDeleteModal(true);
  };

  const StatusUpdate = (status: boolean, id: string) => {
    let body = {
      id,
      status: status ? 1 : 0,
    };
    setLoadingFetch(true);
    DriverUpdateStatusApi(body)
      .then(({ data }: any) => {
        getAllDriverApiFunc();
      })
      .catch((e: any) => {
        console.log(e);
        setLoadingFetch(false);
      });
  };

  const handleDeleteModalSumbit = () => {
    let body = {
      id: [id],
    };
    setLoadingFetch(true);
    DriverDeleteApi(body)
      .then(({ data }: any) => {
        getAllDriverApiFunc();
        setDeleteModal(false);
      })
      .catch((e: any) => {
        console.log(e);
        setLoadingFetch(false);
      });
  };

  const handleSearch = () => {
    if (searchValue.length > 0) {
      setLoadingFetch(true);
      getAllDriverApiFunc(searchValue);
    }
  };

  const handleEmptySearch = () => {
    setSearchValue("");
    setLoadingFetch(true);
    getAllDriverApiFunc("");
  };

  return (
    <MainLayout>
      <div className="relative z-0 overflow-x-auto my-3">
        {loadingFetch && <LoadingScreen />}
        <TitleCard
          title="manage driver"
          searchText="Search by Name,License No,Ph.No or Location..."
          placeholder="Filter by"
          buttonText="add driver"
          handleClick={() => router.push("/dashboard/driver/add")}
          value={searchValue}
          onChange={({
            target: { value },
          }: React.ChangeEvent<HTMLInputElement>) =>
            value?.length === 0 ? handleEmptySearch() : setSearchValue(value)
          }
          onButtonClick={() => handleSearch()}
          onSearchClear={handleEmptySearch}
        />
        <TableWrapper
          headers={driverTableHeader}
          listData={driverData}
          isStatus={true}
          isAction={true}
        >
          {driverData?.length !== 0 ? (
            driverData?.map((driver: any, index: number) => {
              return (
                <tr
                  key={driver?.id}
                  className="bg-white border-b  hover:bg-gray-50"
                >
                  <td className="px-4 py-3">
                    <p className="w-32 break-all font-xl font-Inter font-normal text-grey">
                      {driver?.fName || "-"}
                      {""} {driver?.lName || "-"}
                    </p>
                  </td>
                  <td className="px-4 py-3">
                    <p className=" font-xl font-Inter font-normal text-grey whitespace-nowrap">
                      {driver?.mobile || "-"}
                    </p>
                  </td>
                  <td className="px-4 py-3">
                    <p className=" font-xl font-Inter font-normal text-grey whitespace-nowrap capitalize">
                      {driver?.licenseNumber || "-"}
                    </p>
                  </td>
                  <td className="px-4 py-3">
                    <p className=" font-xl font-Inter font-normal text-grey inline-block">
                      {moment(driver?.licenseExpiry).format("YYYY-MM-DD") ||
                        "-"}
                    </p>
                  </td>
                  <td className="px-4 py-3">
                    <p className="w-32 break-all font-xl font-Inter font-normal text-grey inline-block capitalize">
                      {driver?.cityName || "-"}
                    </p>
                  </td>
                  <td className="px-4 py-3">
                    <p className="w-32 break-all font-xl font-Inter font-normal text-grey">
                      {driver?.ownerFirstName || "-"}{" "}
                      {driver?.ownerLastName || "-"}
                    </p>
                  </td>
                  <td className="px-4 py-3">
                    <p className="w-32 break-all font-xl font-Inter font-normal text-grey">
                      {driver?.companyName || "-"}
                    </p>
                  </td>
                  <td className="px-4 py-4">
                    <label
                      className="relative inline-flex items-center cursor-pointer"
                      htmlFor={driver?.id}
                    >
                      <input
                        id={driver?.id}
                        type="checkbox"
                        name="checkbox"
                        checked={driver?.status}
                        onChange={() =>
                          StatusUpdate(!driver?.status, driver?.id)
                        }
                        className="sr-only peer"
                      />
                      <p className="hidden">check</p>
                      <div
                        className="w-11 h-6 flex items-center bg-gray-300 rounded-full peer peer-checked:after:translate-x-full
                        after:absolute after:left-0 peer-checked:after:-left-1 after:bg-gray-300 peer-checked:after:border-white
                        peer-checked:after:border-8 peer-checked:after:bg-green after:border-gray-300 after:rounded-full after:h-7
                        after:w-7 after:transition-all peer-checked:bg-green"
                      />
                      <span className="ms-3 text-sm font-medium text-gray-900 dark:text-gray-300"></span>
                    </label>
                  </td>
                  <td className="p-1">
                    <div className="flex justify-between gap-1">
                      <div className="group flex relative">
                        <button
                          onClick={() =>
                            router.push(
                              `/dashboard/driver/view?_id=${driver?.id}`
                            )
                          }
                          className="rounded-full bg-light-grey"
                        >
                          <Image src={view} alt="view" />
                        </button>
                        <div
                          className="group-hover:opacity-100 transition-opacity bg-light-grey px-2  text-sm text-gray-black rounded-md 
                          absolute left-1/2 -translate-x-1/2 translate-y-full opacity-0 m-4 mx-auto"
                        >
                          View
                        </div>
                      </div>
                      <div className="group flex relative">
                        <button
                          onClick={() =>
                            router.push(
                              `/dashboard/driver/edit?_id=${driver?.id}`
                            )
                          }
                          className="rounded-full bg-light-grey"
                        >
                          <Image src={edit} alt="edit" />
                        </button>
                        <div
                          className="group-hover:opacity-100 transition-opacity bg-light-grey px-2  text-sm text-gray-black rounded-md 
                          absolute left-1/2 -translate-x-1/2 translate-y-full opacity-0 m-4 mx-auto"
                        >
                          Edit
                        </div>
                      </div>
                      <div className="group flex relative">
                        <button
                          onClick={() => handleOpen(driver?.id)}
                          className="rounded-full bg-light-grey"
                        >
                          <Image src={trash} alt="trash" />
                        </button>
                        <div
                          className="group-hover:opacity-100 transition-opacity bg-light-grey px-2  text-sm text-gray-black rounded-md 
                          absolute left-1/2 -translate-x-1/2 translate-y-full opacity-0 m-4 mx-auto"
                        >
                          Delete
                        </div>
                      </div>
                    </div>
                  </td>
                </tr>
              );
            })
          ) : (
            <tr className="text-center">
              <td
                colSpan={10}
                className="font-Inter font-normal px-4 py-3 font-lg text-center"
              >
                No records found !!!
              </td>
            </tr>
          )}
        </TableWrapper>
        {driverData.length > 0 && (
          <Pagination
            pageMeta={pageMeta}
            page={page}
            rowsPerPage={rowsPerPage}
            handlePageChange={({ value }: any) => setPage(value)}
            handleSizeChange={({ value }: any) => setRowsPerPage(value)}
            handleNextPage={() => {
              pageMeta?.totalPages &&
                (pageMeta?.totalPages > page
                  ? setPage(page + 1)
                  : setPage(pageMeta?.totalPages));
            }}
            handlePrevPage={() => {
              setPage(page > 1 ? page - 1 : 1);
            }}
          />
        )}
        {deleteModal === true && (
          <DeleteModal
            title="Are you Sure?"
            success="Are you sure you want to delete the driver ?"
            handleModalClose={() => {
              setDeleteModal(false);
            }}
            handleModalSubmit={handleDeleteModalSumbit}
          />
        )}
      </div>
    </MainLayout>
  );
};

const mapDispatchToProps = (dispatch: any) => {
  return bindActionCreators(
    { getDriverListApi, DriverDeleteApi, DriverUpdateStatusApi },
    dispatch
  );
};
export default connect(null, mapDispatchToProps)(Driver);

import MainLayout from "@/layout/mainlayout";
import ArrowLeft from "@/assets/icon/Arrow_left.svg";
import Image from "next/image";
import { useRouter } from "next/router";
import CityLocation from "@/components/Location/City/index";
import StateLocation from "@/components/Location/State/index";
import { useState } from "react";

const ManageLocation = () => {
  const router = useRouter();
  const [addState, setAddState] = useState(false);
  const [addCity, setAddCity] = useState(false);
  return (
    <MainLayout>
      <div className="mx-2 mt-4">
        <div className="flex justify-between">
          <div className="text-primary_color text-xl font-extrabold font-Inter capitalize flex items-center gap-4">
            {router.query.slug == "city" && (
              <Image
                className="cursor-pointer"
                src={ArrowLeft}
                alt="arrow"
                width={25}
                height={25}
                onClick={() => {
                  router.back();
                }}
              />
            )}
            {router.query.slug} Manage Location
          </div>
          <button
            className="bg-primary_color text-white border rounded-md px-10 font-xl py-2 capitalize font-Inter"
            onClick={() => {
              router.query.slug == "city"
                ? setAddCity(true)
                : setAddState(true);
            }}
          >
            Add {router.query.slug}
          </button>
        </div>
        <div className="my-6" />
        {router.query.slug == "city" ? (
          <CityLocation
            addCity={addCity}
            setAddCity={setAddCity}
          />
        ) : (
          <StateLocation
            setAddState={setAddState}
            addState={addState}
          />
        )}
      </div>
    </MainLayout>
  );
};

export default ManageLocation;

import {
  BarChart,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";

const DashboardbarChart = () => {
  const data = [
    { name: "A", value: 20, lineValue: 25 },
    { name: "B", value: 30, lineValue: 28 },
    { name: "C", value: 15, lineValue: 18 },
    { name: "D", value: 25, lineValue: 30 },
  ];

  return (
    <div
      className="rounded overflow-hidden border border-pink mt-5"
      style={{ width: "650px", height: "380px" }}
    >
      <ResponsiveContainer>
        <BarChart data={data}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="name" />
          <YAxis />
          <Tooltip />
          <Legend />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};

const mapDispatchToProps = (dispatch: any) => {
  return bindActionCreators({}, dispatch);
};

export default connect(null, mapDispatchToProps)(DashboardbarChart);

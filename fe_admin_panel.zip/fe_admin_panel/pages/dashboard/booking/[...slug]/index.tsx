import MainLayout from "@/layout/mainlayout";
import { useRouter } from "next/router";
import BookingRequest from "@/components/Booking/request/index";
import BookingApproval from "@/components/Booking/approval/index";
import BookingCurrent from "@/components/Booking/current/index";
import BookingCancelled from "@/components/Booking/cancelled/index";
import BookingHistory from "@/components/Booking/history/index";
import BookingLead from "@/components/Booking/lead/index";
import BookingInProcess from "@/components/Booking/inprocess/index";

const BookingAdd = () => {
  const router = useRouter();
  const { slug = "" } = router.query;
  return (
    <MainLayout>
      <div className="relative z-0 overflow-x-auto my-3">
        <h3 className="text-primary_color font-Inter capitalize flex items-center text-xl font-extrabold mb-8">
          Manage Booking
        </h3>
        <div className="border-grey-line border-b my-3" />
        <div className="border-b border-grey-line mb-5">
          <ul className="flex flex-wrap">
            <li className="">
              <button
                onClick={() => router.push("/dashboard/booking/request")}
                className={`${slug[0] === "request" &&
                  "text-primary_color border-b-4 border-primary_color rounded-t-lg active "
                  } inline-block p-4 rounded-t-lg font-xl font-Inter font-normal text-grey`}
              >
                Pending Request
              </button>
            </li>
            <li className="me-2">
              <button
                onClick={() => router.push("/dashboard/booking/approved")}
                className={`${slug[0] === "approved" &&
                  "text-primary_color border-b-4 border-primary_color rounded-t-lg active "
                  } inline-block p-4 rounded-t-lg font-xl font-Inter font-normal text-grey`}
              >
                Approved Booking
              </button>
            </li>
            <li className="me-2">
              <button
                onClick={() => router.push("/dashboard/booking/inprocess")}
                className={`${slug[0] === "inprocess" &&
                  "text-primary_color border-b-4 border-primary_color rounded-t-lg active "
                  } inline-block p-4 rounded-t-lg font-xl font-Inter font-normal text-grey`}
              >
                InProgress Booking
              </button>
            </li>
            <li className="me-2">
              <button
                onClick={() => router.push("/dashboard/booking/ongoing")}
                className={`${slug[0] === "ongoing" &&
                  "text-primary_color border-b-4 border-primary_color rounded-t-lg active "
                  } inline-block p-4 rounded-t-lg font-xl font-Inter font-normal text-grey`}
              >
                Ongoing Booking
              </button>
            </li>
            <li className="me-2">
              <button
                onClick={() => router.push("/dashboard/booking/cancelled")}
                className={`${slug[0] === "cancelled" &&
                  "text-primary_color border-b-4 border-primary_color rounded-t-lg active "
                  } inline-block p-4 rounded-t-lg font-xl font-Inter font-normal text-grey`}
              >
                Cancelled Booking
              </button>
            </li>
            <li className="me-2">
              <button
                onClick={() => router.push("/dashboard/booking/history")}
                className={`${slug[0] === "history" &&
                  "text-primary_color border-b-4 border-primary_color rounded-t-lg active "
                  } inline-block p-4 rounded-t-lg font-xl font-Inter font-normal text-grey`}
              >
                Booking History
              </button>
            </li>
            <li className="me-2">
              <button
                onClick={() => router.push("/dashboard/booking/lead")}
                className={`${slug[0] === "lead" &&
                  "text-primary_color border-b-4 border-primary_color rounded-t-lg active "
                  } inline-block p-4 rounded-t-lg font-xl font-Inter font-normal text-grey`}
              >
                Booking Leads
              </button>
            </li>
          </ul>
        </div>
        {slug[0] === "request" && <BookingRequest />}
        {slug[0] === "approved" && (
          <BookingApproval />
        )}
        {slug[0] === "inprocess" && (
          <BookingInProcess />
        )}
        {slug[0] === "ongoing" && (
          <BookingCurrent />
        )}
        {slug[0] === "cancelled" && (
          <BookingCancelled />
        )}
        {slug[0] === "history" && <BookingHistory />}
        {slug[0] === "lead" && (
          <BookingLead />
        )}
      </div>
    </MainLayout>
  );
};

export default BookingAdd;

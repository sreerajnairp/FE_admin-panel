import MainLayout from "@/layout/mainlayout";
import ArrowLeft from "@/assets/icon/Arrow_left.svg";
import Image from "next/image";
import { useRouter } from "next/router";
import CurrentView from "@/components/Booking/current/view/index";
import { getBookingById } from "@/redux/actions/BookingApiAct";
import { useState, useCallback, useEffect } from "react";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";

const BookingAdd = ({ getBookingById }: any) => {
  const router = useRouter();
  const { _id = "", slug = "" } = router.query;
  const [userData, setUserData] = useState(null);

  const getBookingDetailsByID = useCallback(async () => {
    if (_id) {
      const { data } = await getBookingById(_id);
      setUserData(data);
    }
  }, [_id]);
  useEffect(() => {
    if (_id) {
      getBookingDetailsByID();
    }
  }, [_id]);

  return (
    <MainLayout>
      <div className="mx-2 mt-4">
        <div className="flex gap-4">
          <Image
            className="cursor-pointer"
            src={ArrowLeft}
            alt="arrow"
            width={25}
            height={25}
            onClick={() => router.back()}
          />
          <div className="text-primary_color text-xl font-extrabold font-Inter capitalize">
            Order ID({(userData as any)?.orderId})
          </div>
        </div>
        <div className="border-grey-line border-b my-6" />
        <CurrentView />
      </div>
    </MainLayout>
  );
};

const mapDispatchToProps = (dispatch: any) => {
  return bindActionCreators({ getBookingById }, dispatch);
};
export default connect(null, mapDispatchToProps)(BookingAdd);

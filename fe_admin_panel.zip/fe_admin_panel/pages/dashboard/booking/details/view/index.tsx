import MainLayout from "@/layout/mainlayout";
import ArrowLeft from "@/assets/icon/Arrow_left.svg";
import Image from "next/image";
import { useRouter } from "next/router";
import ApprovalView from "@/components/Booking/approval/view/index";

const BookingDetailsView = () => {
  const router = useRouter();
  const { assign = false, cancelled = false, leadView = false } = router.query;

  return (
    <MainLayout>
      <div className="mx-2 mt-4">
        <div className="flex gap-4">
          <Image
            className="cursor-pointer"
            src={ArrowLeft}
            alt="arrow"
            width={25}
            height={25}
            onClick={() => router.back()}
          />
          <div className="text-primary_color text-xl font-extrabold font-Inter capitalize">
            Booking Information
          </div>
        </div>
        <div className="border-grey-line border-b my-6" />
          <ApprovalView
            assignView={assign}
            cancelledView={cancelled}
            leadView={leadView}
          />
      </div>
    </MainLayout>
  );
};

export default BookingDetailsView;

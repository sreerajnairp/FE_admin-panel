import MainLayout from "@/layout/mainlayout";
import { useRouter } from "next/router";
import { useEffect, useState } from "react";
import TableWrapper from "@/components/common/TableWrapper";
import Pagination from "@/components/common/Pagination";
import view from "@/assets/icon/view.svg";
import Image from "next/image";
import { PageMeta } from "@/types/common";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import {
  getOwnerListApi,
  OwnerUpdateStatusApi,
  OwnerDeleteApi,
} from "@/redux/actions/OwnerApiAct";
import { PAYMENT_STATUS, refundTableHeader } from "@/helpers/constants";
import { DeleteModal } from "@/components/common/DeleteModal";
import moment from "moment";
import { getBookingListApi } from "@/redux/actions/BookingApiAct";
import { LoadingScreen } from "@/components/common/Loader";

const Refund = ({ OwnerDeleteApi, getBookingListApi }: any) => {
  const router = useRouter();
  const [deleteModal, setDeleteModal] = useState(false);
  const [userData, setUserData] = useState([]);
  const [pageMeta, setPageMeta] = useState<PageMeta>();
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [page, setPage] = useState(1);
  const [loadingFetch, setLoadingFetch] = useState(true);

  useEffect(() => {
    getBookingListApiFunc();
  }, [page, rowsPerPage]);

  const getBookingListApiFunc = () => {
    let query = {
      page: page,
      size: rowsPerPage,
      status: 3,
    };
    getBookingListApi(query)
      .then(({ data }: any) => {
        setUserData(data.list);
        setPageMeta(data.pageMeta);
        setLoadingFetch(false);
      })
      .catch((e: any) => {
        console.log(e);
      });
  };

  const handleDeleteModalSumbit = (id: any) => {
    let body = {
      id: [id],
    };
    OwnerDeleteApi(body)
      .then(({ data }: any) => {
        setDeleteModal(false);
      })
      .catch((e: any) => {
        console.log(e);
      });
  };

  return (
    <MainLayout>
      <div className="relative z-0 overflow-x-auto my-3">
        {loadingFetch && <LoadingScreen />}
        <h3 className="text-primary_color font-Inter capitalize flex items-center text-xl font-extrabold mb-8">
          Manage Refund
        </h3>
        <TableWrapper
          headers={refundTableHeader}
          listData={userData}
          isStatus={true}
          isAction={true}
        >
          {userData?.length !== 0 ? (
            userData?.map((user: any, index: number) => {
              return (
                <tr
                  key={user?.id}
                  className="bg-white border-b  hover:bg-gray-50"
                >
                  <td className="px-4 py-3">
                    <p className="w-24 break-all font-xl font-Inter font-normal text-grey">
                      {user?.orderId || "-"}
                    </p>
                  </td>
                  <td className="px-5 py-3">
                    <p className=" font-xl font-Inter font-normal text-grey whitespace-nowrap capitalize">
                      {user?.username || "N/A"}
                    </p>
                  </td>
                  <td className="px-4 py-3">
                    <p className="font-xl font-Inter font-normal text-grey">
                      {user?.refundCreditedAt !== null
                        ? moment(user?.refundCreditedAt)
                            .utc()
                            .format("DD/MM/YYYY")
                        : "-"}
                    </p>
                  </td>
                  <td className="px-4 py-3">
                    {user.cancelledDate !== null ? (
                      <p className="font-xl font-Inter font-normal text-grey">
                        {moment(user.cancelledDate).utc().format("DD/MM/YYYY")}
                      </p>
                    ) : (
                      <p className="ms-5 font-xl font-Inter font-normal text-grey whitespace-nowrap">
                        N/A
                      </p>
                    )}
                  </td>

                  <td className="px-4 py-3">
                    <p className="ms-5 font-xl font-Inter font-normal text-grey whitespace-nowrap capitalize ">
                      {user?.cancelCredit ? user?.cancelCredit : "0"}
                    </p>
                  </td>
                  <td className="py-3 px-4">
                    <p className=" font-xl font-Inter font-normal text-grey whitespace-nowrap capitalize">
                      {user?.cancelCredit === null
                        ? "No Refund"
                        : user?.paymentStatus !== null
                        ? PAYMENT_STATUS[user?.paymentStatus]
                        : "Yet to Refund"}
                    </p>
                  </td>
                  <td className="p-1">
                    <div className="flex ms-8">
                      <button
                        onClick={() =>
                          router.push(`/dashboard/refund/view?_id=${user?.id}`)
                        }
                        className="rounded-full bg-light-grey"
                      >
                        <Image src={view} alt="view" />
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })
          ) : (
            <tr className="text-center">
              <td
                colSpan={12}
                className="font-Inter font-normal px-4 py-3 font-lg text-center"
              >
                No records found !!!
              </td>
            </tr>
          )}
        </TableWrapper>
        {userData.length > 0 && (
          <Pagination
            pageMeta={pageMeta}
            page={page}
            rowsPerPage={rowsPerPage}
            handlePageChange={({ value }: any) => setPage(value)}
            handleSizeChange={({ value }: any) => setRowsPerPage(value)}
            handleNextPage={() => {
              pageMeta?.totalPages &&
                (pageMeta?.totalPages > page
                  ? setPage(page + 1)
                  : setPage(pageMeta?.totalPages));
            }}
            handlePrevPage={() => {
              setPage(page > 1 ? page - 1 : 1);
            }}
          />
        )}
        {deleteModal === true && (
          <DeleteModal
            title="Are you Sure?"
            success="Are you sure you want to Delete the Booking ?"
            handleModalClose={() => {
              setDeleteModal(false);
            }}
            handleModalSubmit={handleDeleteModalSumbit}
          />
        )}
      </div>
    </MainLayout>
  );
};

const mapDispatchToProps = (dispatch: any) => {
  return bindActionCreators(
    {
      getOwnerListApi,
      OwnerUpdateStatusApi,
      OwnerDeleteApi,
      getBookingListApi,
    },
    dispatch
  );
};
export default connect(null, mapDispatchToProps)(Refund);

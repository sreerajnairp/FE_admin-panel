import ToasterWrapper from '@/components/common/Toaster';
import '../styles/globals.css'
import type { AppProps } from 'next/app'
import localFont from 'next/font/local';
/**
 *   Custom component/function imports
 */
import store from '@/helpers/index';
import Head from 'next/head';
import { Provider } from 'react-redux';
import ErrorBoundary from '../components/error_boundary'

const Inter = localFont({
  src: '../public/font/Inter/static/Inter-Medium.ttf', 
  variable: '--font-Inter'
})



function App({ Component, pageProps }: AppProps) {
  return (
    <Provider store={store}>
      <Head>
        <title>Velo Fleet Management</title>
      </Head>
      <main className={`${Inter.variable}`}>
        <ErrorBoundary>
        <Component {...pageProps} />
        <ToasterWrapper />
        </ErrorBoundary>
      </main>
    </Provider>
   
  )
}

export default App;
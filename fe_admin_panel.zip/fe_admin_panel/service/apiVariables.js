//auth Api
export const authApi = {
  loginApi: {
    url: "auth/adminLogin",
    method: "post",
    get api() {
      return this.url
    }
  },
  forgotApi: {
    url: "auth/login",
    method: "post",
    get api() {
      return this.url
    }
  },
  OTPApi: {
    url: "auth/verifyOtp",
    method: "post",
    get api() {
      return this.url
    }
  },
  resetApi: {
    url: "auth/resetPassword",
    method: 'post',
    token: true,
    get api() {
      return this.url
    },
  },
  employeeSetPasswordApi: {
    url: "employee/setPassword",
    method: 'post',
    token: true,
    get api() {
      return this.url
    },
  },
  logoutApi: {
    url: "auth/logout",
    method: "post",
    token: true,
    get api() {
      return this.url
    }
  },
  updateApi: {
    url: "auth/update/Profile",
    method: "put",
    id: null,
    get api() {
      return this.url + '/' + this.id;
    }
  },
};


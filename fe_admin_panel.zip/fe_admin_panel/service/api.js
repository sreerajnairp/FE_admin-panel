import { decryptData, encryptData } from "@/helpers/utils";
import {
  axiosInstance,
  cancelTokenSource,
  statusHelper,
  getServiceUrl,
} from "./utilities";
import { ENCRYPTION_KEY } from "@/config";

/**
 *  Customized axios function for api calls.
 * @returns {Promise} that contains the api data's response
 */

export const api = async function ({
  method = "get",
  api: apiURL,
  body,
  status = false,
  baseURL = "user",
  configObj = {},
  token = false,
  UploadImage = false,
}) {
  const tempConfigObj = { ...configObj };
  tempConfigObj.cancelToken = cancelTokenSource.token;
  return await new Promise((resolve, reject) => {
    if (token) {
      axiosInstance.defaults.headers.common.Authorization = `Bearer ${localStorage.getItem(
        "accessToken"
      )}`;
    }
    let payload;
    if (UploadImage) {
      payload = body;
    } else {
      payload = encryptData(body, ENCRYPTION_KEY);
    }
    axiosInstance[method](
      `${getServiceUrl(baseURL)}${apiURL}`,
      payload || "",
      tempConfigObj
    )
      .then((data) => {
        const decrypt = JSON.parse(decryptData(data.data, ENCRYPTION_KEY));
        resolve(statusHelper(status, decrypt));
      })
      .catch((error) => {
        try {
          if (error.response) {
            const decryptError = JSON.parse(
              decryptData(error.response.data, ENCRYPTION_KEY)
            );
            reject(statusHelper(status, decryptError));
          } else {
            reject(error);
          }
        } catch (err) {
          reject(err);
        }
      });
  });
};

import { generateQuery } from "@/helpers/utils";
export const BookingVariable = {
  getAllBookingApi: {
    url: "booking",
    method: "get",
    query: {
      page: 1,
      size: 9,
      search: "",
      truckId: "",
      status: 0,
    },
    token: true,
    get api() {
      return this.url + generateQuery(this.query);
    },
    set addQuery({ key, payload }) {
      this.query[key] = payload;
    },
  },
  updateBookingApi: {
    url: "booking/status",
    method: "put",
    id: null,
    token: true,
    get api() {
      return this.url + "/" + this.id;
    },
  },
  getBookingId: {
    url: "booking",
    method: "get",
    id: null,
    token: true,
    get api() {
      return this.url + "/" + this.id;
    },
  },
  assignOwner: {
    url: "booking/assignOwner",
    method: "post",
    token: true,
    get api() {
      return this.url;
    },
  },
  refundUpdate: {
    url: "booking/refund",
    method: "post",
    token: true,
    get api() {
      return this.url;
    },
  },
  leadDelete: {
    api: "booking/delete_ids",
    method: "put",
    token: true,
  },
  getServiceableOwners: {
    url: "booking/getServiceableOwners",
    method: "get",
    id: null,
    token: true,
    query: {
      page: 1,
      size: 9,
      search: "",
    },
    get api() {
      return this.url + "/" + this.id + generateQuery(this.query);
    },
    set addQuery({ key, payload }) {
      this.query[key] = payload;
    },
  },
};

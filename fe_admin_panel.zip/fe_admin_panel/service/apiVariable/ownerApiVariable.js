import { generateQuery } from "@/helpers/utils";
export const OwnerVariable = {
  getOwnerListAllApi: {
    url: "owner",
    method: "get",
    query: {
      page: 1,
      size: 9,
      search: "",
      ownerId: null,
      serviceableLocation: "",
      status: 1
    },
    token: true,
    get api() {
      return this.url + generateQuery(this.query);
    },
    set addQuery({ key, payload }) {
      this.query[key] = payload;
    },
  },
  addOwner: {
    url: "owner",
    method: "post",
    token: true,
    get api() {
      return this.url;
    },
  },
  updateOwner: {
    url: "owner",
    method: "put",
    id: null,
    token: true,
    get api() {
      return this.url + "/" + this.id;
    },
  },
  getOwnerId: {
    url: "owner",
    method: "get",
    id: null,
    token: true,
    get api() {
      return this.url + "/" + this.id;
    },
  },
  updateStatusApi: {
    api: "owner/updateStatus",
    method: "post",
    token: true,
  },
  deleteTruckApi: {
    api: "owner/bulkDelete",
    method: "post",
    token: true,
  },
};

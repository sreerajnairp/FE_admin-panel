import { generateQuery } from "@/helpers/utils";
export const DriverVariable = {
  getAllDriverApi: {
    url: "driver",
    method: "get",
    query: {
      page: 1,
      size: 9,
      search: "",
      ownerId: null,
    },
    token: true,
    get api() {
      return this.url + generateQuery(this.query);
    },
    set addQuery({ key, payload }) {
      this.query[key] = payload;
    },
  },
  deleteDriverApi: {
    api: "driver/bulkDelete",
    method: "post",
    token: true,
  },
  updateDriver: {
    url: "driver",
    method: "put",
    id: null,
    token: true,
    get api() {
      return this.url + "/" + this.id;
    },
  },
  updateStatusApi: {
    api: "driver/updateStatus",
    method: "post",
    token: true,
  },
  addDriver: {
    url: "driver",
    method: "post",
    token: true,
    get api() {
      return this.url;
    },
  },
  getDriverId: {
    url: "driver",
    method: "get",
    id: null,
    token: true,
    get api() {
      return this.url + "/" + this.id;
    },
  },
};

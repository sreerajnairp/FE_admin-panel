import { generateQuery } from "@/helpers/utils";
export const TruckVariable = {
  getTruckListAllApi: {
    url: "truck",
    method: "get",
    query: {
      page: 1,
      size: 9,
      search: "",
      ownerId: null,
    },
    token: true,
    get api() {
      return this.url + generateQuery(this.query);
    },
    set addQuery({ key, payload }) {
      this.query[key] = payload;
    },
  },
  addTruck: {
    url: "truck",
    method: "post",
    token: true,
    get api() {
      return this.url;
    },
  },
  updateTruck: {
    url: "truck",
    method: "put",
    id: null,
    token: true,
    get api() {
      return this.url + "/" + this.id;
    },
  },
  getTruckId: {
    url: "truck",
    method: "get",
    id: null,
    token: true,
    get api() {
      return this.url + "/" + this.id;
    },
  },
  updateStatusApi: {
    api: "truck/updateStatus",
    method: "post",
    token: true,
  },
  deleteTruckApi: {
    api: "truck/bulkDelete",
    method: "post",
    token: true,
  },
  getVehicleTypeApi: {
    url: "vehicleType",
    method: "get",
    get api() {
      return this.url;
    },
  },
  getVehicleTyreApi: {
    url: "common/vehicleTyre",
    method: "get",
    get api() {
      return this.url;
    },
  },
  getVehicleAxleApi: {
    url: "vehicleAxle",
    method: "get",
    get api() {
      return this.url;
    },
  },
  getVehicleLoadTypeApi: {
    url: "vehicleLoadType",
    method: "get",
    get api() {
      return this.url;
    },
  },
  getVehicleCapacityApi: {
    url: "vehicleCapacity",
    method: "get",
    get api() {
      return this.url;
    },
  },
  getVehicleSizeApi: {
    url: "vehicleSize",
    method: "get",
    get api() {
      return this.url;
    },
  },
  getVehicleModelApi: {
    url: "vehicleModel",
    method: "get",
    get api() {
      return this.url;
    },
  },
};

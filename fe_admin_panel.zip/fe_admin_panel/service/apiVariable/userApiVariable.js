import { generateQuery } from '@/helpers/utils';
export const UserVariable = {
    getAllUserApi: {
        url: "customer",
        method: "get",
        query: {
            page: 1,
            size: 9,
            search: '',
        },
        token: true,
        get api() {
            return this.url + generateQuery(this.query);
        },
        set addQuery({ key, payload }) {
            this.query[key] = payload;
        },
    },
    deleteUserApi: {
        api: "customer/bulkDelete",
        method: "post",
        token: true,
    },
    updateUser: {
        url: "customer",
        method: "put",
        id: null,
        token: true,
        get api() {
            return this.url + '/' + this.id;
        }
    },
    updateStatusApi: {
        api: "customer/updateStatus",
        method: "post",
        token: true,
    },
    addUser: {
        url: "customer",
        method: "post",
        token: true,
        get api() {
            return this.url
        }
    },
    getUserId: {
        url: "customer",
        method: "get",
        id: null,
        token: true,
        get api() {
            return this.url + '/' + this.id;
        }
    },
};
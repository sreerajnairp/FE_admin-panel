import { generateQuery } from "@/helpers/utils";

export const CommonVariable = {
  getAllCountryApi: {
    url: "common/getCountry",
    method: "get",
    get api() {
      return this.url;
    },
  },
  getAllCityApi: {
    url: "common/getCityByCountry",
    method: "get",
    // countryCode: null,
    token: true,
    get api() {
      return this.url;
    },
  },
  uploadImageApi: {
    url: "common/uploadImage",
    method: "post",
    get api() {
      return this.url;
    },
  },
  getServicableApi: {
    url: "common/getServiceableCity",
    method: "get",
    query: {
      id: null,
      cityIds: null,
    },
    token: true,
    get api() {
      return this.url + generateQuery(this.query);
    },
    set addQuery({ key, payload }) {
      this.query[key] = payload;
    },
  },
  getPermitApi: {
    url: "common/permit",
    method: "get",
    get api() {
      return this.url;
    },
  },
  getStatePermitApi: {
    url: "common/getStateByCountry",
    method: "get",
    query: {
      isGeneral: null,
      id: null,
      stateIds: null,
    },
    token: true,
    get api() {
      return this.url + generateQuery(this.query);
    },
    set addQuery({ key, payload }) {
      this.query[key] = payload;
    },
  },
  getCityByState: {
    url: "city",
    method: "get",
    stateId: null,
    token: true,
    query: {
      isGeneral: null,
      cityId: null,
    },
    get api() {
      return this.url + "/" + this.stateId + generateQuery(this.query);
    },
    set addQuery({ key, payload }) {
      this.query[key] = payload;
    },
  },
  stateUpdate: {
    url: "city/createState",
    method: "post",
    token: true,
    get api() {
      return this.url;
    },
  },
  cityAdd: {
    url: "city",
    method: "post",
    token: true,
    get api() {
      return this.url;
    },
  },
  cityUpdate: {
    url: "city/bulkUpdate",
    method: "post",
    token: true,
    get api() {
      return this.url;
    },
  },
  deleteStateApi: {
    url: "city/deleteState",
    method: "delete",
    token: true,
    stateId: null,
    get api() {
      return this.url + "/" + this.stateId;
    },
  },
  deleteCityApi: {
    url: "city",
    method: "delete",
    token: true,
    cityId: null,
    get api() {
      return this.url + "/" + this.cityId;
    },
  },
  getCityApi: {
    url: "common/getCity",
    method: "get",
    token: true,
    query: {
      id: null,
    },
    get api() {
      return this.url + generateQuery(this.query);
    },
    set addQuery({ key, payload }) {
      this.query[key] = payload;
    },
  },
};

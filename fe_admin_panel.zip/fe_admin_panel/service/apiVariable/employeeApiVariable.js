import { generateQuery } from "@/helpers/utils";
export const EmployeeVariable = {
  getEmployeeListAllApi: {
    url: "employee",
    method: "get",
    query: {
      page: 1,
      size: 9,
      search: "",
    },
    token: true,
    get api() {
      return this.url + generateQuery(this.query);
    },
    set addQuery({ key, payload }) {
      this.query[key] = payload;
    },
  },
  deleteEmployeeApi: {
    api: "employee/bulkDelete",
    method: "post",
    token: true,
  },
  updateEmployee: {
    url: "employee",
    method: "put",
    id: null,
    token: true,
    get api() {
      return this.url + "/" + this.id;
    },
  },
  updateStatusApi: {
    api: "employee/updateStatus",
    method: "post",
    token: true,
  },
  getEmployeeId: {
    url: "employee",
    method: "get",
    id: null,
    token: true,
    get api() {
      return this.url + "/" + this.id;
    },
  },
  addEmployee: {
    url: "employee",
    method: "post",
    token: true,
    get api() {
      return this.url;
    },
  },
  resendEmailEmployee: {
    url: "employee/resendEmail",
    method: "post",
    token: true,
    get api() {
      return this.url;
    },
  },
};

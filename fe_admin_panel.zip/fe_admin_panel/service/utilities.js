import axios from "axios";
import config from "../config";
import { Toast } from "./toast";
import { AccessTokenRefresh } from "@/redux/actions/AuthApiAct";
import pdf from "@/assets/icon/pdf.svg";
import { localVariables } from "@/helpers/constants";
import Image from "next/image";

export const axiosInstance = axios.create({
  headers: {
    "Content-Type": "text/plain",
  },
});

export const cancelTokenSource = axios.CancelToken.source();

axiosInstance.interceptors.request.use(
  (config) => {
    let accessToken;
    accessToken = localStorage.getItem("accessToken");
    if (accessToken) {
      config.headers.Authorization = `Bearer ${accessToken}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

axiosInstance.interceptors.response.use(
  (response) => {
    return response;
  },
  async (error) => {
    const originalRequest = error.config;

    if (
      (error.response && error.response.status === 401) ||
      (error.response.status === 403 && !originalRequest._retry)
    ) {
      originalRequest._retry = true;

      // Cancel all pending requests
      // cancelTokenSource.cancel();

      try {
        const refreshToken =
          localStorage.getItem("rememberMe") == "local"
            ? localStorage.getItem("refreshToken")
            : sessionStorage.getItem("refreshToken");
        const refreshResponse = await AccessTokenRefresh({ refreshToken });
        const newAccessToken = refreshResponse.data.data.user.accessToken;
        localStorage.getItem("rememberMe") == "local"
          ? localStorage.setItem("accessToken", newAccessToken)
          : sessionStorage.setItem("accessToken", newAccessToken);
        const newRefreshToken = refreshResponse.data.data.user.refreshToken;
        localStorage.getItem("rememberMe") == "local"
          ? localStorage.setItem("refreshToken", newRefreshToken)
          : sessionStorage.setItem("refreshToken", newRefreshToken);
        originalRequest.headers.Authorization = `Bearer ${newAccessToken}`;
        return axiosInstance(originalRequest);
      } catch (refreshError) {
        setTimeout(() => logout(), 1000);
        return Promise.reject(refreshError);
      }
    }

    return Promise.reject(error);
  }
);
export const logout = () => {
  const rememberMe = localStorage.getItem(localVariables.userCredentials);
  if (rememberMe?.length) {
    localStorage.removeItem("accessToken");
    localStorage.removeItem("permission");
    localStorage.removeItem("refreshToken");
    window.location.href = "/auth/login";
  } else {
    localStorage.clear();
    window.location.href = "/auth/login";
  }
};

export const getServiceUrl = () => {
  return config.api.baseUrl;
};

export const statusHelper = (status, data) => {
  if (data.status === 401 || data.status === 403) {
    Toast({ type: "error", message: data.statusText });
  }

  if (status) {
    return {
      status: data.status,
      ...data.data,
    };
  }
  return data;
};
export function localStorageHelper(key) {
  if (typeof window !== "undefined") {
    return JSON.parse(localStorage.getItem(key));
  }
}

export const getImageSrc = (image) => {
  return `${image}`.toLowerCase()?.trim().endsWith(".pdf") ? pdf : image;
};

export const renderDocument = (doc) => (
  <a
    className="rounded-md flex justify-center"
    href={doc}
    target="_blank"
    style={{ marginLeft: "10px" }}
  >
    <Image src={getImageSrc(doc)} alt="doc" width={100} height={100} />
  </a>
);

export const getAddress = (address) => {
  if (!address) return "N/A";
  return address.length > 40 ? `${address.slice(0, 40)}...` : address;
};

export const formatAmount = (amount) => (amount ? parseInt(amount) : "-");

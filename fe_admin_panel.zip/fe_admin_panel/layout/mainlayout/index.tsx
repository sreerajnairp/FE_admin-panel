import { LayoutProps } from "@/types/Admin";
import useWindowSize from "@/hooks/windowSize";
import { Navbar } from "@/components/Navbar";
import Sidebar from "@/components/Sidebar";
import { useEffect, useState } from "react";
import { useRouter } from "next/router";
import { DashboardMenu } from "@/helpers/constants";

export default function MainLayout({ children }: Readonly<LayoutProps>) {
  const router = useRouter();
  const { pathname } = router;
  const [sidebarOpen, setSidebarOpen] = useState<boolean>(false);
  const [profileShow, setProfileShow] = useState<boolean>(false);
  const width = useWindowSize();

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };
  
  useEffect(() => {
    width < 993 ? setSidebarOpen(true) : setSidebarOpen(false);
  }, [width]);

  useEffect(() => {
    if (!localStorage.getItem("accessToken")) {
      router.push("/auth/login");
    }
  }, []);

  useEffect(() => {
    const storedPermission = localStorage.getItem("permission") ?? "";
    if (storedPermission) {
      const route = DashboardMenu.find((r) => pathname.startsWith(r.link));
      const RedirectAuth = route?.roles.includes(storedPermission)
      if (!RedirectAuth) {
        router.push('/404')
      }
    }

  }, [pathname])

  return (
    <div className="flex flex-col md:flex-row">
      <div className="flex-shrink-0 overflow-y-auto">
        <Sidebar sidebarOpen={sidebarOpen} />
      </div>
      <div className="flex flex-col order-first md:order-last w-full overflow-y-auto">
        <Navbar
          toggleSidebar={toggleSidebar}
          sidebarOpen={sidebarOpen}
          ProfileShow={profileShow}
          setProfileShow={setProfileShow}
        />
        <main className="mx-8 mt-5">{children}</main>
      </div>
    </div>
  );
}

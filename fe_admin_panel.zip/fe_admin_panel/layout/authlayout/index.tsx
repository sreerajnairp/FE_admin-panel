import { LayoutProps } from "@/types/Admin";
import { useRouter } from "next/router";
import { useEffect } from "react";

export default function AuthLayout({ children }: Readonly<LayoutProps>) {
  const router = useRouter();
  const pathName = window.location.pathname?.split("/");
  useEffect(() => {
    if (pathName[1] !== "auth") {
      if (localStorage.getItem("accessToken")) {
        router.push("/dashboard/owner");
      }
    }
  }, [pathName]);

  return (
    <div className="min-h-screen">
      <div
        className="w-full h-screen bg-cover bg-center hidden md:block"
        style={{
          backgroundImage: `url('../asset/image/Admin_Banner.svg')`,
          position: "relative",
        }}
      />
      <div className="">{children}</div>
    </div>
  );
}

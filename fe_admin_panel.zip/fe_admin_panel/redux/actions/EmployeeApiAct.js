import { EmployeeVariable } from "../../service/apiVariable/employeeApiVariable";
import { addQuery, errorToast } from "../../helpers/utils";

//Employee List
export const getEmpoyeeListApi =
  (query) =>
  (dispatch, getState, { api, Toast }) => {
    addQuery(query, EmployeeVariable.getEmployeeListAllApi);
    return new Promise((resolve, reject) => {
      api({ ...EmployeeVariable?.getEmployeeListAllApi })
        .then((data) => {
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };

//Employee Delete
export const EmployeeDeleteApi =
  (body) =>
  (dispatch, getState, { api, Toast }) => {
    return new Promise((resolve, reject) => {
      api({
        ...EmployeeVariable?.deleteEmployeeApi,
        body,
      })
        .then((data) => {
          Toast({ type: "success", message: data.message });
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };

//Employee Add
export const EmployeeAddApi =
  (body) =>
  (dispatch, getState, { api, Toast }) => {
    return new Promise((resolve, reject) => {
      api({
        ...EmployeeVariable?.addEmployee,
        body,
        UploadImage: true,
        configObj: {
          headers: {
            "Content-Type": 'multipart/form-data'
          },
        },
      })
        .then((data) => {
          Toast({ type: "success", message: data.message });
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };

//Employee update
export const EmployeeUpdateApi =
  (body, query) =>
  (dispatch, getState, { api, Toast }) => {
    EmployeeVariable.updateEmployee.id = query.id;
    return new Promise((resolve, reject) => {
      api({
        ...EmployeeVariable?.updateEmployee,
        body,
        UploadImage: true,
        configObj: {
          headers: {
            "Content-Type": 'multipart/form-data'
          },
        },
      })
        .then((data) => {
          Toast({ type: "success", message: data.message });
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };

//Employee status update
export const EmployeeUpdateStatusApi =
  (body) =>
  (dispatch, getState, { api, Toast }) => {
    return new Promise((resolve, reject) => {
      api({
        ...EmployeeVariable?.updateStatusApi,
        body,
      })
        .then((data) => {
          Toast({ type: "success", message: data.message });
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };

//Employee get by id
export const getEmployeeById =
  (id) =>
  (dispatch, getState, { api, Toast }) => {
    EmployeeVariable.getEmployeeId.id = id;
    return new Promise((resolve, reject) => {
      api({
        ...EmployeeVariable?.getEmployeeId,
      })
        .then((data) => {
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };

  //Employee Resend Email
export const EmployeeResendEmailApi =
(body) =>
(dispatch, getState, { api, Toast }) => {
  return new Promise((resolve, reject) => {
    api({
      ...EmployeeVariable?.resendEmailEmployee,
      body,
    })
      .then((data) => {
        Toast({ type: "success", message: data.message });
        resolve(data);
      })
      .catch(({ message }) => reject(errorToast(message)));
  });
};
import { DriverVariable } from "../../service/apiVariable/driverApiVariable";
import { addQuery, errorToast } from "../../helpers/utils";

//Driver List
export const getDriverListApi =
  (query) =>
  (dispatch, getState, { api, Toast }) => {
    addQuery(query, DriverVariable.getAllDriverApi);
    return new Promise((resolve, reject) => {
      api({ ...DriverVariable?.getAllDriverApi })
        .then((data) => {
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };

//Driver get by id
export const getDriverById =
  (id) =>
  (dispatch, getState, { api, Toast }) => {
    DriverVariable.getDriverId.id = id;
    return new Promise((resolve, reject) => {
      api({
        ...DriverVariable?.getDriverId,
      })
        .then((data) => {
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };

//Driver Delete
export const DriverDeleteApi =
  (body) =>
  (dispatch, getState, { api, Toast }) => {
    return new Promise((resolve, reject) => {
      api({
        ...DriverVariable?.deleteDriverApi,
        body,
      })
        .then((data) => {
          Toast({ type: "success", message: data.message });
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };

//Driver update
export const DriverUpdateApi =
  (body, query) =>
  (dispatch, getState, { api, Toast }) => {
    DriverVariable.updateDriver.id = query.id;
    return new Promise((resolve, reject) => {
      api({
        ...DriverVariable?.updateDriver,
        body,
        UploadImage: true,
        configObj: {
          headers: {
            "Content-Type": 'multipart/form-data'
          },
        },
      })
        .then((data) => {
          Toast({ type: "success", message: data.message });
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };

//Driver Add
export const DriverAddApi =
  (body) =>
  (dispatch, getState, { api, Toast }) => {
    return new Promise((resolve, reject) => {
      api({
        ...DriverVariable?.addDriver,
        body,
        UploadImage: true,
        configObj: {
          headers: {
            "Content-Type": 'multipart/form-data'
          },
        },
      })
        .then((data) => {
          Toast({ type: "success", message: data.message });
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };
//Driver status update
export const DriverUpdateStatusApi =
  (body) =>
  (dispatch, getState, { api, Toast }) => {
    return new Promise((resolve, reject) => {
      api({
        ...DriverVariable?.updateStatusApi,
        body,
      })
        .then((data) => {
          Toast({ type: "success", message: data.message });
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };

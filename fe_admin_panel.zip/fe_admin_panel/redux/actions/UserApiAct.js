import { UserVariable } from "../../service/apiVariable/userApiVariable";
import { addQuery, errorToast } from "../../helpers/utils";

//User List
export const getUserListApi =
  (query) =>
  (dispatch, getState, { api, Toast }) => {
    addQuery(query, UserVariable.getAllUserApi);
    return new Promise((resolve, reject) => {
      api({ ...UserVariable?.getAllUserApi })
        .then((data) => {
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };

//User get by id
export const getUserById =
  (id) =>
  (dispatch, getState, { api, Toast }) => {
    UserVariable.getUserId.id = id;
    return new Promise((resolve, reject) => {
      api({
        ...UserVariable?.getUserId,
      })
        .then((data) => {
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };

//User Delete
export const UserDeleteApi =
  (body) =>
  (dispatch, getState, { api, Toast }) => {
    return new Promise((resolve, reject) => {
      api({
        ...UserVariable?.deleteUserApi,
        body,
      })
        .then((data) => {
          Toast({ type: "success", message: data.message });
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };

//User update
export const UserUpdateApi =
  (body, query) =>
  (dispatch, getState, { api, Toast }) => {
    UserVariable.updateUser.id = query.id;
    return new Promise((resolve, reject) => {
      api({
        ...UserVariable?.updateUser,
        body,
        UploadImage: true,
        configObj: {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        },
      })
        .then((data) => {
          Toast({ type: "success", message: data.message });
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };

//User Add
export const UserAddApi =
  (body) =>
  (dispatch, getState, { api, Toast }) => {
    return new Promise((resolve, reject) => {
      api({
        ...UserVariable?.addUser,
        body,
      })
        .then((data) => {
          Toast({ type: "success", message: data.message });
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };
//User status update
export const UserUpdateStatusApi =
  (body) =>
  (dispatch, getState, { api, Toast }) => {
    return new Promise((resolve, reject) => {
      api({
        ...UserVariable?.updateStatusApi,
        body,
      })
        .then((data) => {
          Toast({ type: "success", message: data.message });
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };

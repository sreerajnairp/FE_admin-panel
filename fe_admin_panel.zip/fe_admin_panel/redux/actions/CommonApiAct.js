import { CommonVariable } from "../../service/apiVariable/dropdownApiVariable";
import { errorToast, addQuery } from "../../helpers/utils";

// Country Drop Down API
export const getCountryListApi =
  (query) =>
  (dispatch, getState, { api, Toast }) => {
    return new Promise((resolve, reject) => {
      api({ ...CommonVariable?.getAllCountryApi })
        .then((data) => {
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };

//City Drop Down API
export const getCityListApi =
  (query) =>
  (dispatch, getState, { api, Toast }) => {
    return new Promise((resolve, reject) => {
      api({
        ...CommonVariable?.getAllCityApi,
        // body,
      })
        .then((data) => {
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };

//City Drop Down API
export const getCityApi =
  (query) =>
  (dispatch, getState, { api, Toast }) => {
    addQuery(query, CommonVariable.getCityApi);
    return new Promise((resolve, reject) => {
      api({ ...CommonVariable?.getCityApi })
        .then((data) => {
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };

//Image Upload
export const ImageUploadApi =
  (body) =>
  (dispatch, getState, { api, Toast }) => {
    return new Promise((resolve, reject) => {
      api({
        ...CommonVariable?.uploadImageApi,
        body,
        UploadImage: true,
      })
        .then((data) => {
          Toast({ type: "success", message: data.message });
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };

// Servicable Drop Down API
export const getServicableListApi =
  (query) =>
  (dispatch, getState, { api, Toast }) => {
    addQuery(query, CommonVariable.getServicableApi);
    return new Promise((resolve, reject) => {
      api({ ...CommonVariable?.getServicableApi })
        .then((data) => {
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };

// Permit Drop Down API
export const getPermitListApi =
  (query) =>
  (dispatch, getState, { api, Toast }) => {
    return new Promise((resolve, reject) => {
      api({ ...CommonVariable?.getPermitApi })
        .then((data) => {
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };

// State Permit Drop Down API
export const getStatePermitApi =
  (query) =>
  (dispatch, getState, { api, Toast }) => {
    addQuery(query, CommonVariable.getStatePermitApi);
    return new Promise((resolve, reject) => {
      api({ ...CommonVariable?.getStatePermitApi })
        .then((data) => {
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };

//City By State Id
export const getCityByStateApi =
  (stateId, query) =>
  (dispatch, getState, { api, Toast }) => {
    CommonVariable.getCityByState.stateId = stateId;
    addQuery(query, CommonVariable.getCityByState);
    return new Promise((resolve, reject) => {
      api({
        ...CommonVariable?.getCityByState,
      })
        .then((data) => {
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };

//state Update
export const getStateAddApi =
  (body) =>
  (dispatch, getState, { api, Toast }) => {
    return new Promise((resolve, reject) => {
      api({
        ...CommonVariable?.stateUpdate,
        body,
      })
        .then((data) => {
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };

//City Add
export const getCityAddApi =
  (body) =>
  (dispatch, getState, { api, Toast }) => {
    return new Promise((resolve, reject) => {
      api({
        ...CommonVariable?.cityAdd,
        body,
      })
        .then((data) => {
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };

//City Update
export const getCityUpdateApi =
  (body) =>
  (dispatch, getState, { api, Toast }) => {
    return new Promise((resolve, reject) => {
      api({
        ...CommonVariable?.cityUpdate,
        body,
      })
        .then((data) => {
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };

//State Delete
export const StateDeleteApi =
  (stateId) =>
  (dispatch, getState, { api, Toast }) => {
    CommonVariable.deleteStateApi.stateId = stateId;
    return new Promise((resolve, reject) => {
      api({
        ...CommonVariable?.deleteStateApi,
      })
        .then((data) => {
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };

//City Delete
export const CityDeleteApi =
  (cityId) =>
  (dispatch, getState, { api, Toast }) => {
    CommonVariable.deleteCityApi.cityId = cityId;
    return new Promise((resolve, reject) => {
      api({
        ...CommonVariable?.deleteCityApi,
      })
        .then((data) => {
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };

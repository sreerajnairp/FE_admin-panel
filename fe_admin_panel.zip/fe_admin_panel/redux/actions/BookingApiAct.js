import { BookingVariable } from "../../service/apiVariable/bookingApiVariable";
import { addQuery, errorToast } from "../../helpers/utils";

//Booking List
export const getBookingListApi =
  (query) =>
  (dispatch, getState, { api, Toast }) => {
    addQuery(query, BookingVariable.getAllBookingApi);
    return new Promise((resolve, reject) => {
      api({ ...BookingVariable?.getAllBookingApi })
        .then((data) => {
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };

//update Booking Status
export const BookingStatusUpdateApi =
  (body, query) =>
  (dispatch, getState, { api, Toast }) => {
    BookingVariable.updateBookingApi.id = query.id;
    return new Promise((resolve, reject) => {
      api({
        ...BookingVariable?.updateBookingApi,
        body,
      })
        .then((data) => {
          Toast({ type: "success", message: data.message });
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };
  
//Booking get by id
export const getBookingById =
  (id) =>
  (dispatch, getState, { api, Toast }) => {
    BookingVariable.getBookingId.id = id;
    return new Promise((resolve, reject) => {
      api({
        ...BookingVariable?.getBookingId,
      })
        .then((data) => {
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };

//Booking Assign Owner
export const BookingAssignOwnerApi =
  (body) =>
  (dispatch, getState, { api, Toast }) => {
    return new Promise((resolve, reject) => {
      api({
        ...BookingVariable?.assignOwner,
        body,
      })
        .then((data) => {
          Toast({ type: "success", message: data.message });
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };

//Refund Update
export const getRefundUpdateApi =
  (body) =>
  (dispatch, getState, { api, Toast }) => {
    return new Promise((resolve, reject) => {
      api({
        ...BookingVariable?.refundUpdate,
        body,
      })
        .then((data) => {
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };

//Lead Booking Delete
export const LeadDeleteApi =
  (body) =>
  (dispatch, getState, { api, Toast }) => {
    return new Promise((resolve, reject) => {
      api({
        ...BookingVariable?.leadDelete,
        body,
      })
        .then((data) => {
          Toast({ type: "success", message: data.message });
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };

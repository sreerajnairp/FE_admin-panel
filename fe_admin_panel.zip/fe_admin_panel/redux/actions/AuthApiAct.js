import { axiosInstance, getServiceUrl, logout } from "@/service/utilities";
import { errorToast } from "../../helpers/utils";
import { authApi } from "../../service/apiVariables";

// login API
export const LoginApi =
  (body) =>
  (dispatch, getState, { api, Toast }) => {
    return new Promise((resolve, reject) => {
      api({ ...authApi.loginApi, body })
        .then(({ data, message }) => {
          Toast({ type: "success", message });
          localStorage.setItem("accessToken", data.accessToken);
          localStorage.setItem("permission", data.role);
          localStorage.setItem("refreshToken", data.refreshToken);
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };

// Forgot Password API
export const ForgotPasswordApi =
  (body) =>
  (dispatch, getState, { api, Toast }) => {
    return new Promise((resolve, reject) => {
      api({
        ...authApi?.forgotApi,
        body,
      })
        .then((data) => {
          Toast({ type: "success", message: data.message });
          localStorage.setItem("userdetails", JSON.stringify(data?.data));
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };

// Verify OTP API
export const VerifyOTPApi =
  (body) =>
  (dispatch, getState, { api, Toast }) => {
    return new Promise((resolve, reject) => {
      api({
        ...authApi?.OTPApi,
        body,
      })
        .then((data) => {
          Toast({ type: "success", message: data.message });
          localStorage.setItem("resetHash", data?.data?.hash);
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };

// Reset Password API
export const ResetPasswordApi =
  (body) =>
  (dispatch, getState, { api, Toast }) => {
    return new Promise((resolve, reject) => {
      api({ ...authApi?.resetApi, body })
        .then((data) => {
          Toast({ type: "success", message: data.message });
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };

// Reset Password API
export const EmployeePasswordApi =
  (body) =>
  (dispatch, getState, { api, Toast }) => {
    return new Promise((resolve, reject) => {
      api({ ...authApi?.employeeSetPasswordApi, body })
        .then((data) => {
          Toast({ type: "success", message: data.message });
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };

//Access Token Refresh
export const AccessTokenRefresh = async (body) => {
  let request = await axiosInstance({
    method: "POST",
    data: body,
    url: getServiceUrl("user") + "auth/refresh-token",
  });
  return request;
};

//Logout Api
export const LogoutApi =
  () =>
  (dispatch, getState, { api, Toast }) => {
    const refreshToken = localStorage.getItem("refreshToken");
    let body = { refreshToken };
    return new Promise((resolve, reject) => {
      api({ ...authApi?.logoutApi, body })
        .then((data) => {
          Toast({ type: "success", message: data.message });
          resolve(data);
          logout();
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };

// Update profile
export const UpdateProfile =
  (body, query) =>
  (dispatch, getState, { api, Toast }) => {
    authApi.updateApi.id = query.id;
    return new Promise((resolve, reject) => {
      api({
        ...authApi?.updateApi,
        body,
      })
        .then((data) => {
          Toast({ type: "success", message: data.message });
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };

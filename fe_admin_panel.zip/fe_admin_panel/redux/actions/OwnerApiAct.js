import { OwnerVariable } from "../../service/apiVariable/ownerApiVariable";
import { addQuery, errorToast } from "../../helpers/utils";
import { BookingVariable } from "@/service/apiVariable/bookingApiVariable";

//User List
export const getOwnerListApi =
  (query) =>
  (dispatch, getState, { api, Toast }) => {
    addQuery(query, OwnerVariable.getOwnerListAllApi);
    return new Promise((resolve, reject) => {
      api({ ...OwnerVariable?.getOwnerListAllApi })
        .then((data) => {
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };

//User update
export const OwnerUpdateApi =
  (body, query) =>
  (dispatch, getState, { api, Toast }) => {
    OwnerVariable.updateOwner.id = query.id;
    return new Promise((resolve, reject) => {
      api({
        ...OwnerVariable?.updateOwner,
        body,
        UploadImage: true,
        configObj: {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        },
      })
        .then((data) => {
          Toast({ type: "success", message: data.message });
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };

//User Add
export const OwnerAddApi =
  (body) =>
  (dispatch, getState, { api, Toast }) => {
    return new Promise((resolve, reject) => {
      api({
        ...OwnerVariable?.addOwner,
        body,
        UploadImage: true,
        configObj: {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        },
      })
        .then((data) => {
          Toast({ type: "success", message: data.message });
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };

//User get by id
export const getOwnerById =
  (id) =>
  (dispatch, getState, { api, Toast }) => {
    OwnerVariable.getOwnerId.id = id;
    return new Promise((resolve, reject) => {
      api({
        ...OwnerVariable?.getOwnerId,
      })
        .then((data) => {
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };

//User status update
export const OwnerUpdateStatusApi =
  (body) =>
  (dispatch, getState, { api, Toast }) => {
    return new Promise((resolve, reject) => {
      api({
        ...OwnerVariable?.updateStatusApi,
        body,
      })
        .then((data) => {
          Toast({ type: "success", message: data.message });
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };

//User Delete
export const OwnerDeleteApi =
  (body) =>
  (dispatch, getState, { api, Toast }) => {
    return new Promise((resolve, reject) => {
      api({
        ...OwnerVariable?.deleteTruckApi,
        body,
      })
        .then((data) => {
          Toast({ type: "success", message: data.message });
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };

//ServiceableOwners
export const getServiceableOwnersList =
  (id, query) =>
  (dispatch, getState, { api, Toast }) => {
    BookingVariable.getServiceableOwners.id = id;
    addQuery(query, BookingVariable.getServiceableOwners);
    return new Promise((resolve, reject) => {
      api({
        ...BookingVariable?.getServiceableOwners,
      })
        .then((data) => {
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };

import { TruckVariable } from "../../service/apiVariable/truckApiVariable";
import { addQuery, errorToast } from "../../helpers/utils";

//User List
export const getTruckListApi =
  (query) =>
  (dispatch, getState, { api, Toast }) => {
    addQuery(query, TruckVariable.getTruckListAllApi);
    return new Promise((resolve, reject) => {
      api({ ...TruckVariable?.getTruckListAllApi })
        .then((data) => {
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };
//User update
export const TruckUpdateApi =
  (body, query) =>
  (dispatch, getState, { api, Toast }) => {
    TruckVariable.updateTruck.id = query.id;
    return new Promise((resolve, reject) => {
      api({
        ...TruckVariable?.updateTruck,
        body,
        UploadImage: true,
        configObj: {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        },
      })
        .then((data) => {
          Toast({ type: "success", message: data.message });
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };

//User Add
export const TruckAddApi =
  (body) =>
  (dispatch, getState, { api, Toast }) => {
    return new Promise((resolve, reject) => {
      api({
        ...TruckVariable?.addTruck,
        body,
        UploadImage: true,
        configObj: {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        },
      })
        .then((data) => {
          Toast({ type: "success", message: data.message });
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };

//User get by id
export const getTruckById =
  (id) =>
  (dispatch, getState, { api, Toast }) => {
    TruckVariable.getTruckId.id = id;
    return new Promise((resolve, reject) => {
      api({
        ...TruckVariable?.getTruckId,
      })
        .then((data) => {
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };

//User status update
export const TruckUpdateStatusApi =
  (body) =>
  (dispatch, getState, { api, Toast }) => {
    return new Promise((resolve, reject) => {
      api({
        ...TruckVariable?.updateStatusApi,
        body,
      })
        .then((data) => {
          Toast({ type: "success", message: data.message });
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };

//User Delete
export const TruckDeleteApi =
  (body) =>
  (dispatch, getState, { api, Toast }) => {
    return new Promise((resolve, reject) => {
      api({
        ...TruckVariable?.deleteTruckApi,
        body,
      })
        .then((data) => {
          Toast({ type: "success", message: data.message });
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };

//Vehicle Type List
export const getVehicleTypeApi =
  (query) =>
  (dispatch, getState, { api, Toast }) => {
    addQuery(query, TruckVariable.getVehicleTypeApi);
    return new Promise((resolve, reject) => {
      api({ ...TruckVariable?.getVehicleTypeApi })
        .then((data) => {
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };
//Vehicle Load Type List
export const getVehicleLoadTypeApi =
  (query) =>
  (dispatch, getState, { api, Toast }) => {
    addQuery(query, TruckVariable.getVehicleLoadTypeApi);
    return new Promise((resolve, reject) => {
      api({ ...TruckVariable?.getVehicleLoadTypeApi })
        .then((data) => {
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };
//Vehicle Capacity List
export const getVehicleCapacityApi =
  (query) =>
  (dispatch, getState, { api, Toast }) => {
    addQuery(query, TruckVariable.getVehicleCapacityApi);
    return new Promise((resolve, reject) => {
      api({ ...TruckVariable?.getVehicleCapacityApi })
        .then((data) => {
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };
//Vehicle Size List
export const getVehicleSizeApi =
  (query) =>
  (dispatch, getState, { api, Toast }) => {
    addQuery(query, TruckVariable.getVehicleSizeApi);
    return new Promise((resolve, reject) => {
      api({ ...TruckVariable?.getVehicleSizeApi })
        .then((data) => {
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };
//VEhicle Model List
export const getVehicleModelApi =
  (query) =>
  (dispatch, getState, { api, Toast }) => {
    addQuery(query, TruckVariable.getVehicleModelApi);
    return new Promise((resolve, reject) => {
      api({ ...TruckVariable?.getVehicleModelApi })
        .then((data) => {
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };

//Vehicle Tyre List
export const getVehicleTyreApi =
  (query) =>
  (dispatch, getState, { api, Toast }) => {
    addQuery(query, TruckVariable.getVehicleTyreApi);
    return new Promise((resolve, reject) => {
      api({ ...TruckVariable?.getVehicleTyreApi })
        .then((data) => {
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };

//Vehicle Axle List
export const getVehicleAxleApi =
  (query) =>
  (dispatch, getState, { api, Toast }) => {
    addQuery(query, TruckVariable.getVehicleAxleApi);
    return new Promise((resolve, reject) => {
      api({ ...TruckVariable?.getVehicleAxleApi })
        .then((data) => {
          resolve(data);
        })
        .catch(({ message }) => reject(errorToast(message)));
    });
  };

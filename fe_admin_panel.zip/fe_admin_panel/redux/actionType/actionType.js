export const adminDetails = {
    sourceOptions: 'SOURCE_OPTIONS',
};
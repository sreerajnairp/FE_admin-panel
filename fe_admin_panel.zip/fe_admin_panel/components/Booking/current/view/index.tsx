import { useRouter } from "next/router";
import { useState, useCallback, useEffect } from "react";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import Image from "next/image";
import moment from "moment";
import check from "@/assets/svg/tick.svg";
import { getBookingById } from "@/redux/actions/BookingApiAct";
import { ORDER_STATUS } from "@/helpers/constants";
import { LoadingScreen } from "@/components/common/Loader";
import { getAddress, renderDocument } from "@/service/utilities";
import dynamic from "next/dynamic";

const MapComponent = dynamic(() => import("../mapComponent"), { ssr: false });

const CurrentView = ({ getBookingById }: any) => {
  const router = useRouter();
  const { _id = "" } = router.query;
  const [userData, setUserData] = useState(null);
  const [loadingFetch, setLoadingFetch] = useState(true);

  const getBookingDetailsByID = useCallback(async () => {
    if (_id) {
      const { data } = await getBookingById(_id);
      setUserData(data);
      setLoadingFetch(false);
    }
  }, [_id]);

  useEffect(() => {
    if (_id) {
      getBookingDetailsByID();
    }
  }, [_id]);

  const formatDateTime = (dateTime: any) => {
    if (!dateTime) return "";
    return moment(dateTime).format("DD/MM/YYYY LT");
  };
  const formatDate = (date: any) => {
    if (!date) return "N/A";
    return moment(date).format("DD/MM/YYYY");
  };

  const approvedStatuses = ["Approved", "Ongoing", "Inprogress", "Completed"];
  const approveStatus = ["Inprogress", "Ongoing", "Completed"];

  const userStatus = (userData as any)?.status;
  const isInprogress = ORDER_STATUS[userStatus] === "Inprogress";
  const isRouteStarted = (userData as any)?.isRouteStarted;
  const isOngoing = ORDER_STATUS[userStatus] === "Ongoing";
  const isOngoingAndRouteStarted = isOngoing && isRouteStarted;
  const isCompleted = ORDER_STATUS[userStatus] === "Completed";

  const renderImages = (images: any) => {
    return images ? renderDocument(images) : "Profile Not Uploaded";
  };

  const renderInvoiceSection = () => {
    return (
      <div className="mt-5 md:mt-0">
        <h3 className="text-primary_color font-Inter capitalize flex items-center text-xl font-extrabold mb-2 mt-2">
          Invoice
        </h3>
        <table className="border-collapse border border-solid border-gray-400 w-full">
          <tbody>
            <tr>
              <td className="px-4 py-20">
                {renderImages((userData as any)?.invoice)}
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    );
  };

  return (
    <>
      {loadingFetch && <LoadingScreen />}
      <div className="w-6xl mx-auto container rounded overflow-hidden border mb-5 p-4">
        <div className="my-5">
          <ul className="relative flex flex-col md:flex-row gap-2 mx-5 text-center">
            <li className="shrink basis-0 flex-1 group">
              <p className="h-12 my-2 px-4 box-content">
                {formatDateTime((userData as any)?.assignedAt)}
              </p>
              <div className="md:ms-14 lg:ms-24 min-w-7 min-h-7 w-full inline-flex justify-center items-center text-xs align-middle">
                <span className="size-10 flex justify-center items-center flex-shrink-0 bg-primary_color font-medium text-white rounded-full">
                  {approvedStatuses.includes(ORDER_STATUS[userStatus]) ? (
                    <Image src={check} alt="check" width={20} height={20} />
                  ) : (
                    1
                  )}
                </span>
                <span className="hidden md:block w-full h-[3px] flex-1 bg-primary_color group-last:hidden "></span>
              </div>
              <div className="mt-3">
                <span className="block text-md font-medium  px-4 text-primary_color">
                  Booking Assigned
                </span>
              </div>
            </li>
            <li className="shrink basis-0 flex-1 group">
              <p className="h-12 my-2 px-4 box-content">
                {formatDateTime((userData as any)?.inprogressAt)}
              </p>
              <div className="md:ms-14 lg:ms-24  min-w-7 min-h-7 w-full inline-flex justify-center items-center text-xs align-middle">
                <span
                  className={`size-10 flex justify-center items-center flex-shrink-0 ${
                    approveStatus.includes(ORDER_STATUS[userStatus])
                      ? "bg-primary_color text-white"
                      : "bg-white text-primary_color border-primary_color"
                  } font-medium rounded-full border-2`}
                >
                  {approveStatus.includes(ORDER_STATUS[userStatus]) ? (
                    <Image src={check} alt="check" width={20} height={20} />
                  ) : (
                    2
                  )}
                </span>
                <div
                  className={`hidden md:block w-full h-[3px] flex-1 ${
                    isInprogress || isOngoingAndRouteStarted || isCompleted
                      ? "bg-primary_color"
                      : "bg-grey-line"
                  } group-last:hidden`}
                ></div>
              </div>
              <div className="mt-3">
                <span className="block text-md font-medium text-gray-800  px-4">
                  Out for Pickup
                </span>
              </div>
            </li>
            <li className="shrink basis-0 flex-1 group">
              <p className="h-12 my-2 px-4 box-content">
                {formatDateTime((userData as any)?.routeStartedAt)}
              </p>
              <div className="md:ms-14 lg:ms-24  min-w-7 min-h-7 w-full inline-flex justify-center items-center text-xs align-middle">
                <span
                  className={`size-10 flex justify-center items-center flex-shrink-0 ${
                    isOngoingAndRouteStarted || isCompleted
                      ? "bg-primary_color text-white"
                      : "bg-white text-primary_color border-primary_color"
                  } font-medium rounded-full border-2`}
                >
                  {isOngoingAndRouteStarted || isCompleted ? (
                    <Image src={check} alt="check" width={20} height={20} />
                  ) : (
                    3
                  )}
                </span>
                <div
                  className={`hidden md:block w-full h-[3px] flex-1 ${
                    isOngoingAndRouteStarted || isCompleted
                      ? "bg-primary_color"
                      : "bg-grey-line"
                  } group-last:hidden`}
                ></div>
              </div>
              <div className="mt-3">
                <span className="block text-md font-medium text-gray-800  px-4">
                  Goods Collected/ <br />
                  Trip Started
                </span>
              </div>
            </li>
            <li className="shrink basis-0 flex-1 group">
              <p className="h-12 my-2 px-4 box-content">
                {formatDateTime((userData as any)?.completedAt)}
              </p>
              <div className="md:ms-14 lg:ms-24 min-w-7 min-h-7 w-full inline-flex justify-center md:justify-normal items-center text-xs align-middle">
                <span
                  className={`size-10 flex justify-center items-center flex-shrink-0 ${
                    isCompleted
                      ? "bg-primary_color text-white"
                      : "bg-white text-primary_color border-primary_color"
                  } font-medium rounded-full border-2`}
                >
                  {isCompleted ? (
                    <Image src={check} alt="check" width={20} height={20} />
                  ) : (
                    4
                  )}
                </span>
              </div>
              <div className="mt-3">
                <span className="block text-md font-medium text-gray-800  px-4">
                  Goods Delivered
                </span>
              </div>
            </li>
          </ul>
        </div>
      </div>
      <div className="w-6xl mx-auto container overflow-hidden">
        <div className="relative w-full h-screen">
          <div className="absolute top-8 left-0 w-full h-5/6 z-10">
            {(userData as any)?.dropLongitude &&
              (userData as any)?.pickupLongitude && (
                <MapComponent
                  id={_id}
                  status={ORDER_STATUS[userStatus]}
                  isRouteStarted={(userData as any)?.isRouteStarted}
                  bookedLocation={{
                    longitude: (userData as any)?.dropLongitude,
                    latitude: (userData as any)?.dropLattitude,
                    name: (userData as any)?.dropAddress,
                  }}
                  pickupLocation={{
                    longitude: (userData as any)?.pickupLongitude,
                    latitude: (userData as any)?.pickupLattitude,
                    name: (userData as any)?.pickupAddress,
                  }}
                  truckLocation={{
                    longitude: (userData as any)?.driverLongitude,
                    latitude: (userData as any)?.driverLatitude,
                  }}
                />
              )}
          </div>
        </div>
      </div>
      <div className="gap-5 grid grid-cols-1 md:grid-cols-2">
        <div>
          <h3 className="text-primary_color font-Inter capitalize flex items-center text-xl font-extrabold mb-2 mt-2">
            Order Details
          </h3>
          <table className="border-collapse border border-solid border-gray-400 w-full">
            <tbody>
              <tr>
                <th className="px-4 pt-4 text-start">Order ID:</th>
                <td className="px-4 pt-4">
                  {(userData as any)?.orderId || "-"}
                </td>
              </tr>

              <tr>
                <th className="px-4 pt-4 text-start">Order Date & Time:</th>
                <td className="px-4 pt-4">
                  {formatDateTime((userData as any)?.createdAt)}
                </td>
              </tr>
              <tr>
                <th className="px-4 pt-4 text-start">Payment:</th>
                <td className="px-4 pt-4">
                  {parseInt((userData as any)?.advanceAmount) || "-"} /{" "}
                  {parseInt((userData as any)?.totalPrice) || "-"}
                </td>
              </tr>
              <tr>
                <th className="px-4 pt-4 text-start">Load Type:</th>
                <td className="px-4 pt-4">
                  {(userData as any)?.vehicleLoadTypeName || "-"}
                </td>
              </tr>
              <tr>
                <th className="px-4 pt-4 text-start">Pickup Location:</th>
                <td className="px-4 pt-4">
                  <div className="has-tooltip font-Inter font-lg">
                    <span className="tooltip max-w-60 rounded shadow-lg p-1 bg-gray-100 text-primary_color -mt-8">
                      {(userData as any)?.pickupAddress || "-"}
                    </span>
                    <p className="break-all font-xl font-Inter font-normal text-grey">
                      {getAddress((userData as any)?.pickupAddress)}
                    </p>
                  </div>
                </td>
              </tr>
              <tr>
                <th className="px-4 pt-4 pb-5 text-start">Drop Location:</th>
                <td className="px-4 py-4">
                  <div className="has-tooltip font-Inter font-lg">
                    <span className="tooltip max-w-60 rounded shadow-lg p-1 bg-gray-100 text-primary_color -mt-8">
                      {(userData as any)?.dropAddress || "-"}
                    </span>
                    <p className="break-all font-xl font-Inter font-normal text-grey">
                      {getAddress((userData as any)?.dropAddress)}
                    </p>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        {isCompleted ? renderInvoiceSection() : " "}
      </div>
      <div className="gap-5 grid grid-cols-1 md:grid-cols-2 mt-5">
        <div>
          <h3 className="text-primary_color font-Inter capitalize flex items-center text-xl font-extrabold mb-2 mt-2">
            Owner Details
          </h3>
          <table className="border-collapse border border-solid border-gray-400 w-full">
            <tbody>
              <tr>
                <th className="px-4 pt-4 text-start">Owner Name:</th>
                <td className="px-4 pt-4">
                  {(userData as any)?.ownerName || "-"}
                </td>
              </tr>
              <tr>
                <th className="px-4 pt-4 text-start">Owner Company Name:</th>
                <td className="px-4 pt-4">
                  {(userData as any)?.companyName || "-"}
                </td>
              </tr>
              <tr>
                <th className="px-4 pt-4 text-start">Email:</th>
                <td className="px-4 pt-4">
                  {(userData as any)?.ownerEmail || "-"}
                </td>
              </tr>
              <tr>
                <th className="px-4 pt-4 text-start">Phone Number:</th>
                <td className="px-4 pt-4">
                  {(userData as any)?.ownerMobile || "-"}
                </td>
              </tr>
              <tr>
                <th className="px-4 py-4 text-start">Base Location:</th>
                <td className="px-4 py-4">
                  {(userData as any)?.baseLocationCity || "-"}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        <div className="mt-5 md:mt-0">
          <h3 className="text-primary_color font-Inter capitalize flex items-center text-xl font-extrabold mb-2 mt-2">
            Truck Details
          </h3>
          <table className="border-collapse border border-solid border-gray-400 w-full">
            <tbody>
              <tr>
                <th className="px-4 pt-4 text-start">Registration Number:</th>
                <td className="px-4 pt-4">
                  {(userData as any)?.registrationNumber || "-"}
                </td>
              </tr>
              <tr>
                <th className="px-4 pt-4 text-start">Truck Model:</th>
                <td className="px-4 pt-4">
                  {(userData as any)?.vehicleModelName || "-"}
                </td>
              </tr>
              <tr>
                <th className="px-4 pt-4 text-start"> Insurance Validity:</th>
                <td className="px-4 pt-4">
                  {formatDate((userData as any)?.insuranceValidity)}
                </td>
              </tr>
              <tr>
                <th className="px-4 pt-4 text-start"> Truck Type:</th>
                <td className="px-4 pt-4 w-96">
                  {(userData as any)?.vehicleTypeName || "-"}
                </td>
              </tr>
              <tr>
                <th className="px-4 py-4 text-start">Capacity Limit:</th>
                <td className="px-4 py-4 w-96">
                  {(userData as any)?.vehicleCapacityName || "-"}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
      <div className="gap-5 grid grid-cols-1 md:grid-cols-2 my-10">
        <div>
          <h3 className="text-primary_color font-Inter capitalize flex items-center text-xl font-extrabold mb-2 mt-2">
            Customer Details
          </h3>
          <table className="border-collapse border border-solid border-gray-400 w-full">
            <tbody>
              <tr>
                <th className="px-4 pt-4 text-start">Customer Name:</th>
                <td className="px-4 pt-4">
                  {(userData as any)?.receiverName || "-"}
                </td>
              </tr>
              <tr>
                <th className="px-4 pt-4 text-start">Phone Number:</th>
                <td className="px-4 pt-4">
                  {(userData as any)?.receiverMobile || "-"}
                </td>
              </tr>
              <tr>
                <th className="px-4 py-4 text-start">Alternate Mobile:</th>
                <td className="px-4 py-4">
                  {(userData as any)?.receiverAlternateMobile || "-"}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        <div className="mt-5 md:mt-0">
          <h3 className="text-primary_color font-Inter capitalize flex items-center text-xl font-extrabold mb-2 mt-2">
            Driver Details
          </h3>
          <table className="border-collapse border border-solid border-gray-400 w-full">
            <tbody>
              <tr>
                <th className="px-4 pt-4 text-start">Driver Name:</th>
                <td className="px-4 pt-4">
                  {(userData as any)?.driverName || "-"}
                </td>
              </tr>
              <tr>
                <th className="px-4 pt-4 text-start">Email:</th>
                <td className="px-4 pt-4">
                  {(userData as any)?.driverEmail || "-"}
                </td>
              </tr>
              <tr>
                <th className="px-4 py-4 text-start">Phone Number:</th>
                <td className="px-4 py-4">
                  {(userData as any)?.driverMobile || "-"}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
};

const mapDispatchToProps = (dispatch: any) => {
  return bindActionCreators({ getBookingById }, dispatch);
};
export default connect(null, mapDispatchToProps)(CurrentView);

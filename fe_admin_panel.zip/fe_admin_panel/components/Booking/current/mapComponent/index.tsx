import React, { useState, useEffect, useCallback } from 'react';
import { Layer, Marker, Popup, Source, Map } from 'react-map-gl';
import MapMarkerImg from "@/assets/map_marker.png";
import StartMarkerImg from "@/assets/svg/truckGps.svg";
import Image from 'next/image';
import 'mapbox-gl/dist/mapbox-gl.css';
import io, { Socket } from 'socket.io-client';
import { DefaultEventsMap } from '@socket.io/component-emitter';
import debounce from 'lodash/debounce';
import mapboxgl from 'mapbox-gl'
import configBasedOnEnv from '@/config';

const MAPBOX_TOKEN = process.env.NEXT_PUBLIC_ENV_MAPBOX_KEY
const SOCKET_SERVER_URL = configBasedOnEnv?.socket

let socket: Socket<DefaultEventsMap, DefaultEventsMap>;
const MapComponent = ({ bookedLocation, pickupLocation, status = "Approved", deliveryStatus = "pickup" , isRouteStarted, id, truckLocation }: any) => {
    const [viewport, setViewport] = useState({
        longitude: 0,
        latitude: 0,
        zoom: 10,
    });
    const [route, setRoute] = useState(null);
    const [showPopup, setShowPopup] = useState(false);
    const [popupInfo, setPopupInfo] = useState<any>({});
    const [truckLocations, setTruckLocations] = useState({
        longitude: truckLocation?.longitude || 80.165709,
        latitude: truckLocation?.latitude || 13.061756,
        name: "Truck Location",
        heading : 0,
        streetName: ""
    });
    useEffect(() => {
        setViewport({
            ...viewport,
            longitude: pickupLocation?.longitude,
            latitude: pickupLocation?.latitude,
        });
    }, []);
    useEffect(() => {
        if (status === 'Ongoing' || status === "Inprogress") {
            fetchTruckRoute();
            setViewport({
                ...viewport,
                longitude: truckLocations?.longitude,
                latitude: truckLocations?.latitude,
            });
        } else if(status === 'Approved' || status === "Completed") {
            fetchRoute();
        }else{
            setRoute(null);
        }
    }, [status,truckLocations]);
    useEffect(() => {
        socketInitializer();

        return () => {
            socket.disconnect();
        };
    }, []);
    
    async function socketInitializer() {

        socket = io(SOCKET_SERVER_URL,{
            reconnectionAttempts: 5,
            reconnectionDelay: 1000,
            transports: ["websocket"]
          });
        socket.on('connect', () => {
          console.log('Connected to server');
          const bookingData = {
            bookingId: id
          };
          socket.emit('subscribe', bookingData)
        });
        socket.on("driverLocationUpdate", (location: any) => {
          console.log("New location received:", location , new Date());
          setTruckLocations({
            ...truckLocations,
            longitude: location.longitude,
            latitude: location.latitude,
            heading : parseInt(location.heading) + 90
          });
        });
       
      }
    const fetchRoute = async () => {
        try {
            const response = await fetch(
                `https://api.mapbox.com/directions/v5/mapbox/driving/${bookedLocation.longitude},${bookedLocation.latitude};${pickupLocation.longitude},${pickupLocation.latitude}?access_token=${MAPBOX_TOKEN}&alternatives=true&steps=true&overview=full&geometries=geojson&banner_instructions=true&voice_instructions=true`
            );
            const data = await response.json();
            if (data.routes && data.routes.length > 0) {
                setRoute(data.routes[0]);
                // setWaypoints(data?.waypoints)
            } else {
                console.error('No routes found.');
            }
        } catch (error) {
            console.error('Error fetching route:', error);
        }
    };
    const fetchTruckRoute = async () => {
        try {
            const destinationLocation = {
                longitude: isRouteStarted ? bookedLocation?.longitude : pickupLocation?.longitude ,
                latitude: isRouteStarted ? bookedLocation?.latitude : pickupLocation?.latitude
            }
            const response = await fetch(
                `https://api.mapbox.com/directions/v5/mapbox/driving/${truckLocations.longitude},${truckLocations.latitude};${destinationLocation.longitude},${destinationLocation.latitude}?access_token=${MAPBOX_TOKEN}&alternatives=true&steps=true&overview=full&geometries=geojson&banner_instructions=true&voice_instructions=true`
            );
            const data = await response.json();
            if (data.routes && data.routes.length > 0) {
                setRoute(data.routes[0]);
                // setWaypoints(data?.waypoints)
            } else {
                console.error('No routes found.');
            }
        } catch (error) {
            console.error('Error fetching route:', error);
        }
    };

    const handleViewportChange = useCallback(debounce((newViewport) => {
        setViewport(newViewport);
      }, 100), []);
    const handleMarkerClick = (event: any, info: any) => {
        event.preventDefault();
        setPopupInfo(info);
        setShowPopup(true);
    };

    return (
        <div style={{ height: '100%', width: '100%' }}>
            <Map
                mapboxAccessToken={MAPBOX_TOKEN}
                mapStyle="mapbox://styles/mapbox/streets-v11"
                {...viewport}
                interactive={true}
                onMove={handleViewportChange}
            >
                <Marker
                    longitude={bookedLocation?.longitude}
                    latitude={bookedLocation?.latitude}
                >
                    <Image
                        src={MapMarkerImg}
                        alt="Drop Location Marker"
                        width={30}
                        height={30}
                        onClick={(event) => handleMarkerClick(event, bookedLocation)}
                    />
                </Marker>
                <Marker
                    longitude={pickupLocation?.longitude}
                    latitude={pickupLocation?.latitude}
                >
                    <Image
                        src={MapMarkerImg}
                        alt="Pickup Location Marker"
                        width={30}
                        height={30}
                        onClick={(event) => handleMarkerClick(event, pickupLocation)}
                    />
                </Marker>
                {(status == 'Ongoing' || status == "Inprogress") &&
                    (
                        <Marker
                            longitude={truckLocations?.longitude}
                            latitude={truckLocations?.latitude}
                        >
                            <Image
                                src={StartMarkerImg}
                                alt="Truck Location Marker"
                                width={80}
                                height={80}
                                onClick={(event) => handleMarkerClick(event, truckLocations)}
                                style={{ transform: `rotate(${truckLocations?.heading}deg)` }}
                            />
                        </Marker>
                    )
                }
                {route && (
                    <Source id="route" type="geojson" data={(route as any)?.geometry}>
                        <Layer
                            id="route"
                            type="line"
                            paint={{
                                'line-color': '#2D0977',
                                'line-width': 4,
                            }}
                        />
                    </Source>
                )}
                {showPopup && (
                    <Popup
                        longitude={popupInfo?.longitude}
                        latitude={popupInfo?.latitude}
                        onClose={() => setShowPopup(false)}
                        closeOnClick={false}
                    >
                        <div className='p-3'>
                            <p className='text-primary_color text-md font-extrabold font-Inter capitalize'>{popupInfo?.name}</p>
                            <p className='text-secondary_color text-md font-extrabold font-Inter capitalize'>{popupInfo?.streetName}</p>
                            {(route as any)?.duration && <p>Estimated Time: {`${Math.floor((route as any)?.duration / 3600)}h ${Math.round(((route as any)?.duration % 3600) / 60)}min`}</p>}
                            {(route as any)?.distance && <p>Distance: {`${((route as any)?.distance / 1000).toFixed(2)} km`}</p>}
                        </div>
                    </Popup>
                )}
            </Map>
        </div>
    );
};

export default MapComponent;

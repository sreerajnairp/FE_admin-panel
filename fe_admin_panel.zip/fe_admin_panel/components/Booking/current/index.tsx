import { useRouter } from "next/router";
import { useEffect, useState } from "react";
import TableWrapper from "@/components/common/TableWrapper";
import Pagination from "@/components/common/Pagination";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import { UserDeleteApi, UserUpdateStatusApi } from "@/redux/actions/UserApiAct";
import { PageMeta } from "@/types/common";
import {
  ORDER_STATUS,
  PAYMENT_STATUS,
  bookingApprovedHeader,
} from "@/helpers/constants";
import view from "@/assets/svg/view_icon.svg";
import Image from "next/image";
import moment from "moment";
import { getBookingListApi } from "@/redux/actions/BookingApiAct";
import { LoadingScreen } from "@/components/common/Loader";
import { getAddress } from "@/service/utilities";

const BookingCurrent = ({ getBookingListApi }: any) => {
  const router = useRouter();
  const [userData, setUserData] = useState([]);
  const [pageMeta, setPageMeta] = useState<PageMeta>();
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [page, setPage] = useState(1);
  const [loadingFetch, setLoadingFetch] = useState(true);

  useEffect(() => {
    const queryPage = parseInt(router.query.page as string) || 1;
    setPage(queryPage);
  }, [router.query.page]);

  useEffect(() => {
    getOngoingApiFunc();
  }, [page, rowsPerPage]);

  const getOngoingApiFunc = () => {
    let query = {
      page: page,
      size: rowsPerPage,
      status: 2,
      isRouteStarted: 1,
    };
    getBookingListApi(query)
      .then(({ data }: any) => {
        setUserData(data.list);
        setPageMeta(data.pageMeta);
        setLoadingFetch(false);
      })
      .catch((e: any) => {
        console.log(e);
      });
  };

  return (
    <>
      {loadingFetch && <LoadingScreen />}
      <TableWrapper
        headers={bookingApprovedHeader}
        listData={userData}
        isStatus={true}
        isAction={true}
      >
        {userData?.length !== 0 ? (
          userData?.map((user: any, index: number) => {
            return (
              <tr
                key={user?.id}
                className="bg-white border-b  hover:bg-gray-50"
              >
                <td className="px-4 py-3">
                  <p className=" font-xl font-Inter font-normal text-grey whitespace-nowrap ">
                    {user?.username || "N/A"}
                  </p>
                </td>
                <td className="px-4 py-3">
                  <p className=" font-xl font-Inter font-normal text-grey whitespace-nowrap">
                    {user?.orderId || "N/A"}
                  </p>
                </td>
                <td className="px-4 py-3">
                  <div className="has-tooltip">
                    <span className="tooltip max-w-64 rounded shadow-lg p-1 bg-gray-100 text-primary_color  -mt-8">
                      {user?.pickupAddress || "N/A"}
                    </span>
                    <p className="w-32 break-all font-xl font-Inter font-normal text-grey">
                      {getAddress(user?.pickupAddress)}
                    </p>
                  </div>
                </td>
                <td className="px-4 py-3">
                  <div className="has-tooltip">
                    <span className="tooltip max-w-60 rounded shadow-lg p-1 bg-gray-100 text-primary_color -mt-8">
                      {user?.dropAddress || "N/A"}
                    </span>
                    <p className=" w-32 break-all font-xl font-Inter font-normal text-grey">
                      {getAddress(user?.dropAddress)}
                    </p>
                  </div>
                </td>
                <td className="px-4 py-3 text-center">
                  <p className=" font-xl font-Inter font-normal text-grey whitespace-nowrap">
                    {moment(user?.pickupDateTime).utc().format("DD/MM/YYYY") ||
                      "N/A"}
                  </p>
                  <p className=" font-xl font-Inter font-normal text-grey whitespace-nowrap">
                    {moment(user?.pickupDateTime).utc().format("LT") || "N/A"}
                  </p>
                </td>
                <td className="px-4 py-3">
                  <p className=" font-xl font-Inter font-normal text-grey whitespace-nowrap ">
                    {user?.vehicleLoadTypeName || "N/A"}
                  </p>
                </td>
                <td className="px-4 py-3 text-center">
                  <p className=" font-xl font-Inter font-normal text-grey whitespace-nowrap ">
                    {moment(user?.createdAt).format("DD/MM/YYYY") || "N/A"}
                  </p>
                  <p className=" font-xl font-Inter font-normal text-grey whitespace-nowrap">
                    {moment(user?.createdAt).format("LT") || "N/A"}
                  </p>
                </td>
                <td className="px-4 py-3">
                  <p className=" font-xl font-Inter font-normal text-grey whitespace-nowrap capitalize">
                    {PAYMENT_STATUS[user?.paymentStatus]}
                  </p>
                </td>
                <td className="px-4 py-3">
                  <p className=" font-xl font-Inter font-normal text-grey whitespace-nowrap">
                    <span className="text-green">
                      {user?.advanceAmount
                        ? parseInt(user?.advanceAmount)
                        : "-"}
                    </span>
                    {" / "}
                    {PAYMENT_STATUS[user?.paymentStatus] == "Fully paid" ? (
                      <span className="text-green">
                        {user?.initialBalanceAmount
                          ? parseInt(user?.initialBalanceAmount)
                          : "-"}
                      </span>
                    ) : (
                      <span className="text-red-500">
                        {user?.balanceAmount
                          ? parseInt(user?.balanceAmount)
                          : "-"}
                      </span>
                    )}
                  </p>
                  <p className="font-xl my-1 font-Inter font-normal text-grey whitespace-nowrap">
                    T - {user?.totalPrice ? parseInt(user?.totalPrice) : "-"}
                  </p>
                </td>
                <td className="px-3 py-4">
                  <span className=" font-md font-Inter font-normal text-white whitespace-nowrap bg-green px-2 py-1 rounded-2xl">
                    {ORDER_STATUS[user?.status]}
                  </span>
                </td>
                <td className="p-1">
                  <div className="flex justify-center">
                    <button
                      onClick={() =>
                        router.push(
                          `/dashboard/booking/current/view?_id=${user?.id}`
                        )
                      }
                      className="rounded-full bg-light-grey"
                    >
                      <Image src={view} alt="view" />
                    </button>
                  </div>
                </td>
              </tr>
            );
          })
        ) : (
          <tr className="text-center">
            <td
              colSpan={12}
              className="font-Inter font-normal px-4 py-3 font-lg text-center"
            >
              No records found !!!
            </td>
          </tr>
        )}
      </TableWrapper>
      {userData.length > 0 && (
        <Pagination
          pageMeta={pageMeta}
          page={page}
          rowsPerPage={rowsPerPage}
          handlePageChange={({ value }: any) => {
            router.push({
              pathname: router.pathname,
              query: { ...router.query, page: value.toString() },
            });
            setPage(value);
          }}
          handleSizeChange={({ value }: any) => setRowsPerPage(value)}
          handleNextPage={() => {
            if (pageMeta?.totalPages && page < pageMeta.totalPages) {
              const nextPage = page + 1;
              router.push({
                pathname: router.pathname,
                query: { ...router.query, page: nextPage.toString() },
              });
              setPage(nextPage);
            }
          }}
          handlePrevPage={() => {
            const prevPage = page > 1 ? page - 1 : 1;
            router.push({
              pathname: router.pathname,
              query: { ...router.query, page: prevPage.toString() },
            });
            setPage(prevPage);
          }}
        />
      )}
    </>
  );
};

const mapDispatchToProps = (dispatch: any) => {
  return bindActionCreators(
    { getBookingListApi, UserDeleteApi, UserUpdateStatusApi },
    dispatch
  );
};
export default connect(null, mapDispatchToProps)(BookingCurrent);

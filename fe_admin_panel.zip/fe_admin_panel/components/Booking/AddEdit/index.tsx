import { NormalInput } from "@/components/common/Inputs/NormalInput";
import { NormalSelect } from "@/components/common/Inputs/NormalSelect";
import { useForm, FormProvider } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import { UserFormValues } from "@/types/Admin";
import { userSchema } from "@/validations/web.schema";
import { useRouter } from "next/router";
import { ButtonContainer } from "@/components/common/ButtonContainer";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import { DatePicker } from "@/components/common/DatePicker";
import { genderOptions } from "@/helpers/constants";

const resetData = () => ({
  username: "",
  email: "",
  mobile: "",
  gender: "",
  profilePicture: "",
  streetName: "",
  city: "",
  country: "",
  zipCode: "",
});

const BookingAddEdit = () => {
  const router = useRouter();
  const { slug = "" } = router.query;
  const methods = useForm<UserFormValues>({
    defaultValues: {
      ...resetData(),
    },
    resolver: yupResolver(userSchema),
  });

  const onSubmit = () => {};

  return (
    <FormProvider {...methods}>
      <form onSubmit={methods.handleSubmit(onSubmit)}>
        <div className="mb-5 text-primary_color text-xl font-semibold font-Inter">
          User Details
        </div>
        <div className="grid grid-row md:grid-col md:grid-cols-2 lg:grid-cols-3 md:gap-x-20 gap-y-8">
          <NormalSelect
            options={genderOptions}
            placeholder="Please Select User Name"
            label="User Name"
            name="userName"
            isrequired={true}
          />
          <NormalInput
            name="mobile"
            type="number"
            label="Phone Number"
            placeholder="Please Enter Your Phone Number"
            isrequired={true}
            error={methods.formState.errors.mobile?.message}
          />
          <NormalSelect
            options={genderOptions}
            placeholder="Please Select Category"
            label="Category"
            name="category"
            isrequired={true}
          />
          <NormalInput
            name="quantity"
            type="number"
            label="Quantity"
            placeholder="Please Enter Your Quantity"
            isrequired={true}
          />
          <DatePicker
            name="date"
            type="date"
            label="Date"
            isrequired={true}
            placeholder="Enter select date"
          />
          <NormalSelect
            options={genderOptions}
            placeholder="Please Select Location"
            label="Location"
            name="location"
            isrequired={true}
          />
        </div>
        <div className="border-grey-line border-b mt-32 mb-5" />
        <ButtonContainer
          labelLeft="cancel"
          labelRight={<div>{router.query.slug} booking</div>}
          handleClose={() => {
            slug[0] == "add"
              ? methods.reset({ ...resetData() })
              : router.back();
          }}
          btnType="submit"
        />
      </form>
    </FormProvider>
  );
};

const mapDispatchToProps = (dispatch: any) => {
  return bindActionCreators({}, dispatch);
};
export default connect(null, mapDispatchToProps)(BookingAddEdit);

import { useRouter } from "next/router";
import { useEffect, useState } from "react";
import { DeleteModal } from "@/components/common/DeleteModal";
import TableWrapper from "@/components/common/TableWrapper";
import Pagination from "@/components/common/Pagination";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import { UserDeleteApi } from "@/redux/actions/UserApiAct";
import { PageMeta } from "@/types/common";
import { ORDER_STATUS, bookingRequestHeader } from "@/helpers/constants";
import remove from "@/assets/svg/remove_icon.svg";
import view from "@/assets/svg/view_icon.svg";
import Image from "next/image";
import moment from "moment";
import {
  BookingStatusUpdateApi,
  getBookingListApi,
} from "@/redux/actions/BookingApiAct";
import { LoadingScreen } from "@/components/common/Loader";
import { getAddress } from "@/service/utilities";

const BookingRequest = ({ getBookingListApi, BookingStatusUpdateApi }: any) => {
  const [deleteModal, setDeleteModal] = useState(false);
  const router = useRouter();
  const [userData, setUserData] = useState([]);
  const [pageMeta, setPageMeta] = useState<PageMeta>();
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [page, setPage] = useState(1);
  const [id, setId] = useState("");
  const [loadingFetch, setLoadingFetch] = useState(true);
  const [permission, setPermission] = useState("");

  useEffect(() => {
    const storedPermission = localStorage.getItem("permission");
    if (storedPermission) {
      setPermission(storedPermission);
    }
  }, []);

  useEffect(() => {
    const queryPage = parseInt(router.query.page as string) || 1;
    setPage(queryPage);
  }, [router.query.page]);

  useEffect(() => {
    getRequestApiFunc();
  }, [page, rowsPerPage]);

  const getRequestApiFunc = () => {
    let query = {
      page: page,
      size: rowsPerPage,
      status: 0,
    };
    getBookingListApi(query)
      .then(({ data }: any) => {
        setUserData(data.list);
        setPageMeta(data.pageMeta);
        setLoadingFetch(false);
      })
      .catch((e: any) => {
        console.log(e);
      });
  };

  const handleOpen = (id: string) => {
    setId(id);
    setDeleteModal(true);
  };

  const handleDeleteModalSumbit = () => {
    let query = {
      id: id,
    };
    let body = {
      status: 3,
    };
    setLoadingFetch(true);
    BookingStatusUpdateApi(body, query)
      .then(({ data }: any) => {
        getRequestApiFunc();
        setDeleteModal(false);
      })
      .catch((e: any) => {
        console.log(e);
        setLoadingFetch(false);
      });
  };

  return (
    <>
      {loadingFetch && <LoadingScreen />}
      <TableWrapper
        headers={bookingRequestHeader}
        listData={userData}
        isStatus={true}
        isAction={true}
        isActionClass={"text-center"}
      >
        {userData?.length !== 0 ? (
          userData?.map((user: any, index: number) => {
            return (
              <tr
                key={user?.id}
                className="bg-white border-b  hover:bg-gray-50"
              >
                <td className="px-4 py-3">
                  <p className="w-20 break-all font-xl font-Inter font-normal text-grey">
                    {user?.username || "N/A"}
                  </p>
                </td>
                <td className="px-4 py-3">
                  <div className="has-tooltip">
                    <span className="tooltip max-w-64 rounded shadow-lg p-1 bg-gray-100 text-primary_color  -mt-8">
                      {user?.pickupAddress || "N/A"}
                    </span>
                    <p className="w-32 break-all font-xl font-Inter font-normal text-grey">
                      {getAddress(user?.pickupAddress)}
                    </p>
                  </div>
                </td>
                <td className="px-4 py-3">
                  <div className="has-tooltip">
                    <span className="tooltip max-w-60 rounded shadow-lg p-1 bg-gray-100 text-primary_color -mt-8">
                      {user?.dropAddress || "N/A"}
                    </span>
                    <p className=" w-32 break-all font-xl font-Inter font-normal text-grey">
                      {getAddress(user?.dropAddress)}
                    </p>
                  </div>
                </td>
                <td className="px-4 py-3 text-center">
                  <p className=" font-xl font-Inter font-normal text-grey whitespace-nowrap">
                    {moment(user?.pickupDateTime).utc().format("DD/MM/YYYY") ||
                      "N/A"}
                  </p>
                  <p className=" font-xl font-Inter font-normal text-grey whitespace-nowrap">
                    {moment(user?.pickupDateTime).utc().format("LT") || "N/A"}
                  </p>
                </td>
                <td className="px-4 py-3">
                  <p className="w-24 break-all font-xl font-Inter font-normal text-grey">
                    {user?.vehicleLoadTypeName || "N/A"}
                  </p>
                </td>
                <td className="px-4 py-3 text-center">
                  <p className=" font-xl font-Inter font-normal text-grey whitespace-nowrap">
                    {moment(user?.createdAt).format("DD/MM/YYYY") || "N/A"}
                  </p>
                  <p className=" font-xl font-Inter font-normal text-grey whitespace-nowrap">
                    {moment(user?.createdAt).format("LT") || "N/A"}
                  </p>
                  <p>{moment(user?.createdAt).fromNow()}</p>
                </td>
                <td className="px-6 py-3">
                  <p className=" font-xl font-Inter font-normal text-grey">
                    {user?.advanceAmount ? parseInt(user?.advanceAmount) : "-"}{" "}
                    / {"-"}
                  </p>
                </td>
                <td className="px-2 py-4">
                  <span className=" font-md font-Inter font-normal text-white whitespace-nowrap bg-yellow px-2 py-1 rounded-2xl">
                    {ORDER_STATUS[user?.status]}
                  </span>
                </td>
                <td className="">
                  <div className="flex justify-between gap-1">
                    <button
                      onClick={() =>
                        router.push(
                          `/dashboard/booking/details/view?_id=${user?.id}`
                        )
                      }
                      className=""
                    >
                      <Image src={view} alt="view" />
                    </button>
                    <button
                      className="cursor-pointer w-14 text-center font-Inter text-secondary_color bg-light-grey py-1"
                      onClick={() => {
                        router.push(
                          `/dashboard/booking/details/view?_id=${user?.id}&assign=true`
                        );
                      }}
                    >
                      Assign Owner
                    </button>
                    {permission == "Super Admin" &&
                      <button onClick={() => handleOpen(user?.id)} className="">
                        <Image src={remove} alt="trash" />
                      </button>
                    }
                  </div>
                </td>
              </tr>
            );
          })
        ) : (
          <tr className="text-center">
            <td
              colSpan={12}
              className="font-Inter font-normal px-4 py-3 font-lg text-center"
            >
              No records found !!!
            </td>
          </tr>
        )}
      </TableWrapper>
      {userData.length > 0 && (
        <Pagination
          pageMeta={pageMeta}
          page={page}
          rowsPerPage={rowsPerPage}
          handlePageChange={({ value }: any) => {
            router.push({
              pathname: router.pathname,
              query: { ...router.query, page: value.toString() },
            });
            setPage(value);
          }}
          handleSizeChange={({ value }: any) => setRowsPerPage(value)}
          handleNextPage={() => {
            if (pageMeta?.totalPages && page < pageMeta.totalPages) {
              const nextPage = page + 1;
              router.push({
                pathname: router.pathname,
                query: { ...router.query, page: nextPage.toString() },
              });
              setPage(nextPage);
            }
          }}
          handlePrevPage={() => {
            const prevPage = page > 1 ? page - 1 : 1;
            router.push({
              pathname: router.pathname,
              query: { ...router.query, page: prevPage.toString() },
            });
            setPage(prevPage);
          }}
        />
      )}
      {deleteModal === true && (
        <DeleteModal
          title="Are you Sure?"
          success="Are you sure you want to cancel booking request?"
          handleModalClose={() => {
            setDeleteModal(false);
          }}
          handleModalSubmit={handleDeleteModalSumbit}
        />
      )}
    </>
  );
};

const mapDispatchToProps = (dispatch: any) => {
  return bindActionCreators(
    { getBookingListApi, UserDeleteApi, BookingStatusUpdateApi },
    dispatch
  );
};
export default connect(null, mapDispatchToProps)(BookingRequest);

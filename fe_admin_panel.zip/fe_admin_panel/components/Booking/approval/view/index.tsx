import { useRouter } from "next/router";
import React, { useState, useCallback, useEffect } from "react";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import { PageMeta } from "@/types/common";
import {
  BookingAssignOwnerApi,
  getBookingById,
} from "@/redux/actions/BookingApiAct";
import moment from "moment";
import TableWrapper from "@/components/common/TableWrapper";
import {
  ORDER_STATUS,
  PAYMENT_STATUS,
  bookingOwnerHeader,
} from "@/helpers/constants";
import { NormalButton } from "@/components/common/Inputs/NormalButton";
import Pagination from "@/components/common/Pagination";
import { AddPopup } from "@/components/common/AddModal";
import { TitleCard } from "@/components/common/TitleCard";
import { getServiceableOwnersList } from "@/redux/actions/OwnerApiAct";
import Image from "next/image";
import remove from "@/assets/svg/remove_icon.svg";
import { DeleteModal } from "@/components/common/DeleteModal";
import { LoadingScreen } from "@/components/common/Loader";
import { formatAmount, getAddress } from "@/service/utilities";

const formatDateTime = (dateTime: any, utcOff: boolean = false ) => {
  if (!dateTime) return "";
  if(utcOff){
    return moment(dateTime).utcOffset(dateTime).format("DD/MM/YYYY LT");
  }else{
    return moment(dateTime).format("DD/MM/YYYY LT");
  }
};
const formatDate = (date: any) => {
  if (!date) return "N/A";
  return moment(date).format("DD/MM/YYYY");
};

const OrderDetailsTable = ({ userData, leadView }: any) => {

  return (
    <table className="border-collapse border border-solid border-gray-400 h-full w-full">
      <tbody>
        <tr>
          <th className="px-4 pt-4 text-start">Status:</th>
          <td className="px-4 pt-4">{ORDER_STATUS[userData?.status]}</td>
        </tr>
        {leadView ? (
          <tr>
            <th className="px-4 pt-4 text-start">Truck Type:</th>
            <td className="px-4 pt-4">
              {userData?.vehicleLoadTypeName || "-"}
            </td>
          </tr>
        ) : (
          <tr>
            <th className="px-4 pt-4 text-start">Amount paid:</th>
            <td className="px-4 pt-4">
              {formatAmount(userData?.advanceAmount)}/
              {formatAmount(userData?.totalPrice)}
            </td>
          </tr>
        )}

        <tr>
          <th className="px-4 pt-4 text-start">Picup Date & Time:</th>
          <td className="px-4 pt-4">
            {formatDateTime(userData?.pickupDateTime, true)}
          </td>
        </tr>
        <tr>
          <th className="px-4 pt-4 text-start">Pickup Location:</th>
          <td className="px-4 pt-4 w-96">
            <div className="has-tooltip font-Inter font-lg">
              <span className="tooltip max-w-60 rounded shadow-lg p-1 bg-gray-100 text-primary_color -mt-8">
                {userData?.pickupAddress || "-"}
              </span>
              <p className="break-all font-xl font-Inter font-normal text-grey">
                {getAddress(userData?.pickupAddress)}
              </p>
            </div>
          </td>
        </tr>
        <tr>
          <th className="px-4 py-4 text-start">Drop Location:</th>
          <td className="px-4 py-4 w-96">
            <div className="has-tooltip font-Inter font-lg">
              <span className="tooltip max-w-60 rounded shadow-lg p-1 bg-gray-100 text-primary_color -mt-8">
                {userData?.dropAddress || "-"}
              </span>
              <p className="break-all font-xl font-Inter font-normal text-grey">
                {getAddress(userData?.dropAddress)}
              </p>
            </div>
          </td>
        </tr>
      </tbody>
    </table>
  );
};

const ApprovalView = ({
  getBookingById,
  BookingAssignOwnerApi,
  getServiceableOwnersList,
  assignView,
  cancelledView,
  leadView,
}: any) => {
  const router = useRouter();
  const { _id = "" } = router.query;
  const [userData, setUserData] = useState(null);
  const [ownerData, setOwnerData] = useState([]);
  const [pageMeta, setPageMeta] = useState<PageMeta>();
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [page, setPage] = useState(1);
  const [popUp, setPopUp] = useState<boolean>(false);
  const [isSented, setIsSented] = useState(false);
  const [searchValue, setSearchValue] = useState("");
  const [deleteModal, setDeleteModal] = useState(false);
  const [id, setId] = useState("");
  const [loadingFetch, setLoadingFetch] = useState(true);

  const getBookingDetailsByID = useCallback(async () => {
    if (_id) {
      const { data } = await getBookingById(_id);

      setUserData(data);
      setIsSented(data?.ownerId);
      setLoadingFetch(false);
    }
  }, [_id]);
  const getOwnerListApiFunc = useCallback(
    (search: string = "") => {
      let query = {
        page: search ? 1 : page,
        size: rowsPerPage,
        search,
      };
      if (_id) {
        getServiceableOwnersList(_id, query)
          .then(({ data }: any) => {
            setOwnerData(data.list);
            setPageMeta(data.pageMeta);
            setLoadingFetch(false);
          })
          .catch((e: any) => {
            console.log(e);
          });
      }
    },
    [getServiceableOwnersList, page, rowsPerPage, _id]
  );
  useEffect(() => {
    if (_id) {
      getBookingDetailsByID();
      getOwnerListApiFunc();
    }
  }, [_id]);

  const handleOpen = (id: string) => {
    setId(id);
    setDeleteModal(true);
  };

  const handleSearch = () => {
    if (searchValue.length > 0) {
      setLoadingFetch(true);
      getOwnerListApiFunc(searchValue);
    }
  };

  const handleEmptySearch = () => {
    setSearchValue("");
    setLoadingFetch(true);
    getOwnerListApiFunc("");
  };

  useEffect(() => {
    getOwnerListApiFunc();
  }, [getOwnerListApiFunc]);

  const StatusUpdate = (ownerId: string) => {
    setIsSented(true);
    let body = {
      id: _id,
      ownerId,
      status: 1,
    };
    setLoadingFetch(true);
    BookingAssignOwnerApi(body)
      .then(({ data }: any) => {
        setPopUp(true);
        getBookingDetailsByID();
        setTimeout(() => {
          setPopUp(false);
        }, 1000);
      })
      .catch((e: any) => {
        console.log(e);
        setIsSented(false);
        setLoadingFetch(false);
      });
  };

  const handleDeleteModalSumbit = () => {
    let body = {
      id: _id,
      ownerId: id,
      status: 2,
    };
    setLoadingFetch(true);
    BookingAssignOwnerApi(body)
      .then(({ data }: any) => {
        setDeleteModal(true);
        getBookingDetailsByID();
        setTimeout(() => {
          setDeleteModal(false);
        }, 1000);
      })
      .catch((e: any) => {
        console.log(e);
        setDeleteModal(false);
        setLoadingFetch(false);
      });
  };

  return (
    <>
      {loadingFetch && <LoadingScreen />}
      <h3 className="text-primary_color font-Inter capitalize flex items-center text-xl font-extrabold mb-2 mt-2">
        Booking Details
      </h3>
      <div className="gap-5 grid grid-cols-1 md:grid-cols-2">
        <div>
          <table className="border-collapse border border-solid border-gray-400 h-full w-full">
            <tbody>
              {!leadView && (
                <tr>
                  <th className="px-4 pt-4 text-start">Order ID:</th>
                  <td className="px-4 pt-4">
                    {(userData as any)?.orderId || "-"}
                  </td>
                </tr>
              )}
              <tr>
                <th className="px-4 pt-4 text-start"> Customer Name:</th>
                <td className="px-4 pt-4">
                  {(userData as any)?.username || "-"}
                </td>
              </tr>
              <tr>
                <th className="px-4 pt-4 text-start">Contact Number:</th>
                <td className="px-4 pt-4">
                  {(userData as any)?.receiverMobile || "-"}
                </td>
              </tr>
              {!leadView && (
                <tr>
                  <th className="px-4 pt-4 text-start">
                    {leadView ? "Time Stamp: " : "Order Date & Time:"}
                  </th>
                  <td className="px-4 pt-4">
                    {formatDateTime((userData as any)?.createdAt)}
                  </td>
                </tr>
              )}
              <tr>
                <th className="px-4 py-4 text-start">Load Type:</th>
                <td className="px-4 py-4">
                  {(userData as any)?.vehicleLoadTypeName || "-"}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        <div>
          <OrderDetailsTable userData={userData} leadView={leadView} />
        </div>
      </div>
      {assignView && (
        <>
          <div className="mb-5 mt-8">
            <TitleCard
              title="Available Owners"
              searchText="Search by name..."
              placeholder="Filter by"
              value={searchValue}
              onChange={({
                target: { value },
              }: React.ChangeEvent<HTMLInputElement>) => setSearchValue(value)}
              onButtonClick={() => handleSearch()}
              onSearchClear={handleEmptySearch}
            />
          </div>
          <TableWrapper isStatus={true} headers={bookingOwnerHeader}>
            {(ownerData as any)?.length > 0 ? (
              (ownerData as any)?.map((a: any, index: number) => {
                return (
                  <tr
                    key={a?.id}
                    className="bg-white border-b  hover:bg-gray-50"
                  >
                    <td className="px-4 py-3">
                      <p className=" font-xl font-Inter font-normal text-grey whitespace-nowrap">
                        {a.fName}
                      </p>
                    </td>
                    <td className="px-6 py-3">
                      <p className=" font-xl font-Inter font-normal text-grey whitespace-nowrap">
                        {a?.companyName || "-"}
                      </p>
                    </td>
                    <td className="px-4 py-3">
                      <p className=" font-xl font-Inter font-normal text-grey whitespace-nowrap">
                        {a.mobile}
                      </p>
                    </td>
                    <td className="px-4 py-3">
                      <p className=" font-xl font-Inter font-normal text-grey whitespace-nowrap">
                        {a.email || "-"}
                      </p>
                    </td>
                    <td className="px-3 py-4">
                      <span
                        className={`font-xl font-Inter font-normal text-white whitespace-nowrap ${
                          a?.status ? "bg-green" : "bg-red-500"
                        } px-4 py-2 rounded-2xl`}
                      >
                        {a?.status ? "Active" : "Inactive"}
                      </span>
                    </td>
                    <td>
                      {a.id == (userData as any)?.ownerId ? (
                        <div className="flex flex-row gap-5">
                          <p className=" font-xl font-Inter mt-2 font-normal text-grey whitespace-nowrap capitalize">
                            Waiting for Approval
                          </p>
                          <div className="group flex relative">
                            <button
                              onClick={() => handleOpen(a?.id)}
                              className="rounded-full bg-light-grey p-1"
                            >
                              <Image src={remove} alt="trash" />
                            </button>
                            <div
                              className="group-hover:opacity-100 transition-opacity bg-light-grey px-2  text-sm text-gray-black rounded-md 
                          absolute left-1/2 -translate-x-1/2 translate-y-full opacity-0 m-4 mx-auto"
                            >
                              Cancelled
                            </div>
                          </div>
                        </div>
                      ) : (
                        <NormalButton
                          handleClick={() => StatusUpdate(a?.id)}
                          title={"Assign"}
                          isDisabled={isSented}
                          inputStyles="bg-primary_color border-2 border-white text-white capitalize text-md p-2 px-8"
                        />
                      )}
                    </td>
                  </tr>
                );
              })
            ) : (
              <tr className="bg-white border-b  hover:bg-gray-50">
                <td
                  colSpan={8}
                  className="font-normal px-4 py-3 font-lg text-center"
                >
                  No Data found !!!
                </td>
              </tr>
            )}
          </TableWrapper>
          {(ownerData as any)?.length > 0 && (
            <Pagination
              pageMeta={pageMeta}
              page={page}
              rowsPerPage={rowsPerPage}
              handlePageChange={({ value }: any) => setPage(value)}
              handleSizeChange={({ value }: any) => setRowsPerPage(value)}
              handleNextPage={() => {
                pageMeta?.totalPages &&
                  (pageMeta?.totalPages > page
                    ? setPage(page + 1)
                    : setPage(pageMeta?.totalPages));
              }}
              handlePrevPage={() => {
                setPage(page > 1 ? page - 1 : 1);
              }}
            />
          )}
          {popUp && (
            <AddPopup
              title={"Assigned Owner!"}
              success={"waiting for approval from Owner."}
            />
          )}
          {deleteModal === true && (
            <DeleteModal
              title="Are you Sure?"
              success="Are you sure you want to cancel Owner request?"
              handleModalClose={() => {
                setDeleteModal(false);
              }}
              handleModalSubmit={handleDeleteModalSumbit}
            />
          )}
        </>
      )}
      {cancelledView && (
        <>
          <h3 className="text-primary_color font-Inter capitalize flex items-center text-xl font-extrabold mb-2 mt-4">
            Cancelled Details
          </h3>
          <div className="gap-5 grid grid-cols-1 md:grid-cols-2 mb-20">
            <div>
              <table className="border-collapse border border-solid border-gray-400 h-full w-full">
                <tbody>
                  <tr>
                    <th className="px-4 pt-4 text-start">Cancelled by:</th>
                    <td className="px-4 pt-4">
                      {(userData as any)?.cancelledByName || "-"}
                    </td>
                  </tr>

                  <tr>
                    <th className="px-4 pt-4 text-start">
                      Reason for Cancelled:
                    </th>
                    <td className="px-4 pt-4">
                      <div className="has-tooltip font-Inter font-lg">
                        <span className="tooltip max-w-60 rounded shadow-lg p-1 bg-gray-100 text-primary_color -mt-8">
                          {(userData as any)?.cancelReason || "-"}
                        </span>
                        <p className="break-all font-xl font-Inter font-normal text-grey">
                          {(userData as any)?.cancelReason?.length > 40
                            ? `${(userData as any)?.cancelReason?.slice(
                                0,
                                40
                              )}...`
                            : (userData as any)?.cancelReason || "N/A"}
                        </p>
                      </div>
                    </td>
                  </tr>
                  <tr>
                    <th className="px-4 pt-4 text-start">Amount paid:</th>
                    <td className="px-4 pt-4">
                      {(userData as any)?.advanceAmount
                        ? parseInt((userData as any)?.advanceAmount)
                        : "-"}
                      /
                      {(userData as any)?.totalPrice
                        ? parseInt((userData as any)?.totalPrice)
                        : "-"}
                    </td>
                  </tr>
                  <tr>
                    <th className="px-4 pt-4 text-start">Refund status:</th>
                    <td className="px-4 pt-4">
                      {PAYMENT_STATUS[(userData as any)?.paymentStatus]}
                    </td>
                  </tr>
                  <tr>
                    <th className="px-4 py-4 text-start">Cancelled Date:</th>
                    <td className="px-4 py-4">
                      {formatDate((userData as any)?.cancelledDate)}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </>
  );
};

const mapDispatchToProps = (dispatch: any) => {
  return bindActionCreators(
    { getBookingById, BookingAssignOwnerApi, getServiceableOwnersList },
    dispatch
  );
};
export default connect(null, mapDispatchToProps)(ApprovalView);

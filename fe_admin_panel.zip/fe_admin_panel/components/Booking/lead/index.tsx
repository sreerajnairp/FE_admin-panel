import { useRouter } from "next/router";
import { useEffect, useState } from "react";
import { DeleteModal } from "@/components/common/DeleteModal";
import TableWrapper from "@/components/common/TableWrapper";
import Pagination from "@/components/common/Pagination";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import { UserDeleteApi, UserUpdateStatusApi } from "@/redux/actions/UserApiAct";
import { PageMeta } from "@/types/common";
import { ORDER_STATUS, bookingleadHeader } from "@/helpers/constants";
import view from "@/assets/svg/view_icon.svg";
import Image from "next/image";
import moment from "moment";
import {
  LeadDeleteApi,
  getBookingListApi,
} from "@/redux/actions/BookingApiAct";
import trash from "@/assets/icon/trash.svg";
import { LoadingScreen } from "@/components/common/Loader";

const BookingLeads = ({
  getBookingListApi,
  UserUpdateStatusApi,
  LeadDeleteApi,
}: any) => {
  const [deleteModal, setDeleteModal] = useState(false);
  const router = useRouter();
  const [userData, setUserData] = useState([]);
  const [pageMeta, setPageMeta] = useState<PageMeta>();
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [page, setPage] = useState(1);
  const [selected, setSelected] = useState<any>([]);
  const [allcheck, setAllcheck] = useState<boolean>(false);
  const [loadingFetch, setLoadingFetch] = useState(true);

  useEffect(() => {
    const queryPage = parseInt(router.query.page as string) || 1;
    setPage(queryPage);
  }, [router.query.page]);

  useEffect(() => {
    getHistoryApiFunc();
  }, [page, rowsPerPage]);

  const getHistoryApiFunc = () => {
    let query = {
      page: page,
      size: rowsPerPage,
      status: 8,
    };
    getBookingListApi(query)
      .then(({ data }: any) => {
        setUserData(data.list);
        setPageMeta(data.pageMeta);
        setLoadingFetch(false);
      })
      .catch((e: any) => {
        console.log(e);
      });
  };

  const handleOpen = () => {
    setDeleteModal(true);
  };

  const handleDeleteModalSumbit = () => {
    let body = {
      id: [].concat(...selected),
    };
    setLoadingFetch(true);
    LeadDeleteApi(body)
      .then(({ data }: any) => {
        getHistoryApiFunc();
        setSelected([]);
        setAllcheck(false);
        setDeleteModal(false);
      })
      .catch((e: any) => {
        console.log(e);
        setLoadingFetch(false);
      });
  };

  const selectAll = (value: boolean) => {
    setAllcheck(value);
    if (value) {
      const selectedIds = userData.map((user: any) => user.id);
      setSelected(selectedIds);
    } else {
      setSelected([]);
    }
  };

  const handleSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const id = event.target.name;
    const checked = event.target.checked;

    if (checked) {
      setSelected([...selected, id]);
    } else {
      setSelected(selected.filter((item: any) => item !== id));
    }
    const allChecked = userData.every((user: any) =>
      selected.includes(user.id)
    );
    setAllcheck(allChecked);
  };

  return (
    <>
      {loadingFetch && <LoadingScreen />}
      <div className="flex  justify-end">
        {selected?.length > 0 ? (
          <button
            onClick={() => handleOpen()}
            className={`custom-btn hover:opacity-80 flex rounded-lg disabled:opacity-60 bg-white border-2 border-secondary_color text-secondary_color capitalize text-md p-2 px-5 md:text-lg`}
          >
            Delete <Image className="m-1" src={trash} alt="trash" />
          </button>
        ) : (
          ""
        )}
      </div>
      <TableWrapper
        headers={bookingleadHeader}
        listData={userData}
        checkbox={true}
        onCheckAll={selectAll}
        allcheck={allcheck}
        isStatus={true}
        isAction={true}
      >
        {userData?.length !== 0 ? (
          userData?.map((user: any, index: number) => {
            return (
              <tr
                key={user?.id}
                className="bg-white border-b  hover:bg-gray-50"
              >
                <td className="p-4">
                  <div className="flex items-center">
                    <input
                      id={user?.id}
                      name={user?.id}
                      checked={selected.includes(user?.id)}
                      onChange={(e) => handleSelect(e)}
                      type="checkbox"
                      className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500 dark:focus:ring-blue-600   focus:ring-2  "
                    />
                    <label className="sr-only" htmlFor={user?.id}>
                      checkbox
                    </label>
                  </div>
                </td>
                {/* <td className="px-4 py-3">
                  <p className=" font-xl font-Inter font-normal text-grey whitespace-nowrap">
                    {(page - 1) * rowsPerPage + index + 1}
                  </p>
                </td> */}
                <td className="px-4 py-3">
                  <p className=" font-xl font-Inter font-normal text-grey whitespace-nowrap ">
                    {user?.username || "N/A"}
                  </p>
                </td>
                <td className="px-4 py-3">
                  <div className="has-tooltip">
                    <span className="tooltip max-w-60 rounded shadow-lg p-1 bg-gray-100 text-primary_color -mt-8">
                      {user?.pickupAddress || "-"}
                    </span>
                    <p className=" w-32 break-all font-xl font-Inter font-normal text-grey">
                      {user?.pickupAddress?.length > 40
                        ? `${user?.pickupAddress.slice(0, 40)}...`
                        : user?.pickupAddress || "N/A"}
                    </p>
                  </div>
                </td>
                <td className="px-4 py-3">
                  <div className="has-tooltip">
                    <span className="tooltip max-w-60 rounded shadow-lg p-1 bg-gray-100 text-primary_color -mt-8">
                      {user?.dropAddress || "-"}
                    </span>
                    <p className=" w-32 break-all font-xl font-Inter font-normal text-grey">
                      {user?.dropAddress?.length > 40
                        ? `${user?.dropAddress.slice(0, 40)}...`
                        : user?.dropAddress || "N/A"}
                    </p>
                  </div>
                </td>
                <td className="px-4 py-3 text-center">
                  <p className=" font-xl font-Inter font-normal text-grey whitespace-nowrap">
                    {moment(user?.pickupDateTime)
                      .utcOffset(user?.pickupDateTime)
                      .format("DD/MM/YYYY") || "N/A"}
                  </p>
                  <p className=" font-xl font-Inter font-normal text-grey whitespace-nowrap">
                    {moment(user?.pickupDateTime)
                      .utcOffset(user?.pickupDateTime)
                      .format("LT") || "N/A"}
                  </p>
                </td>
                <td className="px-4 py-3">
                  <p className=" font-xl font-Inter font-normal text-grey whitespace-nowrap ">
                    {user?.vehicleLoadTypeName || "N/A"}
                  </p>
                </td>
                <td className="px-4 py-3 text-center">
                  <p className=" font-xl font-Inter font-normal text-grey whitespace-nowrap ">
                    {moment(user?.createdAt).format("DD/MM/YYYY") || "N/A"}
                  </p>
                  <p className=" font-xl font-Inter font-normal text-grey whitespace-nowrap">
                    {moment(user?.createdAt).format("LT") || "N/A"}
                  </p>
                </td>
                <td className="px-3 py-4">
                  <span
                    className={`font-md font-Inter font-normal text-white whitespace-nowrap bg-primary_color px-2 py-1 rounded-2xl`}
                  >
                    {ORDER_STATUS[user?.status]}
                  </span>
                </td>
                <td className="p-1">
                  <div className="flex justify-center">
                    <button
                      onClick={() =>
                        router.push(
                          `/dashboard/booking/details/view?_id=${user?.id}&leadView=true`
                        )
                      }
                      className="rounded-full bg-light-grey"
                    >
                      <Image src={view} alt="view" />
                    </button>
                  </div>
                </td>
              </tr>
            );
          })
        ) : (
          <tr className="text-center">
            <td
              colSpan={12}
              className="font-Inter font-normal px-4 py-3 font-lg text-center"
            >
              No records found !!!
            </td>
          </tr>
        )}
      </TableWrapper>
      {userData.length > 0 && (
        <Pagination
          pageMeta={pageMeta}
          page={page}
          rowsPerPage={rowsPerPage}
          handlePageChange={({ value }: any) => {
            router.push({
              pathname: router.pathname,
              query: { ...router.query, page: value.toString() },
            });
            setPage(value);
          }}
          handleSizeChange={({ value }: any) => setRowsPerPage(value)}
          handleNextPage={() => {
            if (pageMeta?.totalPages && page < pageMeta.totalPages) {
              const nextPage = page + 1;
              router.push({
                pathname: router.pathname,
                query: { ...router.query, page: nextPage.toString() },
              });
              setPage(nextPage);
            }
          }}
          handlePrevPage={() => {
            const prevPage = page > 1 ? page - 1 : 1;
            router.push({
              pathname: router.pathname,
              query: { ...router.query, page: prevPage.toString() },
            });
            setPage(prevPage);
          }}
        />
      )}
      {deleteModal === true && (
        <DeleteModal
          title="Are you Sure?"
          success="Are you sure you want to delete the selected Items ?"
          handleModalClose={() => {
            setDeleteModal(false);
          }}
          handleModalSubmit={handleDeleteModalSumbit}
        />
      )}
    </>
  );
};

const mapDispatchToProps = (dispatch: any) => {
  return bindActionCreators(
    { getBookingListApi, UserDeleteApi, UserUpdateStatusApi, LeadDeleteApi },
    dispatch
  );
};
export default connect(null, mapDispatchToProps)(BookingLeads);

import { AddPopup } from "@/components/common/AddModal";
import { NormalInput } from "@/components/common/Inputs/NormalInput";
import { NormalSelect } from "@/components/common/Inputs/NormalSelect";
import { useForm, FormProvider } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import { EmployeeFormValues } from "@/types/Admin";
import { employeeSchema } from "@/validations/web.schema";
import { useRouter } from "next/router";
import { ButtonContainer } from "@/components/common/ButtonContainer";
import { useCallback, useEffect, useState } from "react";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import { FileUploadButton } from "@/components/common/ButtonUpload";
import {
  getCountryListApi,
  getCityListApi,
  ImageUploadApi,
  getServicableListApi,
  getCityByStateApi,
  getStatePermitApi,
} from "@/redux/actions/CommonApiAct";
import { Toast } from "@/service/toast";
import {
  EmployeeAddApi,
  EmployeeUpdateApi,
  getEmployeeById,
} from "@/redux/actions/EmployeeApiAct";
import { IDProofValue, IDoptions, genderOptions, roleOptions } from "@/helpers/constants";
import { LoadingScreen } from "@/components/common/Loader";
import { NormalMultiSelect } from "@/components/common/Inputs/NormalMultiSelect";
import TableMatrixUpload from "../TableUpload";

const resetData = () => ({
  username: "",
  email: "",
  mobile: "",
  gender: "",
  profilePic: null,
  role: "",
  idProofType: [],
  documents: [],
  streetName: "",
  city: null,
  country: "",
  state: null,
  zipCode: null,
});

const EmployeeAddEdit = ({
  getCountryListApi,
  getCityListApi,
  ImageUploadApi,
  EmployeeAddApi,
  EmployeeUpdateApi,
  getEmployeeById,
  getServicableListApi,
  getStatePermitApi,
  getCityByStateApi,
}: any) => {
  const router = useRouter();
  const [popUp, setPopUp] = useState<boolean>(false);
  const [userDetails, setUserDetails] = useState();
  const [isSent, setIsSent] = useState<boolean>(false);
  const [profileImage, setProfileImage] = useState<string>("");
  const [cityOptions, setCityOptions] = useState([]);
  const [countryOptions, setCountryOptions] = useState([]);
  const { _id = "", slug = "" } = router.query;
  const [loadingFetch, setLoadingFetch] = useState<boolean>(false);
  const [selectedState, setSelectedState] = useState([]);
  const [isOwnerStateMounted, setIsOwnerStateMounted] = useState(false);

  const methods = useForm<EmployeeFormValues>({
    defaultValues: {
      ...resetData(),
    },
    resolver: yupResolver(employeeSchema),
  });
  const IDproofSelect = methods.watch<any>("idProofType");
  const IDproofUpload = methods.watch<any>("documents");
  const getBaseFunc = (id: any) => {
    let query = {
      isGeneral: true,
      cityId: methods.getValues("city"),
    };
    getCityByStateApi(id, query).then(({ data }: any) => {
      setCityOptions(
        data?.list?.map((res: any) => {
          return {
            value: res.id,
            label: res.city,
          };
        })
      );
    });
  };

  const getstateFunc = () => {
    let query = {
      isGeneral: true,
      id: methods.getValues("state"),
    };
    getStatePermitApi(query).then(({ data }: any) => {
      const states = data?.list?.map((res: any) => {
        return {
          value: res.id,
          label: res.state,
        };
      });
      setSelectedState(states);
    });
  };

  useEffect(() => {
    getstateFunc();
  }, [methods.getValues("state")]);

  const getUserDetails = useCallback(async () => {
    if (_id) {
      setLoadingFetch(true);
      const { data } = await getEmployeeById(_id);
      setUserDetails(data);
      methods.reset({
        username: data?.username,
        email: data?.email,
        mobile: data?.mobile,
        gender: data?.gender,
        profilePic: data?.profilePic,
        role: data?.role,
        idProofType: data?.employeeDocuments.map((a: any) => parseInt(a.idProofType)),
        documents: data?.employeeDocuments,
        streetName: data?.streetName,
        city: data?.city,
        country: data?.country,
        state: data?.state,
        zipCode: data?.zipCode,
        status: data?.status,
      });
      setProfileImage(data?.profilePic);
      setLoadingFetch(false);
    }
  }, [_id]);
  useEffect(() => {
    if (_id) {
      getUserDetails();
    }
  }, [_id]);

  const getCountryDropDown = () => {
    getCountryListApi().then(({ data }: any) => {
      setCountryOptions(
        data?.map((res: any) => {
          return {
            value: res.name,
            label: res.name,
          };
        })
      );
    });
  };

  useEffect(() => {
    getCountryDropDown();
  }, []);

  const handleProfileUpload = async (e: any) => {
    methods.clearErrors("profilePic");
    let file = e.target.files[0];
    if (file) {
      const fileType = file.type;
      if (
        fileType === "image/jpeg" ||
        fileType === "image/jpg" ||
        fileType === "image/png" ||
        fileType === "image/webp"
      ) {
        const fileSizeInMB = file.size / (1024 * 1024);
        if (fileSizeInMB < 3) {
          const reader = new FileReader();
          reader.onload = (event) => {
            const previewUrl = event.target?.result as string;
            setProfileImage(previewUrl);
          };
          reader.readAsDataURL(file);
          methods.setValue("profilePic", file);
        } else {
          Toast({
            type: "error",
            message: "File Size should not exceed 3MB.",
          });
          e.target.value = "";
        }
      } else {
        Toast({
          type: "error",
          message: "Only JPEG, JPG and PNG files are allowed.",
        });
        e.target.value = "";
      }
    }
  };

  const validateDocuments = (data: any, filteredDocument: any) => {
    let hasError = false;

    if (data?.idProofType?.length !== filteredDocument?.length) {
      Toast({ type: "error", message: `Document is required` });
      hasError = true;
    }

    filteredDocument?.forEach((item: any) => {
      if (
        !item?.document ||
        item?.document?.length === 0 ||
        item?.document[0] === null
      ) {
        Toast({
          type: "error",
          message: `${IDProofValue[item?.idProofType]} document is required`,
        });
        hasError = true;
      }
    });

    return hasError;
  };

  const appendDocumentsToFormData = (
    formData: FormData,
    filteredDocument: any
  ) => {
    filteredDocument.forEach((item: any, index: number) => {
      if (item?.idProofType) {
        formData.append(`documents[${index}][idProofType]`, item.idProofType);
      }
      if (item?.document && Array.isArray(item?.document)) {
        item?.document.forEach((doc: any, docIndex: number) => {
          formData.append(`documents[${index}][document][${docIndex}]`, doc);
        });
      }
    });
  };

  const appendDataToFormData = (
    formData: FormData,
    data: any,
    filteredDocument: any
  ) => {
    Object.keys(data).forEach((key) => {
      if (data[key] !== null && data[key] !== undefined) {
        if (key === "documents" && Array.isArray(data[key])) {
          appendDocumentsToFormData(formData, filteredDocument);
        } else if (key !== "idProofType") {
          formData.append(key, data[key]);
        }
      }
    });
  };

  const onSubmit = async (data: any) => {
    setIsSent(true);
    setLoadingFetch(true);

    const formData = new FormData();
    const filteredDocument = data?.documents.filter((item: any) =>
      IDproofSelect.includes(parseInt(item?.idProofType))
    );

    const hasError = validateDocuments(data, filteredDocument);

    if (hasError) {
      setLoadingFetch(false);
      setIsSent(false);
      return;
    }

    appendDataToFormData(formData, data, filteredDocument);

    try {
      if (userDetails) {
        const query = { id: _id };
        formData.append("userId", (userDetails as any)?.userId);
        formData.append("userAddressId", (userDetails as any)?.userAddressId);
        await EmployeeUpdateApi(formData, query);
      } else {
        await EmployeeAddApi(formData);
      }
      setLoadingFetch(false);
      setIsSent(false);
      setPopUp(true);
      setTimeout(() => {
        router.push("/dashboard/employee");
      }, 2000);
    } catch (error) {
      console.log(error);
      setIsSent(false);
      setLoadingFetch(false);
    }
  };

  useEffect(() => {
    if (methods.getValues("state") && methods.watch("state")) {
      const id = methods.getValues("state");
      const stateID = id.value ? id.value : id;
      if (isOwnerStateMounted) {
        methods.setValue("city", null);
      } else {
        setIsOwnerStateMounted(true);
      }
      getBaseFunc(stateID);
    }
  }, [methods.getValues("state"), methods.watch("state")]);

  return (
    <FormProvider {...methods}>
      <form onSubmit={methods.handleSubmit(onSubmit)}>
        {loadingFetch && <LoadingScreen />}
        <div className="mb-5 text-primary_color text-xl font-semibold font-Inter">
          Employee Details
        </div>
        <div className="grid grid-row md:grid-col md:grid-cols-2 lg:grid-cols-3 md:gap-x-20 gap-y-8">
          <NormalInput
            name="username"
            type="text"
            label="Name"
            placeholder="Please Enter Name"
            isrequired={true}
            error={methods.formState.errors.username?.message}
          />
          <NormalInput
            name="email"
            type="email"
            label="Email Id"
            placeholder="Please Enter Email Id"
            isrequired={true}
            error={methods.formState.errors.email?.message}
          />
          <NormalInput
            name="mobile"
            type="number"
            label="Phone Number"
            placeholder="Please Enter Phone Number"
            isrequired={true}
            error={methods.formState.errors.mobile?.message}
          />
          <NormalSelect
            options={genderOptions}
            placeholder="Please Select Gender"
            label="Gender"
            name="gender"
            isrequired={true}
            error={methods.formState.errors.gender?.message}
          />
          <FileUploadButton
            id={"Profile Pic"}
            uploadImage={profileImage}
            onPerviewClose={() => {
              setProfileImage("");
              methods.setValue("profilePic", null);
            }}
            label={"Profile Pic"}
            placeholder="Please Upload Profile Pic"
            onFileSubmit={(e: any) => handleProfileUpload(e)}
            ImageSize={100}
            isrequired={false}
            error={methods.formState.errors.profilePic?.message}
          />
          <NormalSelect
            options={roleOptions}
            placeholder="Please Select Role"
            label="Role"
            name="role"
            isrequired={true}
            error={methods.formState.errors.role?.message}
          />
          <NormalMultiSelect
            placeholder="Please Select ID Proof"
            label="ID Proof"
            name="idProofType"
            options={IDoptions}
            isrequired={true}
            error={methods.formState.errors.idProofType?.message}
          />
        </div>
        <TableMatrixUpload
          key="price"
          title={"Upload Document"}
          IDproofSelect={IDproofSelect}
          IDproofOption={IDoptions}
          IDproofUpload={IDproofUpload}
          onDataChange={(value: any) => methods.setValue("documents", value)}
        />
        <div className="mb-5 mt-8 text-primary_color text-xl font-semibold font-Inter">
          Address Details
        </div>
        <div className="grid grid-row md:grid-col md:grid-cols-2 lg:grid-cols-3 md:gap-x-20 gap-y-8">
          <NormalInput
            name="streetName"
            type="text"
            label="Address"
            placeholder="Please Enter Address"
            isrequired={false}
            error={methods.formState.errors.streetName?.message}
          />
          <NormalSelect
            options={countryOptions}
            placeholder="Please Select Country"
            label="Country"
            name="country"
            isrequired={true}
            error={methods.formState.errors.country?.message}
          />
          <NormalSelect
            options={selectedState}
            placeholder="Please Select State"
            label="State"
            name="state"
            isrequired={true}
            error={methods.formState.errors.state?.message}
          />
          <NormalSelect
            options={cityOptions}
            placeholder="Please Select City / Town"
            label="City / Town"
            name="city"
            isrequired={true}
            error={methods.formState.errors.city?.message}
          />
          <NormalInput
            name="zipCode"
            type="number"
            label="Zip Code"
            placeholder="Please Enter Zip Code"
            isrequired={false}
            error={methods.formState.errors.zipCode?.message}
          />
        </div>
        <div className="border-grey-line border-b mt-32 mb-5" />
        <ButtonContainer
          labelLeft="cancel"
          labelRight={slug[0] == "add" ? "add employee" : "update"}
          handleClose={() => {
            router.push(`/dashboard/employee`);
          }}
          btnType="submit"
          isdisabledSubmit={isSent}
        />
        {popUp && (
          <AddPopup
            title={slug[0] == "add" ? "added!" : "updated!"}
            success={
              slug[0] == "add"
                ? "employee added successfully"
                : "employee Updated successfully"
            }
          />
        )}
      </form>
    </FormProvider>
  );
};

const mapDispatchToProps = (dispatch: any) => {
  return bindActionCreators(
    {
      getCountryListApi,
      getCityListApi,
      ImageUploadApi,
      EmployeeAddApi,
      EmployeeUpdateApi,
      getEmployeeById,
      getServicableListApi,
      getStatePermitApi,
      getCityByStateApi,
    },
    dispatch
  );
};
export default connect(null, mapDispatchToProps)(EmployeeAddEdit);

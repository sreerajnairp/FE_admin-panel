import { useRouter } from "next/router";
import { useCallback, useEffect, useState } from "react";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import Image from "next/image";
import {
  getEmployeeById,
  EmployeeResendEmailApi,
} from "@/redux/actions/EmployeeApiAct";
import {
  getCityListApi,
  getCountryListApi,
} from "@/redux/actions/CommonApiAct";
import { getImageSrc } from "@/service/utilities";
import { LoadingScreen } from "@/components/common/Loader";
import { IDProofValue } from "@/helpers/constants";

const EmployeeView = ({ getEmployeeById, EmployeeResendEmailApi }: any) => {
  const router = useRouter();
  const { _id = "" } = router.query;
  const [userDetails, setUserDetails] = useState();
  const [profilePicture, setProfilePicture] = useState("");
  const [loadingFetch, setLoadingFetch] = useState(true);
  const [isSented, setIsSented] = useState<boolean>(false);
  const getUserDetails = useCallback(async () => {
    if (_id) {
      const { data } = await getEmployeeById(_id);
      setUserDetails(data);
      setProfilePicture(data?.profilePic);
      setLoadingFetch(false);
    }
  }, [_id]);

  useEffect(() => {
    if (_id) {
      getUserDetails();
    }
  }, [_id]);

  const handleSendEmail = (id: string) => {
    let body = {
      id: id,
    };
    setIsSented(true);
    setLoadingFetch(true);
    EmployeeResendEmailApi(body)
      .then(({ data }: any) => {
        setLoadingFetch(false);
      })
      .catch((e: any) => {
        console.log(e);
        setIsSented(false);
        setLoadingFetch(false);
      });
  };

  const documentMap: {
    [key: string]: { document: string[] };
  } = {};

  ((userDetails as any)?.employeeDocuments || []).forEach(
    (imageDocument: any) => {
      if (!documentMap[imageDocument.idProofType]) {
        documentMap[imageDocument.idProofType] = { document: [] };
      }
      documentMap[imageDocument.idProofType].document.push(
        ...imageDocument.document
      );
    }
  );

  const groupedDocuments = Object.keys(documentMap).map((key) => ({
    idProofType: key,
    documents: documentMap[key].document,
  }));

  return (
    <>
      {loadingFetch && <LoadingScreen />}
      <div className="gap-5 gap-y-10 grid grid-cols-1  md:grid-cols-2 lg:grid-cols-3">
        <div>
          <h3 className="text-primary_color font-Inter capitalize flex items-center text-xl font-extrabold mb-2 mt-2">
            Employee Details
          </h3>
          <table className="border-collapse border border-solid border-gray-400 h-full w-full">
            <tbody>
              <tr>
                <th className="px-4 pt-4 text-start">Name:</th>
                <td className="px-4 pt-4">
                  {(userDetails as any)?.username || "-"}
                </td>
              </tr>
              <tr>
                <th className="px-4 pt-4 text-start">Role:</th>
                <td className="px-4 pt-4">
                  {(userDetails as any)?.role || "-"}
                </td>
              </tr>
              <tr>
                <th className="px-4 pt-4 text-start">Email:</th>
                <td className="px-4 pt-4">
                  {(userDetails as any)?.email || "-"}
                </td>
              </tr>
              <tr>
                <th className="px-4 pt-4 text-start">Mobile Number:</th>
                <td className="px-4 pt-4">
                  +91 {(userDetails as any)?.mobile || "-"}
                </td>
              </tr>
              <tr>
                <th className="px-4 py-4 text-start">Gender:</th>
                <td className="px-4 py-4">
                  {(userDetails as any)?.gender || "-"}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        <div className="mt-5 md:mt-0">
          <h3 className="text-primary_color font-Inter capitalize flex items-center text-xl font-extrabold mb-2 mt-2">
            Address
          </h3>
          <table className="border-collapse border border-solid border-gray-400  h-full w-full">
            <tbody>
              <tr>
                <th className="px-4 pt-4 text-start">Address:</th>
                <td className="px-4 pt-4">
                  {(userDetails as any)?.streetName || "-"}
                </td>
              </tr>
              <tr>
                <th className="px-4 pt-4 text-start">Country:</th>
                <td className="px-4 pt-4">
                  {(userDetails as any)?.country || "-"}
                </td>
              </tr>
              <tr>
                <th className="px-4 pt-4 text-start">State:</th>
                <td className="px-4 pt-4">
                  {(userDetails as any)?.stateName || "-"}
                </td>
              </tr>
              <tr>
                <th className="px-4 pt-4 text-start">City:</th>
                <td className="px-4 pt-4">
                  {(userDetails as any)?.cityName || "-"}
                </td>
              </tr>
              <tr>
                <th className="px-4 py-4 text-start">Zip Code:</th>
                <td className="px-4 py-4">
                  {(userDetails as any)?.zipCode || "-"}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        <div className="mt-5 md:mt-0">
          <h3 className="text-primary_color font-Inter capitalize flex items-center text-xl font-extrabold mb-2 mt-2">
            Profile Pic
          </h3>
          <table
            aria-hidden="true"
            className="border-collapse w-full h-full border border-solid border-gray-400"
          >
            <tbody>
              <tr>
                <td className="p-4">
                  {profilePicture ? (
                    <a
                      className="rounded-md  flex justify-center"
                      href={profilePicture}
                      target="_blank"
                      style={{ marginLeft: "10px" }}
                    >
                      <Image
                        src={getImageSrc(profilePicture)}
                        alt="doc"
                        width={100}
                        height={100}
                      />
                    </a>
                  ) : (
                    "Profile Pic not uploaded"
                  )}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
      {(userDetails as any)?.employeeDocuments.length > 0 ? (
        <>
          <h3 className="text-primary_colsor font-Inter capitalize flex items-center text-xl font-extrabold mb-2 mt-16">
            Documents
          </h3>
          <div className="gap-5 grid grid-cols-1 md:grid-cols-2 mt-2">
            {groupedDocuments.map((groupImages, index) => (
              <div key={index}>
                <table className="border-collapse border border-solid border-gray-400 h-full w-full">
                  <tbody>
                    <tr key={groupImages.idProofType}>
                      <th scope="row" className="px-4 py-3 text-start">
                        {IDProofValue[(groupImages as any)?.idProofType]}
                      </th>
                      <td className="gap-1 grid grid-cols-1 lg:grid-cols-2 place-items-end ">
                        {groupImages.documents
                          .filter((document) => document !== "null")
                          .map((document) => (
                            <a
                              key={document}
                              href={document}
                              target="_blank"
                              className="block p-2"
                            >
                              <div className="relative w-28 h-28 md:w-32 md:h-32">
                                <Image
                                  src={getImageSrc(document)}
                                  alt="doc"
                                  layout="fill"
                                  objectFit="cover"
                                  className="rounded"
                                />
                              </div>
                            </a>
                          ))}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            ))}
          </div>
        </>
      ) : (
        ""
      )}
      <div className="my-20">
        <button
          onClick={() => handleSendEmail((userDetails as any)?.id)}
          disabled={isSented}
          className="bg-primary_color text-white border rounded-md px-10 font-xl py-2 capitalize font-Inter disabled:opacity-60"
        >
          Employee Reset Password
        </button>
      </div>
    </>
  );
};

const mapDispatchToProps = (dispatch: any) => {
  return bindActionCreators(
    {
      getEmployeeById,
      getCityListApi,
      getCountryListApi,
      EmployeeResendEmailApi,
    },
    dispatch
  );
};
export default connect(null, mapDispatchToProps)(EmployeeView);

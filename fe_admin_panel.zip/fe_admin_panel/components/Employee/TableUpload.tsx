import React, { useEffect, useState } from "react";
import { FileUploadButton } from "../common/ButtonUpload";
import { Toast } from "@/service/toast";
import pdf from "@/assets/icon/pdf.svg";

const TableMatrixUpload = ({
  title,
  IDproofSelect,
  IDproofOption,
  IDproofUpload,
  onDataChange,
}: any) => {
  const [idProofList, setIDProofList] = useState<any>([]);
  const [data, setData] = useState<any>([]);

  useEffect(() => {
    setIDProofList(
      IDproofOption.filter((option: any) =>
        IDproofSelect?.includes(option.value)
      )
    );
  }, [IDproofSelect, IDproofOption]);

  useEffect(() => {
    if (IDproofUpload?.length || idProofList?.length) {
      const newData: any = idProofList.map((proof: any) => {
        const existingItem = IDproofUpload.find(
          (item: any) => item.idProofType == proof.value
        );
        const documents = existingItem ? existingItem.document : [null, null];
        const previews = existingItem ? existingItem.preview : [null, null];
        return {
          idProofType: proof.value,
          document: documents,
          preview: previews,
        };
      });
      setData(newData);
    }
  }, [IDproofUpload, idProofList]);

  const validateFile = (file: File) => {
    if (file) {
      const fileType = file.type;
      const fileSizeInMB = file.size / (1024 * 1024);
      if (
        fileType === "image/jpg" ||
        fileType === "image/jpeg" ||
        fileType === "image/png" ||
        fileType === "image/webp" ||
        fileType === "application/pdf"
      ) {
        if (fileSizeInMB < 3) {
          return null;
        } else {
          return "File size should not exceed 3MB.";
        }
      } else {
        return "Only JPG, JPEG, PDF and PNG files are allowed.";
      }
    }
  };

  const handleFileUpload = async (
    proofLabel: string,
    file: File,
    index: number
  ) => {
    const error = validateFile(file);
    const fileType = file.type;
    if (error) {
      Toast({ type: "error", message: error });
      return;
    }

    const newData = [...data];
    const proofIndex = newData.findIndex(
      (item) => item.idProofType === proofLabel
    );
    if (proofIndex !== -1) {
      const reader = new FileReader();
      reader.onload = (event) => {
        newData[proofIndex].preview[index] =
          fileType === "application/pdf"
            ? pdf
            : (event.target?.result as string);
        newData[proofIndex].document[index] = file;
        setData(newData);
        onDataChange(newData);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleFileRemove = (proofLabel: string, index: number) => {
    const newData = [...data];
    const proofIndex = newData.findIndex(
      (item) => item.idProofType === proofLabel
    );
    if (proofIndex !== -1) {
      newData[proofIndex].document[index] = null;
      newData[proofIndex].preview[index] = null;
      setData(newData);
      onDataChange(newData);
    }
  };

  const generateInputsForRow = (proof: any, idx: number) => {
    return (
      <>
        {[0, 1].map((index) => (
          <td key={index} className="px-4 py-3">
            <FileUploadButton
              id={`Upload Document ${proof.value} ${index}`}
              uploadImage={data[idx]?.preview[index]}
              onFileSubmit={(e: any) =>
                handleFileUpload(proof.value, e.target.files[0], index)
              }
              onPerviewClose={() => handleFileRemove(proof.value, index)}
              label={`Document ${index + 1}`}
              placeholder={`Please Upload Document ${index + 1}`}
              ImageSize={100}
              isrequired={index == 0}
            />
          </td>
        ))}
      </>
    );
  };

  const generateRows = () => {
    return idProofList.map((proof: any, index: number) => (
      <tr key={proof.value} className="bg-white">
        <th
          scope="row"
          className="sticky left-2 bg-white z-9 px-4 py-3 font-medium text-gray-900"
        >
          {proof.label}
        </th>
        {generateInputsForRow(proof, index)}
      </tr>
    ));
  };

  return (
    <div className="w-full max-h-96 overflow-x-auto overflow-y-auto shadow-md sm:rounded-lg my-5">
      <table className="w-full text-sm text-left text-gray-500">
        <thead className="text-sm font-Inter text-white capitalize bg-primary_color sticky top-0 z-10">
          <tr>
            <th colSpan={5} scope="col" className="px-4 py-3 whitespace-nowrap">
              {title}
            </th>
          </tr>
        </thead>
        <tbody>
          {idProofList?.length > 0 ? (
            generateRows()
          ) : (
            <tr className="text-center">
              <td
                colSpan={12}
                className="font-Inter font-normal px-4 py-3 font-lg text-center"
              >
                Please Select Id Proof!
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};

export default TableMatrixUpload;

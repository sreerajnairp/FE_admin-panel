import React from "react";
import PropTypes from "prop-types";

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }
  static getDerivedStateFromError(error) {
    return { hasError: true };
  }
  componentDidCatch(error, errorInfo) {
    console.log({ error, errorInfo });
  }
  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex flex-grow items-center justify-center bg-gray-50">
          <div className="rounded-lg bg-white p-24 text-center shadow-xl">
            <h2 className="mb-8 text-xl md:text-3xl font-bold font-Inter text-secondary_color">
              Oop&apos;s there is an Error{" "}
            </h2>
            <h3 className="my-8 text-xl text-gray-500">
              Let&apos;s get you back
            </h3>
            <button
              className="font-[400] py-4 whitespace-nowrap w-full text-white  border justify-center font-Inter bg-primary_color"
              type="button"
              onClick={() => this.setState({ hasError: false })}
            >
              Try again?
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}
ErrorBoundary.propTypes = {
  children: PropTypes.node,
};

export default ErrorBoundary;

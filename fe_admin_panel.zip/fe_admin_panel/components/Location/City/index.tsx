import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import { LoadingScreen } from "@/components/common/Loader";
import React, { useState, useEffect, useCallback } from "react";
import {
  getCityByStateApi,
  getCityAddApi,
  getCityUpdateApi,
} from "@/redux/actions/CommonApiAct";
import { useForm, FormProvider } from "react-hook-form";
import { CityFormValues } from "@/types/Admin";
import { useRouter } from "next/router";
import { NormalButton } from "@/components/common/Inputs/NormalButton";
import { ButtonContainer } from "@/components/common/ButtonContainer";
import dynamic from "next/dynamic";
import { AddPopup } from "@/components/common/AddModal";
import { citySchema } from "@/validations/web.schema";
import { yupResolver } from "@hookform/resolvers/yup";
import { Toast } from "@/service/toast";
import Image from "next/image";
import close from "@/assets/svg/close.svg";
import TableWrapper from "@/components/common/TableWrapper";
import edit from "@/assets/icon/edit.svg";
import tick from "@/assets/svg/check.svg";
import { CityTableHeader } from "@/helpers/constants";
import { debounce } from "lodash";

const MAPBOX_TOKEN = process.env.NEXT_PUBLIC_ENV_MAPBOX_KEY;

interface City {
  id: any;
  city: string;
  stateId: number;
  status: number;
}
interface SearchBoxProps {
  accessToken: string | undefined;
  placeholder: string;
  options: {
    language: string;
    country: string;
    types?: string;
  };
  value: string;
  onRetrieve: (selectedResult: any) => void;
  onChange: (event: any) => void;
  onClear: () => void;
}

const DynamicSearchBox = dynamic<SearchBoxProps>(
  () => import("@mapbox/search-js-react").then((mod: any) => mod.SearchBox),
  { ssr: false }
);

const CityLocation = ({
  getCityByStateApi,
  getCityAddApi,
  getCityUpdateApi,
  addCity,
  setAddCity,
}: any) => {
  const router = useRouter();
  const { _id = 0, slug = "", State = "" } = router.query;
  const [popUp, setPopUp] = useState<boolean>(false);
  const [isMounted, setIsMounted] = useState(false);
  const [loadingFetch, setLoadingFetch] = useState(true);
  const [selectedCity, setSelectedCity] = useState<City[]>([]);
  const [isSent, setIsSent] = useState<boolean>(false);
  const [searchCity, setSearchCity] = useState("");
  const [editCity, setEditCity] = useState("");
  const [id, setId] = useState("");
  const [isEmptyError, setIsEmptyError] = useState(false);
  const [verifyState, setVerifyState] = useState(null);
  const [unsavedChanges, setUnsavedChanges] = useState(false);
  const [isEmptyAllow, setIsEmptyAllow] = useState(false);

  const method = useForm<CityFormValues>({
    defaultValues: {
      stateId: _id,
      city: "",
    },
    resolver: yupResolver(citySchema),
  });

  const handleCityId = useCallback(async () => {
    if (_id) {
      setLoadingFetch(true);
      const { data } = await getCityByStateApi(_id);
      setSelectedCity(data.list);
      setLoadingFetch(false);
      setPopUp(false);
      method.setValue("city", "");
      setSearchCity("");
    }
  }, [_id]);

  useEffect(() => {
    if (_id) {
      handleCityId();
    }
  }, [_id]);

  const handleCheckboxChange = (city: string, event: any) => {
    const updatedListData = selectedCity.map((item: any) =>
      item.city === city ? { ...item, [event]: !item[event] } : item
    );
    setSelectedCity(updatedListData);
    setUnsavedChanges(true);
  };
  const handleCitySelection = (selectedResult: any) => {
    const cityName =
      selectedResult?.features[0]?.properties?.context?.place?.name;
    setVerifyState(selectedResult?.features[0]?.properties?.context);
    method.setValue("city", cityName);
    setSearchCity(cityName);
  };
  const handleEditCitySelection = (selectedResult: any) => {
    const cityName =
      selectedResult?.features[0]?.properties?.context?.place?.name;
    setVerifyState(selectedResult?.features[0]?.properties?.context);
    setEditCity(cityName);
    setIsEmptyError(false);
    setIsEmptyAllow(false);
    setUnsavedChanges(true);
  };
  const handleSearchBoxChange = useCallback(
    debounce((event: any) => {
      method.clearErrors("city");
      setSearchCity(event);
    }, 300),
    []
  );

  const handleEditSearchBoxChange = useCallback(
    debounce((event: any) => {
      setEditCity(event);
      setIsEmptyError(false);
      setIsEmptyAllow(true)
      setUnsavedChanges(true);
    }, 300),
    []
  );

  const handleCity = (name: any, id: any) => {
    if (!editCity.trim() && !isEmptyError) {
      setId(id);
      setEditCity(name);
      setIsEmptyError(false);
      setAddCity(false);
      setSearchCity("");
      method.clearErrors("city");
      setUnsavedChanges(false);
    }
  };
  const onSubmitAddCity = async (data: any) => {
    if (unsavedChanges) {
      Toast({
        type: "error",
        message: "You have unsaved changes. Please submit the update first.",
      });
      method.setValue("city", "");
      setSearchCity("");
      return;
    }
    setLoadingFetch(true);
    setIsSent(true);
    if ((verifyState as any)?.region?.name === State) {
      let body = {
        stateId: Number(_id),
        city: data?.city,
      };
      try {
        await getCityAddApi(body);
        setLoadingFetch(false);
        setIsSent(false);
        setPopUp(true);
        setTimeout(() => {
          handleCityId();
          setAddCity(false);
        }, 2000);
      } catch (error) {
        method.setValue("city", "");
        setSearchCity("");
        setIsSent(false);
        setLoadingFetch(false);
      }
    } else {
      Toast({
        type: "error",
        message: "Attempting to add a city under the wrong state.",
      });
      method.setValue("city", "");
      setSearchCity("");
      setIsSent(false);
      setLoadingFetch(false);
    }
  };
  const handleUpdateSubmit = () => {
    if (!editCity.trim()) {
      setIsEmptyError(true);
      setIsEmptyAllow(true);
      return;
    }

    const currentState = selectedCity.find((city) => city.id === id);
    if (currentState && currentState.city === editCity) {
      handleCloseEdit();
      return;
    }
    if (!isEmptyAllow) {
      const isDuplicateCity = selectedCity.some((item) => item.city === editCity);
      if (!isDuplicateCity) {
        if ((verifyState as any)?.region?.name === State) {
          setSelectedCity((prevState) =>
            prevState.map((state) =>
              state.id === id ? { ...state, city: editCity } : state
            )
          );
          handleCloseEdit();
        } else {
          Toast({
            type: "error",
            message: "Attempting to add a city under the wrong state.",
          });
          setEditCity("");
          setIsEmptyAllow(true);
        }
      } else {
        Toast({
          type: "error",
          message: "City already exists",
        });
        setEditCity("");
        setIsEmptyAllow(true)
      }
    }
  };

  const onSubmitUpdateCity = async () => {
    if (isEmptyError || addCity) {
      addCity
        ? Toast({
            type: "error",
            message: "Please add city / cancel to submit",
          })
        : Toast({
            type: "error",
            message: "please fill Mandatory.",
          });
      return;
    }
    let body = {
      forState: false,
      data: selectedCity,
    };
    setLoadingFetch(true);
    setIsSent(true);
    try {
      await getCityUpdateApi(body);
      setLoadingFetch(false);
      setIsSent(false);
      setPopUp(true);
      setTimeout(() => {
        handleCloseEdit();
        handleCityId();
      }, 1000);
      setUnsavedChanges(false);
    } catch (error) {
      handleCloseEdit();
      setIsSent(false);
      setLoadingFetch(false);
    }
  };
  const handlePreventDefault = (e: any) => {
    e.stopPropagation();
    e.preventDefault();
  };
  useEffect(() => {
    setIsMounted(true);
  }, []);

  if (!isMounted) return null;

  const handleCloseAdd = () => {
    method.clearErrors("city");
    setSearchCity("");
    setAddCity(false);
  };

  const handleCloseEdit = () => {
    setId("");
    setEditCity("");
    setIsEmptyError(false);
    setIsEmptyAllow(false);
  };
  const halfLength = Math.ceil(selectedCity.length / 2);
  const firstHalf = selectedCity?.slice(0, halfLength);
  const secondHalf = selectedCity?.slice(halfLength);

  return (
    <>
      {loadingFetch && <LoadingScreen />}
      <div className="text-primary_color font-Inter capitalize flex items-center text-xl font-extrabold mt-10 mb-4">
        {State}
      </div>
      {addCity && (
        <div className="my-4">
          <FormProvider {...method}>
            <form onSubmit={method.handleSubmit(onSubmitAddCity)}>
              <div className="flex">
                <button className="mt-1 w-fit" onClick={handlePreventDefault}>
                  <DynamicSearchBox
                    accessToken={MAPBOX_TOKEN}
                    placeholder={"Please Enter City"}
                    options={{
                      language: "en",
                      country: "IN",
                      types: "city",
                    }}
                    value={searchCity}
                    onRetrieve={handleCitySelection}
                    onChange={handleSearchBoxChange}
                    onClear={() =>
                      handleSearchBoxChange("")
                    }
                  />
                </button>
                <NormalButton
                  title="Add"
                  isDisabled={isSent}
                  inputStyles=" border text-white bg-primary_color text-md p-2 px-6 capitalize ml-5"
                  btnType="submit"
                />
                <NormalButton
                  title="Cancel"
                  isDisabled={isSent}
                  handleClick={handleCloseAdd}
                  inputStyles=" border border-2 border-primary_color text-primary_color bg-white text-md p-2 px-6 capitalize ml-5"
                  btnType="button"
                />
              </div>
              {method.formState.errors.city?.message &&
                typeof method.formState.errors.city.message === "string" && (
                  <span className="text-red-500 text-md my-2 font[450]">
                    {method.formState.errors.city.message}
                  </span>
                )}
            </form>
          </FormProvider>
        </div>
      )}
      <div className="flex flex-col lg:flex-row gap-8">
        <TableWrapper
          headers={CityTableHeader}
          listData={selectedCity}
          isStatus={true}
          isAction={true}
          isActionClass={"text-center"}
        >
          {selectedCity?.length !== 0 ? (
            firstHalf.map((data: any, index: number) => {
              return (
                <tr
                  key={data?.id}
                  className="bg-white border-b  hover:bg-gray-50"
                >
                  <td className="px-4 py-3">
                    <div className="my-1">
                      {id !== data?.id ? (
                        <p className="font-xl font-Inter font-normal text-grey whitespace-nowrap">
                          {data?.city || "-"}
                        </p>
                      ) : (
                        <div className="flex">
                          <button
                            className="mt-1 w-fit"
                            onClick={handlePreventDefault}
                          >
                            <DynamicSearchBox
                              accessToken={MAPBOX_TOKEN}
                              placeholder={"Please Enter City"}
                              options={{
                                language: "en",
                                country: "IN",
                                types: "city",
                              }}
                              value={editCity}
                              onRetrieve={handleEditCitySelection}
                              onChange={handleEditSearchBoxChange}
                              onClear={() =>
                                handleEditSearchBoxChange("")
                              }
                            />
                            {(isEmptyError || isEmptyAllow) && (
                              <span className="text-red-500 text-md my-2 font[450]">
                                Invalid City
                              </span>
                            )}
                          </button>
                        </div>
                      )}
                    </div>
                  </td>
                  <td className="px-14 py-4">
                    <label
                      key={data?.id}
                      className="flex items-center space-x-2 cursor-pointer"
                    >
                      <p className="hidden">check</p>
                      <input
                        type="checkbox"
                        checked={!!data?.isGeneral}
                        onChange={() =>
                          handleCheckboxChange(data?.city, "isGeneral")
                        }
                        className="form-checkbox h-5 w-5 text-primary_color"
                      />
                    </label>
                  </td>
                  <td className="px-14 py-4">
                    <label
                      key={data?.id}
                      className="flex items-center space-x-2 cursor-pointer"
                    >
                      <p className="hidden">check</p>
                      <input
                        type="checkbox"
                        checked={!!data?.isServiceable}
                        onChange={() =>
                          handleCheckboxChange(data?.city, "isServiceable")
                        }
                        className="form-checkbox h-5 w-5 text-primary_color"
                      />
                    </label>
                  </td>
                  <td className="p-2">
                    <div className="flex justify-center gap-3">
                      {id !== data?.id ? (
                        <div className="group flex relative">
                          <button
                            onClick={() => handleCity(data?.city, data?.id)}
                            className="rounded-full bg-light-grey"
                          >
                            <Image src={edit} alt="edit" />
                          </button>
                          <div
                            className="group-hover:opacity-100 transition-opacity bg-light-grey px-2  text-sm text-gray-black rounded-md 
                          absolute left-1/2 -translate-x-1/2 translate-y-full opacity-0 m-1 mx-auto"
                          >
                            Edit
                          </div>
                        </div>
                      ) : (
                        <>
                          <div className="group flex relative">
                            <button
                              onClick={handleUpdateSubmit}
                              className="rounded-full bg-light-grey"
                            >
                              <Image
                                src={tick}
                                alt="edit"
                                width={24}
                                height={24}
                              />
                            </button>
                            <div
                              className="group-hover:opacity-100 transition-opacity bg-light-grey px-2  text-sm text-gray-black rounded-md 
                       absolute left-1/2 -translate-x-1/2 translate-y-full opacity-0 m-1 mx-auto"
                            >
                              Update
                            </div>
                          </div>
                          <div className="group flex relative">
                            <button
                              onClick={handleCloseEdit}
                              className="rounded-full bg-light-grey"
                            >
                              <Image
                                src={close}
                                alt="edit"
                                width={24}
                                height={24}
                              />
                            </button>
                            <div
                              className="group-hover:opacity-100 transition-opacity bg-light-grey px-2  text-sm text-gray-black rounded-md 
                         absolute left-1/2 -translate-x-1/2 translate-y-full opacity-0 m-1 mx-auto"
                            >
                              Close
                            </div>
                          </div>
                        </>
                      )}
                    </div>
                  </td>
                </tr>
              );
            })
          ) : (
            <tr className="text-center">
              <td
                colSpan={12}
                className="font-Inter font-normal px-4 py-3 font-lg text-center"
              >
                No records found !!!
              </td>
            </tr>
          )}
        </TableWrapper>
        <TableWrapper
          headers={CityTableHeader}
          listData={selectedCity}
          isStatus={true}
          isAction={true}
          isActionClass={"text-center"}
        >
          {selectedCity?.length !== 0 ? (
            secondHalf.map((data: any, index: number) => {
              return (
                <tr
                  key={data?.id}
                  className="bg-white border-b  hover:bg-gray-50"
                >
                  <td className="px-4 py-3">
                    <div className="my-1">
                      {id !== data?.id ? (
                        <p className="font-xl font-Inter font-normal text-grey whitespace-nowrap">
                          {data?.city || "-"}
                        </p>
                      ) : (
                        <div className="flex">
                          <button
                            className="mt-1 w-fit"
                            onClick={handlePreventDefault}
                          >
                            <DynamicSearchBox
                              accessToken={MAPBOX_TOKEN}
                              placeholder={"Please Enter City"}
                              options={{
                                language: "en",
                                country: "IN",
                                types: "city",
                              }}
                              value={editCity}
                              onRetrieve={handleEditCitySelection}
                              onChange={handleEditSearchBoxChange}
                              onClear={() =>
                                handleEditSearchBoxChange("")
                              }
                            />
                            {(isEmptyError || isEmptyAllow) && (
                              <span className="text-red-500 text-md my-2 font[450]">
                                Invalid City
                              </span>
                            )}
                          </button>
                        </div>
                      )}
                    </div>
                  </td>
                  <td className="px-14 py-4">
                    <label
                      key={data?.id}
                      className="flex items-center space-x-2 cursor-pointer"
                    >
                      <p className="hidden">check</p>
                      <input
                        type="checkbox"
                        checked={!!data?.isGeneral}
                        onChange={() =>
                          handleCheckboxChange(data?.city, "isGeneral")
                        }
                        className="form-checkbox h-5 w-5 text-primary_color"
                      />
                    </label>
                  </td>
                  <td className="px-14 py-4">
                    <label
                      key={data?.id}
                      className="flex items-center space-x-2 cursor-pointer"
                    >
                      <p className="hidden">check</p>
                      <input
                        type="checkbox"
                        checked={!!data?.isServiceable}
                        onChange={() =>
                          handleCheckboxChange(data?.city, "isServiceable")
                        }
                        className="form-checkbox h-5 w-5 text-primary_color"
                      />
                    </label>
                  </td>
                  <td className="p-2">
                    <div className="flex justify-center gap-3">
                      {id !== data?.id ?
                        <div className="group flex relative">
                          <button
                            onClick={() =>
                              handleCity(data?.city, data?.id)
                            }
                            className="rounded-full bg-light-grey"
                          >
                            <Image src={edit} alt="edit" />
                          </button>
                          <div
                            className="group-hover:opacity-100 transition-opacity bg-light-grey px-2  text-sm text-gray-black rounded-md 
                          absolute left-1/2 -translate-x-1/2 translate-y-full opacity-0 m-1 mx-auto"
                          >
                            Edit
                          </div>
                        </div> :
                        <>
                          <div className="group flex relative">
                            <button
                              onClick={handleUpdateSubmit}
                              className="rounded-full bg-light-grey"
                            >
                              <Image src={tick} alt="edit" width={24} height={24} />
                            </button>
                            <div
                              className="group-hover:opacity-100 transition-opacity bg-light-grey px-2  text-sm text-gray-black rounded-md 
                       absolute left-1/2 -translate-x-1/2 translate-y-full opacity-0 m-1 mx-auto"
                            >
                              Update
                            </div>
                          </div>
                          <div className="group flex relative">
                            <button
                              onClick={handleCloseEdit}
                              className="rounded-full bg-light-grey"
                            >
                              <Image src={close} alt="edit" width={24} height={24} />
                            </button>
                            <div
                              className="group-hover:opacity-100 transition-opacity bg-light-grey px-2  text-sm text-gray-black rounded-md 
                         absolute left-1/2 -translate-x-1/2 translate-y-full opacity-0 m-1 mx-auto"
                            >
                              Close
                            </div>
                          </div>
                        </>
                      }
                    </div>
                  </td>
                </tr>
              );
            })
          ) : (
            <tr className="text-center">
              <td
                colSpan={12}
                className="font-Inter font-normal px-4 py-3 font-lg text-center"
              >
                No records found !!!
              </td>
            </tr>
          )}
        </TableWrapper>
      </div>
      <div className="border-grey-line border-b mt-32 mb-5" />
      <ButtonContainer
        labelLeft="cancel"
        labelRight={"Submit"}
        handleClose={() => {  handleCloseAdd(); handleCloseEdit();  handleCityId(); }}
        btnType="submit"
        handleOpen={() => onSubmitUpdateCity()}
        isdisabledSubmit={selectedCity.length == 0 || isSent}
      />
      {popUp && (
        <AddPopup
          title={searchCity.length > 0 ? "added!" : "updated!"}
          success={
            searchCity.length > 0
              ? "city added successfully"
              : "city Updated successfully"
          }
        />
      )}

    </>
  );
};

const mapDispatchToProps = (dispatch: any) => {
  return bindActionCreators(
    { getCityByStateApi, getCityAddApi, getCityUpdateApi },
    dispatch
  );
};
export default connect(null, mapDispatchToProps)(CityLocation);

import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import { LoadingScreen } from "@/components/common/Loader";
import { useState, useEffect, useCallback } from "react";
import {
  getStatePermitApi,
  getStateAddApi,
  getCityUpdateApi,
} from "@/redux/actions/CommonApiAct";
import { useForm, FormProvider } from "react-hook-form";
import { StateFormValues } from "@/types/Admin";
import { useRouter } from "next/router";
import { NormalButton } from "@/components/common/Inputs/NormalButton";
import dynamic from "next/dynamic";
import { AddPopup } from "@/components/common/AddModal";
import { stateSchema } from "@/validations/web.schema";
import { yupResolver } from "@hookform/resolvers/yup";
import Image from "next/image";
import close from "@/assets/svg/close.svg";
import { StateTableHeader } from "@/helpers/constants";
import edit from "@/assets/icon/edit.svg";
import tick from "@/assets/svg/check.svg";
import TableWrapper from "@/components/common/TableWrapper";
import { ButtonContainer } from "@/components/common/ButtonContainer";
import { debounce } from "lodash";
import { Toast } from "@/service/toast";

const MAPBOX_TOKEN = process.env.NEXT_PUBLIC_ENV_MAPBOX_KEY;

interface State {
  id: number;
  state: string;
  isServiceable: boolean;
  isGeneral: boolean;
  countryId: number;
}
interface SearchBoxProps {
  accessToken: string | undefined;
  placeholder: string;
  options: {
    language: string;
    country: string;
    types?: string;
  };
  value: string;
  onRetrieve: (selectedResult: any) => void;
  onChange: (event: any) => void;
  onClear: () => void;
}

const DynamicSearchBox = dynamic<SearchBoxProps>(
  () => import("@mapbox/search-js-react").then((mod: any) => mod.SearchBox),
  { ssr: false }
);

const StateLocation = ({
  getStatePermitApi,
  getStateAddApi,
  addState,
  setAddState,
  getCityUpdateApi,
}: any) => {
  const router = useRouter();
  const [popUp, setPopUp] = useState<boolean>(false);
  const [loadingFetch, setLoadingFetch] = useState(true);
  const [selectedState, setSelectedState] = useState<State[]>([]);
  const [isMounted, setIsMounted] = useState(false);
  const [searchState, setSearchState] = useState("");
  const [editState, setEditState] = useState("");
  const [unsavedChanges, setUnsavedChanges] = useState(false);
  const [viewCity, setViewCity] = useState(false);
  const [id, setId] = useState("");
  const [isSent, setIsSent] = useState<boolean>(false);
  const [isEmptyError, setIsEmptyError] = useState(false);
  const [isEmptyAllow, setIsEmptyAllow] = useState(false);

  const methods = useForm<StateFormValues>({
    defaultValues: {
      state: "",
    },
    resolver: yupResolver(stateSchema),
  });

  const getStatePermitFunc = () => {
    setLoadingFetch(true);
    getStatePermitApi().then(({ data }: any) => {
      if (data) {
        setSelectedState(data.list);
        setLoadingFetch(false);
        setPopUp(false);
        methods.setValue("state", "");
        setSearchState("");
      }
    });
  };

  useEffect(() => {
    getStatePermitFunc();
  }, []);

  const handleState = (name: any, id: any) => {
    if (!editState.trim() && !isEmptyError) {
      setId(id);
      setEditState(name);
      setIsEmptyError(false);
      setAddState(false);
      setSearchState("");
      methods.clearErrors("state");
      setUnsavedChanges(false);
    }
  };

  const handleStateSelection = (selectedResult: any) => {
    const stateName =
      selectedResult?.features[0]?.properties?.context?.region?.name;
    methods.setValue("state", stateName);
    setSearchState(stateName);
  };

  const handleEditStateSelection = (selectedResult: any) => {
    const stateName =
      selectedResult?.features[0]?.properties?.context?.region?.name;
    setEditState(stateName);
    setIsEmptyError(false);
    setIsEmptyAllow(false);
    setUnsavedChanges(true);
  };

  const handleSearchBoxChange = useCallback(
    debounce((event: any) => {
      methods.clearErrors("state");
      setSearchState(event);
    }, 300),
    []
  );

  const handleEditSearchBoxChange = useCallback(
    debounce((event: any) => {
      setEditState(event);
      setIsEmptyError(false);
      setIsEmptyAllow(true);
      setUnsavedChanges(true);
    }, 300),
    []
  );

  const onSubmitState = async (data: any) => {
    if (unsavedChanges) {
      Toast({
        type: "error",
        message: "You have unsaved changes. Please submit the update first.",
      });
      methods.setValue("state", "");
      setSearchState("");
      return;
    }
    let body = { ...data };
    setId("");
    setIsSent(true);
    setLoadingFetch(true);
    try {
      await getStateAddApi(body);
      setLoadingFetch(false);
      setIsSent(false);
      setPopUp(true);
      setEditState("");
      setIsEmptyError(false);
      setIsEmptyAllow(false);
      setTimeout(() => {
        getStatePermitFunc();
        setAddState(false);
      }, 2000);
    } catch (error) {
      methods.setValue("state", "");
      setSearchState("");
      setIsSent(false);
      setLoadingFetch(false);
    }
  };

  const handlePreventDefault = (e: any) => {
    e.stopPropagation();
    e.preventDefault();
  };

  useEffect(() => {
    setIsMounted(true);
  }, []);

  if (!isMounted) return null;

  const onSubmitUpdateState = async () => {
    if (isEmptyError || addState || selectedState.length == 0) {
      addState
        ? Toast({
            type: "error",
            message: "Please add State / cancel to submit",
          })
        : Toast({
            type: "error",
            message: "please fill Mandatory.",
          });
      return;
    }
    let body = {
      forState: true,
      data: selectedState,
    };
    setIsSent(true);
    setLoadingFetch(true);
    try {
      await getCityUpdateApi(body);
      setLoadingFetch(false);
      setIsSent(false);
      setPopUp(true);
      setTimeout(() => {
        handleCloseEdit();
        getStatePermitFunc();
      }, 1000);
      setUnsavedChanges(false);
      setViewCity(false);
    } catch (error) {
      handleCloseEdit();
      setIsSent(false);
      setLoadingFetch(false);
    }
  };

  const handleUpdateSubmit = () => {
    if (!editState.trim()) {
      setIsEmptyError(true);
      setIsEmptyAllow(true);
      return;
    } else {
      const currentState = selectedState.find(
        (state) => state.id === parseInt(id)
      );
      if (currentState && currentState?.state === editState) {
        handleCloseEdit();
        return;
      }
      if (!isEmptyAllow) {
        const verifyDuplicateState = selectedState?.filter(
          (item) => item.state === editState
        );
        if (!verifyDuplicateState.length) {
          setSelectedState((prevState) =>
            prevState.map((state) =>
              state.id === parseInt(id) ? { ...state, state: editState } : state
            )
          );
          handleCloseEdit();
          setViewCity(true);
        } else {
          Toast({
            type: "error",
            message: "State already exists",
          });
        }
      }
    }
  };

  const handleCheckboxChange = (state: any, event: any) => {
    const updatedListData = selectedState.map((item: any) =>
      item.state === state ? { ...item, [event]: !item[event] } : item
    );
    setSelectedState(updatedListData);
    setUnsavedChanges(true);
  };

  const handleCloseAdd = () => {
    methods.clearErrors("state");
    setSearchState("");
    setAddState(false);
  };

  const handleCloseEdit = () => {
    setId("");
    setEditState("");
    setIsEmptyError(false);
    setIsEmptyAllow(false);
    setViewCity(false);
  };
  const halfLength = Math.ceil(selectedState.length / 2);
  const firstHalf = selectedState?.slice(0, halfLength);
  const secondHalf = selectedState?.slice(halfLength);
  return (
    <div className="mb-10">
      {loadingFetch && <LoadingScreen />}
      {addState && (
        <div className="my-4">
          <FormProvider {...methods}>
            <form onSubmit={methods.handleSubmit(onSubmitState)}>
              <div className="flex">
                <button className="mt-1 w-fit" onClick={handlePreventDefault}>
                  <DynamicSearchBox
                    accessToken={MAPBOX_TOKEN}
                    placeholder={"Please Enter State"}
                    options={{
                      language: "en",
                      country: "IN",
                      types: "region",
                    }}
                    value={searchState}
                    onRetrieve={handleStateSelection}
                    onChange={handleSearchBoxChange}
                    onClear={() => {
                      handleSearchBoxChange("");
                    }}
                  />
                </button>
                <NormalButton
                  title="Add"
                  isDisabled={isSent}
                  inputStyles=" border text-white bg-primary_color text-md p-2 px-6 capitalize ml-5"
                  btnType="submit"
                />
                <NormalButton
                  title="Cancel"
                  isDisabled={isSent}
                  handleClick={handleCloseAdd}
                  inputStyles=" border border-2 border-primary_color text-primary_color bg-white text-md p-2 px-6 capitalize ml-5"
                  btnType="button"
                />
              </div>
              {methods.formState.errors.state?.message &&
                typeof methods.formState.errors.state.message === "string" && (
                  <span className="text-red-500 text-md my-2 font[450]">
                    {methods.formState.errors.state.message}
                  </span>
                )}
            </form>
          </FormProvider>
        </div>
      )}
      <div className="flex flex-col lg:flex-row gap-8">
        <TableWrapper
          headers={StateTableHeader}
          listData={selectedState}
          isStatus={true}
          isAction={true}
          isActionClass={"text-center"}
        >
          {selectedState?.length !== 0 ? (
            firstHalf?.map((data: any, index: number) => {
              return (
                <tr
                  key={data?.id}
                  className="bg-white border-b  hover:bg-gray-50"
                >
                  <td className="px-4 py-3">
                    <div className="my-1">
                      {id !== data?.id ? (
                        <button
                          onClick={() => {
                            if (!viewCity) {
                              router.push(
                                `/dashboard/location/city?_id=${parseInt(
                                  data?.id
                                )}&State=${data?.state}`
                              );
                            } else {
                              Toast({
                                type: "error",
                                message:
                                  "You have unsaved changes. Please submit the update first.",
                              });
                            }
                          }}
                          className="font-xl font-Inter cursor-pointer font-normal text-grey whitespace-nowrap"
                        >
                          {data?.state || "-"}
                        </button>
                      ) : (
                        <div className="flex">
                          <button
                            className="mt-1 w-fit"
                            onClick={() => handlePreventDefault}
                          >
                            <DynamicSearchBox
                              accessToken={MAPBOX_TOKEN}
                              placeholder={"Please Enter State"}
                              options={{
                                language: "en",
                                country: "IN",
                                types: "region",
                              }}
                              value={editState}
                              onRetrieve={handleEditStateSelection}
                              onChange={handleEditSearchBoxChange}
                              onClear={() =>
                                handleEditSearchBoxChange("")
                              }
                            />
                            {(isEmptyError || isEmptyAllow)  && (
                              <span className="text-red-500 text-md my-2 font[450]">
                                Invalid State
                              </span>
                            )}
                          </button>
                        </div>
                      )}
                    </div>
                  </td>
                  <td className="px-14 py-4">
                    <label
                      key={data?.id}
                      className="flex items-center space-x-2 cursor-pointer"
                    >
                      <p className="hidden">check</p>
                      <input
                        type="checkbox"
                        checked={!!data?.isGeneral}
                        onChange={() =>
                          handleCheckboxChange(data?.state, "isGeneral")
                        }
                        className="form-checkbox h-5 w-5 text-primary_color"
                      />
                    </label>
                  </td>
                  <td className="px-14 py-4">
                    <label
                      key={data?.id}
                      className="flex items-center space-x-2 cursor-pointer"
                    >
                      <p className="hidden">check</p>
                      <input
                        type="checkbox"
                        checked={!!data?.isServiceable}
                        onChange={() =>
                          handleCheckboxChange(data?.state, "isServiceable")
                        }
                        className="form-checkbox h-5 w-5 text-primary_color"
                      />
                    </label>
                  </td>
                  <td className="p-2">
                    <div className="flex justify-center gap-3">
                      {id !== data?.id ? (
                        <div className="group flex relative">
                          <button
                            onClick={() => handleState(data?.state, data?.id)}
                            className="rounded-full bg-light-grey"
                          >
                            <Image src={edit} alt="edit" />
                          </button>
                          <div
                            className="group-hover:opacity-100 transition-opacity bg-light-grey px-2  text-sm text-gray-black rounded-md 
                          absolute left-1/2 -translate-x-1/2 translate-y-full opacity-0 m-1 mx-auto"
                          >
                            Edit
                          </div>
                        </div>
                      ) : (
                        <>
                          <div className="group flex relative">
                            <button
                              onClick={handleUpdateSubmit}
                              className="rounded-full bg-light-grey"
                            >
                              <Image
                                src={tick}
                                alt="edit"
                                width={24}
                                height={24}
                              />
                            </button>
                            <div
                              className="group-hover:opacity-100 transition-opacity bg-light-grey px-2  text-sm text-gray-black rounded-md 
                       absolute left-1/2 -translate-x-1/2 translate-y-full opacity-0 m-1 mx-auto"
                            >
                              Update
                            </div>
                          </div>
                          <div className="group flex relative">
                            <button
                              onClick={handleCloseEdit}
                              className="rounded-full bg-light-grey"
                            >
                              <Image
                                src={close}
                                alt="edit"
                                width={24}
                                height={24}
                              />
                            </button>
                            <div
                              className="group-hover:opacity-100 transition-opacity bg-light-grey px-2  text-sm text-gray-black rounded-md 
                         absolute left-1/2 -translate-x-1/2 translate-y-full opacity-0 m-1 mx-auto"
                            >
                              Close
                            </div>
                          </div>
                        </>
                      )}
                    </div>
                  </td>
                </tr>
              );
            })
          ) : (
            <tr className="text-center">
              <td
                colSpan={12}
                className="font-Inter font-normal px-4 py-3 font-lg text-center"
              >
                No records found !!!
              </td>
            </tr>
          )}
        </TableWrapper>
        <TableWrapper
          headers={StateTableHeader}
          listData={selectedState}
          isStatus={true}
          isAction={true}
          isActionClass={"text-center"}
        >
          {selectedState?.length !== 0 ? (
            secondHalf?.map((data: any, index: number) => {
              return (
                <tr
                  key={data?.id}
                  className="bg-white border-b  hover:bg-gray-50"
                >
                  <td className="px-4 py-3">
                    <div className="my-1">
                      {id !== data?.id ? (
                        <button
                          onClick={() => {
                            if (!viewCity) {
                              router.push(
                                `/dashboard/location/city?_id=${parseInt(
                                  data?.id
                                )}&State=${data?.state}`
                              );
                            } else {
                              Toast({
                                type: "error",
                                message:
                                  "You have unsaved changes. Please submit the update first.",
                              });
                            }
                          }}
                          className="font-xl font-Inter cursor-pointer font-normal text-grey  break-all w-30"
                        >
                          {data?.state || "-"}
                        </button>
                      ) : (
                        <div className="flex">
                          <button
                            className="mt-1 w-fit"
                            onClick={() => handlePreventDefault}
                          >
                            <DynamicSearchBox
                              accessToken={MAPBOX_TOKEN}
                              placeholder={"Please Enter State"}
                              options={{
                                language: "en",
                                country: "IN",
                                types: "region",
                              }}
                              value={editState}
                              onRetrieve={handleEditStateSelection}
                              onChange={handleEditSearchBoxChange}
                              onClear={() =>
                                handleEditSearchBoxChange("")
                              }
                            />
                            {(isEmptyError || isEmptyAllow) && (
                              <span className="text-red-500 text-md my-2 font[450]">
                                Invalid State
                              </span>
                            )}
                          </button>
                        </div>
                      )}
                    </div>
                  </td>
                  <td className="px-14 py-4">
                    <label
                      key={data?.id}
                      className="flex items-center space-x-2 cursor-pointer"
                    >
                      <p className="hidden">check</p>
                      <input
                        type="checkbox"
                        checked={!!data?.isGeneral}
                        onChange={() =>
                          handleCheckboxChange(data?.state, "isGeneral")
                        }
                        className="form-checkbox h-5 w-5 text-primary_color"
                      />
                    </label>
                  </td>
                  <td className="px-14 py-4">
                    <label
                      key={data?.id}
                      className="flex items-center space-x-2 cursor-pointer"
                    >
                      <p className="hidden">check</p>
                      <input
                        type="checkbox"
                        checked={!!data?.isServiceable}
                        onChange={() =>
                          handleCheckboxChange(data?.state, "isServiceable")
                        }
                        className="form-checkbox h-5 w-5 text-primary_color"
                      />
                    </label>
                  </td>
                  <td className="p-2">
                    <div className="flex justify-center gap-1">
                      {id !== data?.id ? (
                        <div className="group flex relative">
                          <button
                            onClick={() => handleState(data?.state, data?.id)}
                            className="rounded-full bg-light-grey"
                          >
                            <Image src={edit} alt="edit" />
                          </button>
                          <div
                            className="group-hover:opacity-100 transition-opacity bg-light-grey px-2  text-sm text-gray-black rounded-md 
                          absolute left-1/2 -translate-x-1/2 translate-y-full opacity-0 m-1 mx-auto"
                          >
                            Edit
                          </div>
                        </div>
                      ) : (
                        <>
                          <div className="group flex relative">
                            <button
                              onClick={handleUpdateSubmit}
                              className="rounded-full bg-light-grey"
                            >
                              <Image
                                src={tick}
                                alt="edit"
                                width={24}
                                height={24}
                              />
                            </button>
                            <div
                              className="group-hover:opacity-100 transition-opacity bg-light-grey px-2  text-sm text-gray-black rounded-md 
                       absolute left-1/2 -translate-x-1/2 translate-y-full opacity-0 m-1 mx-auto"
                            >
                              Update
                            </div>
                          </div>
                          <div className="group flex relative">
                            <button
                              onClick={handleCloseEdit}
                              className="rounded-full bg-light-grey"
                            >
                              <Image
                                src={close}
                                alt="edit"
                                width={24}
                                height={24}
                              />
                            </button>
                            <div
                              className="group-hover:opacity-100 transition-opacity bg-light-grey px-2  text-sm text-gray-black rounded-md 
                         absolute left-1/2 -translate-x-1/2 translate-y-full opacity-0 m-1 mx-auto"
                            >
                              Close
                            </div>
                          </div>
                        </>
                      )}
                    </div>
                  </td>
                </tr>
              );
            })
          ) : (
            <tr className="text-center">
              <td
                colSpan={12}
                className="font-Inter font-normal px-4 py-3 font-lg text-center"
              >
                No records found !!!
              </td>
            </tr>
          )}
        </TableWrapper>
      </div>
      <div className="border-grey-line border-b mt-32 mb-5" />
      <ButtonContainer
        labelLeft="cancel"
        labelRight={"Submit"}
        handleClose={() => {
          handleCloseAdd();
          handleCloseEdit();
          getStatePermitFunc();
        }}
        btnType="submit"
        handleOpen={() => onSubmitUpdateState()}
        isdisabledSubmit={selectedState.length == 0 || isSent}
      />
      {popUp && (
        <AddPopup
          title={searchState.length > 0 ? "added!" : "updated!"}
          success={
            searchState.length > 0
              ? "state added successfully"
              : "state updated successfully"
          }
        />
      )}
    </div>
  );
};

const mapDispatchToProps = (dispatch: any) => {
  return bindActionCreators(
    {
      getStatePermitApi,
      getStateAddApi,
      getCityUpdateApi,
    },
    dispatch
  );
};

export default connect(null, mapDispatchToProps)(StateLocation);

import { AddPopup } from "@/components/common/AddModal";
import { NormalInput } from "@/components/common/Inputs/NormalInput";
import { NormalSelect } from "@/components/common/Inputs/NormalSelect";
import { useForm, FormProvider } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import { DriverFormValues } from "@/types/Admin";
import { driverSchema } from "@/validations/web.schema";
import { useRouter } from "next/router";
import { ButtonContainer } from "@/components/common/ButtonContainer";
import { useCallback, useEffect, useState } from "react";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import { FileUploadButton } from "@/components/common/ButtonUpload";
import { DatePicker } from "@/components/common/DatePicker";
import {
  OwnerUpdateApi,
  OwnerAddApi,
  getOwnerById,
  getOwnerListApi,
} from "@/redux/actions/OwnerApiAct";
import {
  getCountryListApi,
  getCityListApi,
  ImageUploadApi,
  getServicableListApi,
  getCityByStateApi,
  getStatePermitApi,
} from "@/redux/actions/CommonApiAct";
import { IDProofOptions, statusOptions } from "@/helpers/constants";
import { Toast } from "@/service/toast";
import moment from "moment";
import {
  DriverAddApi,
  DriverUpdateApi,
  getDriverById,
} from "@/redux/actions/DriverApiAct";
import pdf from "@/assets/icon/pdf.svg";
import { LoadingScreen } from "@/components/common/Loader";

const resetData = () => ({
  fName: "",
  lName: "",
  mobile: "",
  alternatePhone: null,
  email: null,
  idProofType: null,
  document: null,
  profilePicture: null,
  licenseNumber: "",
  licenseExpiry: null,
  licensePhoto: null,
  vehicleInsurance: null,
  vehicleRegistration: null,
  experience: null,
  ownerId: null,
  streetName: null,
  country: null,
  city: null,
  zipCode: null,
  state: null,
  status: 1,
});

const DriverAddEdit = ({
  getOwnerListApi,
  getCountryListApi,
  getCityListApi,
  DriverAddApi,
  DriverUpdateApi,
  getDriverById,
  ImageUploadApi,
  getServicableListApi,
  getStatePermitApi,
  getCityByStateApi,
}: any) => {
  const router = useRouter();
  const [popUp, setPopUp] = useState<boolean>(false);
  const [userDetails, setUserDetails] = useState();
  const [isSent, setIsSent] = useState(false);
  const [countryData, setCountryData] = useState([]);
  const [cityData, setCityData] = useState([]);
  const { _id = "", slug = "" } = router.query;
  const [userData, setUserData] = useState([]);
  const [profileImage, setProfileImage] = useState<string>("");
  const [documentData, setDocumentData] = useState<string>("");
  const [licenseImage, setLicenseImage] = useState<string>("");
  const [loadingFetch, setLoadingFetch] = useState<boolean>(false);
  const [selectedState, setSelectedState] = useState([]);
  const [isOwnerStateMounted, setIsOwnerStateMounted] = useState(false);

  const methods = useForm<DriverFormValues>({
    defaultValues: {
      ...resetData(),
    },
    resolver: yupResolver(driverSchema),
  });

  const getBaseFunc = (id: any) => {
    let query = {
      isGeneral: true,
      cityId: methods.getValues("city"),
    };
    getCityByStateApi(id, query).then(({ data }: any) => {
      setCityData(
        data?.list?.map((res: any) => {
          return {
            value: res.id,
            label: res.city,
          };
        })
      );
    });
  };

  const getCountryDropDown = () => {
    getCountryListApi().then(({ data }: any) => {
      setCountryData(
        data?.map((res: any) => {
          return {
            value: res.name,
            label: res.name,
          };
        })
      );
    });
  };

  const getstateFunc = () => {
    let query = {
      isGeneral: true,
      id: methods.getValues("state"),
    };
    getStatePermitApi(query).then(({ data }: any) => {
      const states = data?.list?.map((res: any) => {
        return {
          value: res.id,
          label: res.state,
        };
      });
      setSelectedState(states);
    });
  };

  useEffect(() => {
    getstateFunc();
  }, [methods.getValues("state")]);
  useEffect(() => {
    getCountryDropDown();
  }, []);
  useEffect(() => {
    getAllUserApiFunc();
  }, [methods.getValues("ownerId")]);

  const getAllUserApiFunc = () => {
    let query = {
      status: 1,
      ownerId: methods.getValues("ownerId"),
    };
    getOwnerListApi(query).then(({ data }: any) => {
      const splitData = data?.list?.map((res: any) => {
        return {
          value: res.id,
          label: `${res.fName} - ${res.lName}`,
        };
      });
      setUserData(splitData);
    });
  };

  const handleFileUpload = async (e: any) => {
    methods.clearErrors("document");
    let file = e.target.files[0];
    if (file) {
      const fileType = file.type;
      if (
        fileType === "image/jpeg" ||
        fileType === "image/jpg" ||
        fileType === "image/png" ||
        fileType === "image/webp" ||
        fileType === "application/pdf"
      ) {
        const fileSizeInMB = file.size / (1024 * 1024);
        if (fileSizeInMB < 3) {
          const reader = new FileReader();
          reader.onload = (event) => {
            const previewUrl = event.target?.result as string;
            fileType === "application/pdf"
              ? setDocumentData(pdf)
              : setDocumentData(previewUrl);
          };
          reader.readAsDataURL(file);
          methods.setValue("document", file);
        } else {
          Toast({
            type: "error",
            message: "File Size should not exceed 3MB.",
          });
          e.target.value = "";
        }
      } else {
        Toast({
          type: "error",
          message: "Only JPEG, JPG, PDF and PNG files are allowed.",
        });
        e.target.value = "";
      }
    }
  };
  const handleProfileUpload = async (e: any) => {
    methods.clearErrors("profilePicture");
    let file = e.target.files[0];
    if (file) {
      const fileType = file.type;
      if (
        fileType === "image/jpeg" ||
        fileType === "image/jpg" ||
        fileType === "image/png" ||
        fileType === "image/webp"
      ) {
        const fileSizeInMB = file.size / (1024 * 1024);
        if (fileSizeInMB < 3) {
          const reader = new FileReader();
          reader.onload = (event) => {
            const previewUrl = event.target?.result as string;
            setProfileImage(previewUrl);
          };
          reader.readAsDataURL(file);
          methods.setValue("profilePicture", file);
        } else {
          Toast({
            type: "error",
            message: "File Size should not exceed 3MB.",
          });
          e.target.value = "";
        }
      } else {
        Toast({
          type: "error",
          message: "Only JPEG, JPG and PNG files are allowed.",
        });
        e.target.value = "";
      }
    }
  };
  const handleLicenceUpload = async (e: any) => {
    methods.clearErrors("licensePhoto");
    let file = e.target.files[0];
    if (file) {
      const fileType = file.type;
      if (
        fileType === "image/jpeg" ||
        fileType === "image/jpg" ||
        fileType === "image/png" ||
        fileType === "image/webp" ||
        fileType === "application/pdf"
      ) {
        const fileSizeInMB = file.size / (1024 * 1024);
        if (fileSizeInMB < 3) {
          const reader = new FileReader();
          reader.onload = (event) => {
            const previewUrl = event.target?.result as string;
            fileType === "application/pdf"
              ? setLicenseImage(pdf)
              : setLicenseImage(previewUrl);
          };
          reader.readAsDataURL(file);
          methods.setValue("licensePhoto", file);
        } else {
          Toast({
            type: "error",
            message: "File Size should not exceed 3MB.",
          });
          e.target.value = "";
        }
      } else {
        Toast({
          type: "error",
          message: "Only JPEG, JPG, PDF and PNG files are allowed.",
        });
        e.target.value = "";
      }
    }
  };

  const getEnqiureDetails = useCallback(async () => {
    if (_id) {
      setLoadingFetch(true);
      const { data } = await getDriverById(_id);
      setUserDetails(data);
      methods.reset({
        fName: data?.fName,
        lName: data?.lName,
        mobile: data?.mobile,
        alternatePhone: data?.alternatePhone,
        email: data?.email,
        idProofType: parseInt(data?.idProofType),
        document: data?.document,
        profilePicture: data?.profilePicture,
        licenseNumber: data?.licenseNumber,
        licenseExpiry: moment(data?.licenseExpiry).format("YYYY-MM-DD"),
        licensePhoto: data?.licensePhoto,
        vehicleInsurance: data?.vehicleInsurance,
        vehicleRegistration: data?.vehicleRegistration,
        experience: data?.experience,
        ownerId: data?.ownerId,
        streetName: data?.streetName,
        country: data?.country,
        city: data?.city,
        zipCode: data?.zipCode,
        state: data?.state,
        status: data?.status,
      });
      setDocumentData(data?.document);
      setProfileImage(data?.profilePicture);
      setLicenseImage(data?.licensePhoto);
      setLoadingFetch(false);
    }
  }, [_id]);
  useEffect(() => {
    if (_id) {
      getEnqiureDetails();
    }
  }, [_id]);
  const onSubmit = async (data: any) => {
    setIsSent(true);
    setLoadingFetch(true);
    const formData = new FormData();
    Object.keys(data).forEach((key) => {
      if (data[key] !== null && data[key] !== undefined) {
        formData.append(key, data[key]);
      }
    });
    try {
      if (userDetails) {
        let query = { id: _id };
        formData.append("userId", (userDetails as any)?.userId);
        formData.append("userAddressId", (userDetails as any)?.userAddressId);
        let body = formData;
        await DriverUpdateApi(body, query);
      } else {
        let body = formData;
        await DriverAddApi(body);
      }
      setLoadingFetch(false);
      setIsSent(false);
      setPopUp(true);
      setTimeout(() => {
        router.push("/dashboard/driver");
      }, 2000);
    } catch (error) {
      console.log(error);
      setIsSent(false);
      setLoadingFetch(false);
    }
  };

  useEffect(() => {
    if (methods.getValues("state") && methods.watch("state")) {
      const id = methods.getValues("state");
      const stateID = id.value ? id.value : id;
      if (isOwnerStateMounted) {
        methods.setValue("city", null)
      }else {
        setIsOwnerStateMounted(true);
      }
      getBaseFunc(stateID);
    }
  }, [methods.getValues("state"), methods.watch("state")]);
  useEffect(() => {
    if (methods.getValues("idProofType") && methods.watch("idProofType")) {
      if (isOwnerStateMounted) {
        setDocumentData("");
        methods.setValue("document", null);
      } else {
        setIsOwnerStateMounted(true);
      }
    }
  }, [methods.getValues("idProofType"), methods.watch("idProofType")]);
  return (
    <FormProvider {...methods}>
      <form onSubmit={methods.handleSubmit(onSubmit)}>
        {loadingFetch && <LoadingScreen />}
        <div className="grid grid-row md:grid-col md:grid-cols-2 lg:grid-cols-3 md:gap-x-20 gap-y-8">
          <NormalInput
            name="fName"
            type="text"
            label="First Name"
            placeholder="Please Enter First Name"
            isrequired={true}
            error={methods.formState.errors.fName?.message}
          />
          <NormalInput
            name="lName"
            type="text"
            label="Last Name"
            placeholder="Please Enter Last Name"
            isrequired={true}
            error={methods.formState.errors.lName?.message}
          />
          <NormalInput
            name="mobile"
            type="number"
            label="Phone Number"
            placeholder="Please Enter Phone Number"
            isrequired={true}
            error={methods.formState.errors.mobile?.message}
          />
          <NormalInput
            name="alternatePhone"
            type="number"
            label="Alternate Phone Number"
            placeholder="Please Enter Alternate Number"
            isrequired={false}
            error={methods.formState.errors.alternatePhone?.message}
          />
          <NormalInput
            name="email"
            type="email"
            label="Email ID"
            placeholder="Please Enter Email ID"
            isrequired={false}
            error={methods.formState.errors.email?.message}
          />
          <NormalSelect
            options={userData}
            placeholder="Please Select Owner"
            label="Owner Name"
            name="ownerId"
            isrequired={true}
            error={methods.formState.errors.ownerId?.message}
          />
          <NormalInput
            name="licenseNumber"
            type="text"
            label="License Number"
            placeholder="Please Enter License Number"
            isrequired={true}
            inputStyles={"uppercase"}
            error={methods.formState.errors.licenseNumber?.message}
          />
          <DatePicker
            name="licenseExpiry"
            type="date"
            value={moment(methods.getValues("licenseExpiry")).format(
              "YYYY-MM-DD"
            )}
            label="License Expiry"
            min={slug[0] == "add" ? new Date().toJSON().slice(0, 10) : ""}
            isrequired={true}
            error={methods.formState.errors.licenseExpiry?.message}
            placeholder="Enter select date"
          />
          <FileUploadButton
            id={"Driver License"}
            uploadImage={licenseImage}
            onPerviewClose={() => {
              setLicenseImage("");
              methods.setValue("licensePhoto", null);
            }}
            label={"Driver License"}
            placeholder="Please Upload Driver License"
            onFileSubmit={(e: any) => handleLicenceUpload(e)}
            ImageSize={100}
            isrequired={true}
            error={methods.formState.errors.licensePhoto?.message}
          />
          <NormalSelect
            options={IDProofOptions}
            placeholder="Please Select ID Proof"
            label="ID Proof"
            name="idProofType"
            isrequired={true}
            error={methods.formState.errors.idProofType?.message}
          />
          <FileUploadButton
            id={"Upload Document"}
            uploadImage={documentData}
            onPerviewClose={() => {
              setDocumentData("");
              methods.setValue("document", null);
            }}
            label={"Document"}
            placeholder="Please Upload Document"
            onFileSubmit={(e: any) => handleFileUpload(e)}
            ImageSize={100}
            isrequired={true}
            error={methods.formState.errors.document?.message}
          />
          <FileUploadButton
            id={"Profile Pic"}
            uploadImage={profileImage}
            onPerviewClose={() => {
              setProfileImage("");
              methods.setValue("profilePicture", null);
            }}
            label={"Profile Pic"}
            placeholder="Please Upload Profile Pic"
            onFileSubmit={(e: any) => handleProfileUpload(e)}
            ImageSize={100}
            isrequired={true}
            error={methods.formState.errors.profilePicture?.message}
          />
          <NormalInput
            name="experience"
            type="number"
            label="Driving Experience"
            placeholder="Please Enter Driving Experience"
            isrequired={true}
            error={methods.formState.errors.experience?.message}
          />
        </div>
        <div className="mb-5 mt-8 text-primary_color text-xl font-semibold font-Inter">
          Address Details
        </div>
        <div className="grid grid-row md:grid-col md:grid-cols-2 lg:grid-cols-3 md:gap-x-20 gap-y-8">
          <NormalInput
            name="streetName"
            type="text"
            label="Address"
            placeholder="Please Enter Address"
            isrequired={false}
            error={methods.formState.errors.streetName?.message}
          />
          <NormalSelect
            options={countryData}
            placeholder="Please Select Country"
            label="Country"
            name="country"
            isrequired={true}
            error={methods.formState.errors.country?.message}
          />
          <NormalSelect
            options={selectedState}
            placeholder="Please Select State"
            label="State"
            name="state"
            isrequired={true}
            error={methods.formState.errors.state?.message}
          />
          <NormalSelect
            options={cityData}
            placeholder="Please Select City / Town"
            label="City / Town"
            name="city"
            isrequired={true}
            error={methods.formState.errors.city?.message}
          />
          <NormalInput
            name="zipCode"
            type="number"
            label="Zip Code"
            placeholder="Please Enter Zip Code"
            isrequired={false}
            error={methods.formState.errors.zipCode?.message}
          />
          <NormalSelect
            options={statusOptions}
            placeholder="Please select status"
            label="Status"
            name="status"
            isrequired={false}
            error={methods.formState.errors.status?.message}
          />
        </div>
        <div className="border-grey-line border-b my-10" />
        <ButtonContainer
          labelLeft="cancel"
          labelRight={slug[0] == "add" ? "add driver" : "update"}
          handleClose={() => router.back()}
          btnType="submit"
          isdisabledSubmit={isSent}
        />
        {popUp && (
          <AddPopup
            title={slug[0] == "add" ? "added!" : "updated!"}
            success={
              slug[0] == "add"
                ? "driver added successfully"
                : "driver Updated successfully"
            }
          />
        )}
      </form>
    </FormProvider>
  );
};

const mapDispatchToProps = (dispatch: any) => {
  return bindActionCreators(
    {
      OwnerUpdateApi,
      OwnerAddApi,
      getOwnerById,
      getOwnerListApi,
      getCountryListApi,
      getCityListApi,
      DriverAddApi,
      DriverUpdateApi,
      getDriverById,
      ImageUploadApi,
      getServicableListApi,
      getStatePermitApi,
      getCityByStateApi,
    },
    dispatch
  );
};
export default connect(null, mapDispatchToProps)(DriverAddEdit);

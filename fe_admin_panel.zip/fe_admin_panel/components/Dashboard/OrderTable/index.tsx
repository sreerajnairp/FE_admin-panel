export const OrderTable = () => {
  return (
    <div className="rounded border py-4 px-5  shadow-md mt-5">
      <div className="flex justify-between pb-4">
        <h3>Recent Orders</h3>
        <h6>View All</h6>
      </div>
      <hr className="mb-2" />
      <div className="overflow-y-scroll h-80">
        <table className="table-fixed w-full md:min-w-max text-sm text-left">
          <thead className="text-xs  uppercase bg-dark-grey ">
            <tr>
              <th scope="col" className="px-2 py-3">
                Order ID
              </th>
              <th scope="col" className="px-2 py-3">
                Customer Details
              </th>
              <th scope="col" className="px-2 py-3">
                Product Details
              </th>
              <th scope="col" className="px-2 py-3">
                Amount
              </th>
            </tr>
          </thead>
          <tbody>
            <tr className="bg-white border-b ">
              <th
                scope="row"
                className="px-2 py-4 font-medium  whitespace-nowrap "
              >
                #2254314
              </th>
              <td className="px-2 py-4">Silver</td>
              <td className="px-2 py-4">Laptop</td>
              <td className="px-2 py-4">$2999</td>
            </tr>
            <tr className="bg-white border-b ">
              <th
                scope="row"
                className="px-2 py-4 font-medium  whitespace-nowrap "
              >
                #2254314
              </th>
              <td className="px-2 py-4">Silver</td>
              <td className="px-2 py-4">Laptop</td>
              <td className="px-2 py-4">$2999</td>
            </tr>
            <tr className="bg-white border-b ">
              <th
                scope="row"
                className="px-2 py-4 font-medium  whitespace-nowrap "
              >
                #2254314
              </th>
              <td className="px-2 py-4">Silver</td>
              <td className="px-2 py-4">Laptop</td>
              <td className="px-2 py-4">$2999</td>
            </tr>
            <tr className="bg-white border-b ">
              <th
                scope="row"
                className="px-2 py-4 font-medium  whitespace-nowrap "
              >
                #2254314
              </th>
              <td className="px-2 py-4">Silver</td>
              <td className="px-2 py-4">Laptop</td>
              <td className="px-2 py-4">$2999</td>
            </tr>
            <tr className="bg-white border-b ">
              <th
                scope="row"
                className="px-2 py-4 font-medium  whitespace-nowrap "
              >
                #2254314
              </th>
              <td className="px-2 py-4">Silver</td>
              <td className="px-2 py-4">Laptop</td>
              <td className="px-2 py-4">$2999</td>
            </tr>
            <tr className="bg-white border-b ">
              <th
                scope="row"
                className="px-2 py-4 font-medium  whitespace-nowrap "
              >
                #2254314
              </th>
              <td className="px-2 py-4">Silver</td>
              <td className="px-2 py-4">Laptop</td>
              <td className="px-2 py-4">$2999</td>
            </tr>
            <tr className="bg-white border-b ">
              <th
                scope="row"
                className="px-2 py-4 font-medium  whitespace-nowrap "
              >
                #2254314
              </th>
              <td className="px-2 py-4">Silver</td>
              <td className="px-2 py-4">Laptop</td>
              <td className="px-2 py-4">$2999</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
};

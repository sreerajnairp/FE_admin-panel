import { Toast } from "@/service/toast";

export const FileUpload = ({
  placeholder = "",
  onFileSubmit = () => null,
  id = "",
  images = [],
  setImages = () => null,
  className = "",
  onPreviewClose = () => null,
  label = "Upload Image",
}: any) => {
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files) {
      const validFiles = Array.from(files).filter((file) => {
        const fileType = file.type;
        if (
          fileType === "image/jpeg" ||
          fileType === "image/png" ||
          fileType === "image/webp"
        ) {
          return true;
        } else {
          Toast({
            type: "error",
            message: "Only JPG, PNG files are allowed.",
          });
          return false;
        }
      });

      setImages([...images, ...validFiles]);
    }
  };
  const handleRemoveImage = (index: number) => {
    const newImages = [...images];
    newImages.splice(index, 1);
    setImages(newImages);
  };
  return (
    <>
      <label className="block mb-3 text-xl font-Jost">{label}</label>
      <div className="flex flex-col md:flex-row gap-5">
        <div
          className={`flex items-center justify-center ${
            images.length == 0 ? "w-full" : "md:w-1/3"
          }`}
        >
          <div className="flex flex-col items-center justify-center w-full h-64 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer bg-gray-50 dark:hover:bg-bray-800 hover:bg-gray-100">
            <div className="flex flex-col items-center justify-center pt-5 pb-6">
              <svg
                className="w-8 h-8 mb-4 text-gray-500 dark:text-gray-400"
                aria-hidden="true"
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 20 16"
              >
                <path
                  stroke="currentColor"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M13 13h3a3 3 0 0 0 0-6h-.025A5.56 5.56 0 0 0 16 6.5 5.5 5.5 0 0 0 5.207 5.021C5.137 5.017 5.071 5 5 5a4 4 0 0 0 0 8h2.167M10 15V6m0 0L8 8m2-2 2 2"
                />
              </svg>
              <p className="mb-2 text-sm text-gray-500 dark:text-gray-400">
                <span className="font-semibold">Click to upload</span> or drag
                and drop
              </p>
              <p className="text-xs text-gray-500 dark:text-gray-400">
                SVG, PNG, JPG
              </p>
            </div>
            <input
              id={id}
              multiple
              type="file"
              className="hidden"
              onChange={handleFileChange}
            />
          </div>
        </div>
        {images.length > 0 && (
          <div className="flex flex-row flex-wrap justify-center max-w-3xl gap-5">
            {images.map((image: any, index: number) => (
              <div key={image.url} className="relative">
                <img
                  width={200}
                  src={image.url ? image.url : URL.createObjectURL(image)}
                  alt={`preview-${index}`}
                />
                <button
                  className="absolute top-2 right-2 cursor-pointer"
                  onClick={() => {
                    handleRemoveImage(index);
                  }}
                >
                  <svg
                    width="32"
                    height="32"
                    viewBox="0 0 32 32"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M16 2C8.2 2 2 8.2 2 16C2 23.8 8.2 30 16 30C23.8 30 30 23.8 30 16C30 8.2 23.8 2 16 2ZM16 28C9.4 28 4 22.6 4 16C4 9.4 9.4 4 16 4C22.6 4 28 9.4 28 16C28 22.6 22.6 28 16 28Z"
                      fill="#4F4F4F"
                    />
                    <path
                      d="M21.4 23L16 17.6L10.6 23L9 21.4L14.4 16L9 10.6L10.6 9L16 14.4L21.4 9L23 10.6L17.6 16L23 21.4L21.4 23Z"
                      fill="#4F4F4F"
                    />
                  </svg>
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </>
  );
};

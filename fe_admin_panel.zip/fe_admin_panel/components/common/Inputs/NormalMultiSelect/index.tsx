import Select, { components } from "react-select";
import { Controller, useFormContext } from "react-hook-form";

export const NormalMultiSelect = ({
  options = [],
  placeholder,
  value,
  handleChange,
  onChange,
  error,
  isLocation,
  isRestrictLocation,
  disabled,
  isCustomStyle,
  handleInputChange,
  isCustomMenuHeight,
  isHeight,
  locationRestrict,
  label,
  isrequired,
  errorStyles,
  name,
  ...props
}: any) => {
  const { control } = useFormContext();
  return (
    <div style={{ position: "relative" }}>
      <div className="flex">
        <label className="block mb-1 font-medium font-Inter capitalize">
          {label}
        </label>
        <label className="text-red-600 ml-1">{isrequired ? "*" : ""}</label>
      </div>
      <Controller
        name={name}
        control={control}
        render={({ field: { onBlur, value, onChange } }) => (
          <Select
            className="font-Inter"
            isMulti
            name={name}
            {...props}
            onInputChange={handleInputChange}
            isDisabled={
              disabled || (isRestrictLocation && locationRestrict === 0)
            }
            options={options}
            value={options?.filter((option: any) =>
              value?.includes(option.value)
            )}
            onChange={(selectedOptions: any) => {
              onChange(selectedOptions.map((option: any) => option.value));
            }}
            components={{
              IndicatorSeparator: () => null,
            }}
            onBlur={onBlur}
            placeholder={placeholder}
            isSearchable={true}
            styles={{
              menu: (base) => ({ ...base, zIndex: 99 }),
              control: (provided) => ({
                ...provided,
                // height: "48px",
                backgroundColor: "#F8F8F8",
                outlineColor: "#f9fafb",
                textTransform: "capitalize",
                borderRadius: "0.5rem",
              }),
              container: (provided) => ({
                ...provided,
                marginTop: 1,
              }),
              valueContainer: (provided) => ({
                ...provided,
                overflow: "visible",
              }),
              // menuList: (base) => ({
              //   ...base,
              //   height:
              //     (isCustomMenuHeight && "120px") || (isHeight && isHeight),
              // }),
            }}
          />
        )}
      />
      {error ? (
        <span
          role="alert"
          className={` text-red-500 text-md font[450] ${errorStyles}`}
        >
          {error}
        </span>
      ) : (
        ""
      )}
    </div>
  );
};

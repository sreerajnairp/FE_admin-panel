import React from "react";
import OtpInput from "react18-input-otp";

export const NormalOTP = ({ value, HandleChangeOtp, error, setErrorOtp }: any) => {
  const customInputStyle = {
    width: "52px",
    height: "52px",
    fontSize: "24px",
    backgroundColor: "#daebef",
    borderRadus: "6px",
  };

  return (
    <>
      <OtpInput
        value={value}
        onChange={(e: any) => {
          HandleChangeOtp(e);
          setErrorOtp(false);
        }}
        numInputs={4}
        isInputNum
        separator={<span className="mx-2 text-xl" />}
        inputStyle={customInputStyle}
      />
      {error ? (
        <div className="mt-3">
          <span
            role="alert"
            className={` text-red-500 text-lg font[450]`}
          >
            {"Please enter a valid OTP."}
          </span>
        </div>
      ) : (
        ""
      )}
    </>
    
  );
};

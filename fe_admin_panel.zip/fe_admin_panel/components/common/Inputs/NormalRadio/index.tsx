import { useFormContext } from "react-hook-form";

export const NormalRadio = ({
  isDisabled,
  isRequired,
  label,
  inputStyles,
  labelStyles,
  isChecked,
  value,
  name,
  id,
  handleCheckbox,
}: any) => {
  const { register } = useFormContext();
  return (
    <div className="flex items-center">
      <input
        {...register(name)}
        disabled={isDisabled}
        defaultChecked={isChecked}
        type="radio"
        value={value}
        id={id}
        className="w-8 h-8 accent-primary_color  bg-gray-100 border-gray-300 "
      />
      {label && (
        <label
          htmlFor={id}
          className={`w-full font-Jost ml-2 text-lg font-medium ${
            isChecked ? "text-primary_color" : "text-black"
          }`}
        >
          {label}
        </label>
      )}
    </div>
  );
};

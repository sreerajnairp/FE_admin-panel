import { useFormContext } from "react-hook-form";

export const NormalSwitch = ({
  label,
  checked,
  isrequired,
  isdisabled,
  inputStyles,
  labelStyles,
  placeholder = "",
  onChange = {},
  value = "",
  name = "",
  className = "",
  onButtonClick = () => null,
}: any) => {
  const { register } = useFormContext();
  return (
    <div className="flex">
      <span className="me-3 text-lg font-Jost">{label}</span>
      <label className="relative inline-flex items-center mr-5 cursor-pointer">
        <input {...register(name)} type="checkbox" className="sr-only peer" />
        <div
          className={`w-11 h-6 bg-grey rounded-full peer ${
            value ? "bg-primary_color" : "bg-black"
          }  peer-checked:after:translate-x-full checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all`}
        ></div>
      </label>
    </div>
  );
};

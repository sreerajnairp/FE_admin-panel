import { useFormContext } from "react-hook-form";

export const NormalTextArea = ({
  type,
  label,
  placeholder,
  isrequired,
  isdisabled,
  inputStyles,
  labelStyles,
  className,
  error,
  icon,
  iconStyle,
  name,
  errorStyles,
}: any) => {
  const { register } = useFormContext();
  return (
    <div className={className}>
      <label className="block mb-2 text-xl font-Jost">{label}</label>
      <textarea
        {...register(name)}
        className={`text-lg rounded-lg block w-full p-2.5 border border-dark-grey bg-light-grey  outline-green ${inputStyles}`}
        placeholder={placeholder}
        required={isrequired}
        disabled={isdisabled}
      ></textarea>
    </div>
  );
};

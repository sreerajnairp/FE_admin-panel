import SearchIcon from '@/assets/svg/search.svg'
import Image from 'next/image';

export const NormalSearch = ({
  placeholder = '',
  onChange = {},
  value = '',
  name = '',
  className = '',
  onButtonClick = () => null,
}: any) => {
  return (
    <div className="pt-2 relative mx-auto text-gray-600">
      <input
        className="border-2 border-gray-300 bg-white h-10 px-5 pr-20 rounded-lg text-sm focus:outline-none"
        type="search"
        name={name}
        value={value}
        placeholder={placeholder}
        onChange={({ target }) =>
          onChange(target.value)
        }
        maxLength={50}
      />
      <button onClick={() => onButtonClick()} className="absolute right-0 top-1 mt-5 mr-4">
        <Image src={SearchIcon} alt="Icon" />
      </button>
    </div>
  );
};

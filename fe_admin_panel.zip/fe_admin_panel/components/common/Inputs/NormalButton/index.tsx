import { CustomButtonProps } from "@/types/common";
import Image from "next/image";

export const NormalButton = ({
  title,
  btnType,
  handleClick,
  isDisabled,
  inputStyles,
  rightIcon,
  leftIcon,
}: CustomButtonProps) => {
  return (
    <button
      disabled={isDisabled}
      type={btnType ?? "button"}
      className={`custom-btn hover:opacity-80 flex rounded-lg disabled:opacity-60  ${inputStyles}`}
      onClick={handleClick}
    >
      {leftIcon && (
        <Image className="mt-[-5px] me-2" src={leftIcon} alt="Icon" />
      )}
      {title}
      {rightIcon && <Image className="ms-2" src={rightIcon} alt="Icon" />}
    </button>
  );
};

import { useFormContext } from "react-hook-form";
import { useState } from "react";
import eyeClose from "@/assets/svg/eyeclose.svg";
import eyeOpen from "@/assets/svg/eyeopen.svg";
import Image from "next/image";

export const NormalInput = ({
  type,
  label,
  inputLabel,
  placeholder,
  isrequired,
  isdisabled,
  inputStyles,
  labelStyles,
  className,
  error,
  icon,
  iconStyle,
  name,
  errorStyles,
  context,
  step = "",
}: any) => {
  const [isPasswordVisible, setIsPasswordVisible] = useState(false);
  const { register } = useFormContext();
  const handleKeyDown = (e: any) => {
    if (e.key === 'Enter') {
      e.preventDefault();
    }
  };
  const numberInputOnWheelPreventChange = (e: any) => {
    e.target.blur()
  }
  return (
    <div className={className}>
      <label className="block mb-1 font-medium font-Inter">
        {label} <span className="text-red-600">{isrequired ? "*" : ""}</span>
      </label>
      <input
        {...register(name)}
        type={isPasswordVisible ? "text" : type}
        className={`h-11 w-full rounded-lg border p-4 font-Inter outline-gray-50 bg-light-grey ${inputStyles}`}
        placeholder={placeholder}
        // required={isrequired}
        disabled={isdisabled}
        onKeyDown={handleKeyDown}
        onWheel={numberInputOnWheelPreventChange}
        step={step}
      />
      {icon && (
        <button
          className="!absolute right-28 my-4 rounded cursor-pointer"
          onClick={() => {
            setIsPasswordVisible(!isPasswordVisible);
          }}
          type="button"
        >
          {isPasswordVisible ? (
            <Image src={eyeOpen} alt="Icon" />
          ) : (
            <Image src={eyeClose} alt="Icon" />
          )}
        </button>
      )}
      {context ? (
        <div className={` text-black text-sm my-2 font[450] ${errorStyles}`}>
          {context}
        </div>
      ) : (
        ""
      )}
      {error ? (
        <div
          role="alert"
          className={` text-red-500 text-md my-2 font[450] ${errorStyles}`}
        >
          {error}
        </div>
      ) : (
        ""
      )}
    </div>
  );
};

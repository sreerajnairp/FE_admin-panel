import dynamic from 'next/dynamic';
import React from 'react';
const ReactApexChart = dynamic(() => import('react-apexcharts'), { ssr: false })

interface ChartProps {
  options: any;
  series: any;
  type: "bar" | "pie" | "line" | "area" | undefined;
  height?: number
}

const Chart: React.FC<ChartProps> = ({ options, series, type, height=250 }) => {
  return (
    <div>
      <ReactApexChart options={options} series={series} type={type} height={height} width={"100%"} />
    </div>
  );
};

export default Chart;
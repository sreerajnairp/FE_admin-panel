import { useState } from "react";
import Image from "next/image";
import sort from "@/assets/icon/sort.svg";

type SortOrder = "ascn" | "desc";

function sortData({
  tableData,
  sortKey,
  reverse,
}: any ) {
  if (!sortKey) return tableData;

  const sortedData = tableData.sort((a: { [x: string]: number; }, b: { [x: string]: number; }) => {
    return a[sortKey] > b[sortKey] ? 1 : -1;
  });

  if (reverse) {
    return sortedData.reverse();
  }

  return sortedData;
}

const SortButton = ({ sortOrder, columnKey, sortKey, onClick }: any) => {
  return (
    <button
      onClick={onClick}
      className={`${sortKey === columnKey && sortOrder === "desc"
          ? "sort-button sort-reverse"
          : "sort-button"
        }`}
    >
      <Image src={sort} alt="sort" className="w-5 h-5" />
    </button>
  );
};

const TableWrapper = ( { isStatus , isAction , headers, listData , children , checkbox = false , onCheckAll , allcheck, isActionClass = ""}: any) => {
  const [sortKey, setSortKey] = useState("last_name");
  const [sortOrder, setSortOrder] = useState<SortOrder>("ascn");

  function changeSort(key: any) {
    setSortOrder(sortOrder === "ascn" ? "desc" : "ascn");

    setSortKey(key);
  }

  return (
    <div className="mt-3 w-full overflow-x-auto overflow-hidden">
      <table className="w-full text-sm text-left rtl:text-right text-gray-500 shadow-lg sm:rounded-lg">
        <thead className="text-sm font-Inter text-white capitalize bg-primary_color">
          <tr>
            {checkbox &&
              <th scope="col" className="p-4">
                <div className="flex items-center">
                  <input
                    id="checkbox-all-search"
                    type="checkbox"
                    value={allcheck}
                    onChange={()=> onCheckAll(!allcheck)}
                    className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500 dark:focus:ring-blue-600   focus:ring-2  "
                  />
                  <label className="sr-only" htmlFor="checkbox-all-search">checkbox</label>
                </div>
              </th>
            }
            {headers?.map((row : any) => {
              return (
                <th key={row.key} scope="col" className="px-4 py-3">
                  <div className="flex flex-row gap-1">
                    <p className=" font-xl font-Inter font-normal whitespace-nowrap"> {row.label}</p>
                    {row.sortBy &&
                      <SortButton
                        columnKey={row.key}
                        onClick={() => changeSort(row.key)}
                        {...{
                          sortOrder,
                          sortKey,
                        }}
                      />
                    }
                  </div>
                </th>
              );
            })}
            {isAction &&
              <th scope="col" className={`${isActionClass} px-6 py-3`}>
                <p className=" font-xl font-Inter font-normal">Action</p>
              </th>
            }
          </tr>
        </thead>

        <tbody>
          {children}
        </tbody>
      </table>
    </div>
  );
};

export default TableWrapper;
import { NormalButton } from "../Inputs/NormalButton";

export const DeleteModal = ({
  handleModalClose = () => null,
  handleModalSubmit = () => null,
  title,
  success,
  deleteTitle,
  deleteSuccess,
}: any) => {

  return (
    <div>
      <div
        className="fixed z-50 overflow-y-auto top-0 w-full left-0 overflow-x-hidden h-full"
        id="modal"
      >
        <div className="flex items-center justify-center min-height-100vh pt-4 md:px-4 pb-20 text-center sm:block sm:p-0">
          <div className="fixed inset-0 transition-opacity">
            <div className="absolute inset-0 bg-gray-900 opacity-75"></div>
          </div>
          <span className="hidden sm:inline-block sm:align-middle sm:h-screen">
            &#8203;
          </span>
          <div
            className={`inline-block align-center bg-white rounded-xl pt-16 pb-16 text-left overflow-hidden shadow-xl transform transition-all my-16 md:my-8 sm:align-middle sm:max-w-[584px] sm:w-full`}
          >
            <h3 className="text-secondary_color font-bold text-3xl text-center uppercase	">
              {title}
            </h3>
            <div className="border-secondary_color border-b mx-10 my-3" />
            <h3 className="text-primary_color text-xl text-center	font-semibold">
              {success}
            </h3>
            <div className="flex justify-center mt-10 gap-5">
              <NormalButton
                handleClick={handleModalSubmit}
                title="Yes"
                inputStyles=" border text-white bg-primary_color text-md  p-2 px-12 md:px-16 md:text-lg"
              />
              <NormalButton
                handleClick={handleModalClose}
                title="No"
                inputStyles="bg-white border-2 border-primary_color text-primary_color text-md p-2 px-12 md:px-16 md:text-lg"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

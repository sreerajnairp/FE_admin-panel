import { NormalButton } from "../Inputs/NormalButton";

export const ButtonContainer = ({
  labelLeft,
  labelRight,
  handleClose,
  handleOpen,
  btnType,
  isdisabledSubmit
}: any) => {
  return (
    <div className="flex justify-end mb-3">
      <NormalButton
        handleClick={handleClose}
        title={labelLeft}
        inputStyles="bg-white border-2 border-primary_color text-primary_color capitalize text-md p-2 px-12 md:px-16 md:text-lg"
      />
      <NormalButton
        handleClick={handleOpen}
        title={labelRight}
        isDisabled={isdisabledSubmit}
        inputStyles=" border text-white bg-primary_color text-md  p-2 px-12 capitalize md:px-16 md:text-lg ml-5"
        btnType={btnType || "button"}
      />
    </div>
  );
};

import Select from "react-select";

const Pagination = ({ handleInputChange, handleChange,value, handleNextPage, handlePrevPage, pageMeta, handlePageChange, handleSizeChange,page ,rowsPerPage }: any) => {
    const totalOptions = [
        { value: 10, label: "10" },
        { value: 20, label: "20" },
        { value: 50, label: "50" },
        { value: 100, label: "100" },
    ];
    const pageOptions = Array.from({ length: pageMeta?.totalPages }, (_, i) => i + 1).map((page) => ({
        label: page,
        value: page,
    }))

    return (
        <div className="my-5 flex  w-64 md:w-full justify-start md:justify-end">
            <div className="p-3"> Items per page</div>
            <div className="p-2">
                <Select
                    onInputChange={handleInputChange}
                    value={totalOptions.find((option :any) => option.value === rowsPerPage)}
                    options={totalOptions}
                    menuPlacement="top"
                    components={{
                        IndicatorSeparator: () => null,
                    }}
                    placeholder={"00"}
                    styles={{
                        control: (provided) => ({
                            ...provided,
                            height: "8px",
                            borderRadius: "10px",
                            width: "80px",
                        }),
                    }}
                    onChange={handleSizeChange}
                />
            </div>
            <div className="p-3">
            {pageMeta?.total >= 10
              ? pageMeta?.pageSize
              : pageMeta?.total} of {pageMeta?.total} items
            </div>
            <div className="p-2">
                <Select
                    onInputChange={handleInputChange}
                    value={pageOptions.find((option :any) => option.value === page)}
                    options={pageOptions}
                    components={{
                        IndicatorSeparator: () => null,
                    }}
                    menuPlacement="top"
                    placeholder={"00"}
                    styles={{
                        control: (provided) => ({
                            ...provided,
                            height: "8px",
                            borderRadius: "10px",
                            width: "80px",
                        }),
                    }}
                    onChange={handlePageChange}
                />
            </div>
            <div className="p-3"> of {pageMeta?.totalPages} pages</div>
            <button  disabled={page === 1}  onClick={handlePrevPage} type="button" className="min-h-[38px] min-w-[50px] py-2 px-2.5 inline-flex justify-center items-center gap-x-2 text-sm rounded-lg border border-transparent text-gray-800 hover:bg-gray-100 focus:outline-none focus:bg-gray-100 disabled:opacity-50 disabled:pointer-events-none dark:border-transparent ">
                <svg className="flex-shrink-0 w-5 h-5" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m15 18-6-6 6-6" /></svg>
            </button>
            <button disabled={page === pageMeta?.totalPages} onClick={handleNextPage} type="button" className="min-h-[38px] min-w-[50px] py-2 px-2.5 inline-flex justify-center items-center gap-x-2 text-sm rounded-lg border border-transparent text-gray-800 hover:bg-gray-100 focus:outline-none focus:bg-gray-100 disabled:opacity-50 disabled:pointer-events-none dark:border-transparent ">
                <svg className="flex-shrink-0 w-5 h-5" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m9 18 6-6-6-6" /></svg>
            </button>
        </div>
    );
};

export default Pagination;

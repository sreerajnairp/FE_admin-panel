import { Controller, useFormContext } from "react-hook-form";

export const DatePicker = ({
  type,
  label,
  placeholder,
  isrequired,
  isdisabled,
  value,
  inputStyles,
  labelStyles,
  className,
  error,
  icon,
  iconStyle,
  name,
  min,
  errorStyles,
  ...restProps
}: any) => {
  const { control } = useFormContext();
  return (
    <div className={className}>
      <label className="block mb-1 font-medium font-Inter">
        {label} <span className="text-red-600">{isrequired ? "*" : ""}</span>
      </label>
      <Controller
        name={name}
        control={control}
        render={({ field: { onChange, value, onBlur } }) => (
          <input
            min={min}
            name={name}
            type="date"
            value={value}
            onChange={onChange}
            onBlur={onBlur}
            className={`h-11 w-full rounded-lg border p-4 font-Inter outline-gray-50 bg-light-grey ${inputStyles}`}
            {...restProps}
          />
        )}
      />
      {error ? (
        <span
          role="alert"
          className={` text-red-500 text-md my-2 font[450] ${errorStyles}`}
        >
          {error}
        </span>
      ) : (
        ""
      )}
    </div>
  );
};

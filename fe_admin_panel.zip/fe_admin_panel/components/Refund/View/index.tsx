import { useRouter } from "next/router";
import { useCallback, useEffect, useState } from "react";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import {
  getBookingById,
  getRefundUpdateApi,
} from "@/redux/actions/BookingApiAct";
import moment from "moment";
import { NormalInput } from "@/components/common/Inputs/NormalInput";
import { useForm, FormProvider } from "react-hook-form";
import { RefundFormValues } from "@/types/Admin";
import { refundSchema } from "@/validations/web.schema";
import { ButtonContainer } from "@/components/common/ButtonContainer";
import { yupResolver } from "@hookform/resolvers/yup";
import { LoadingScreen } from "@/components/common/Loader";
import { PAYMENT_STATUS } from "@/helpers/constants";

const resetData = () => ({
  cancelReason: "",
  ownerId: "",
  paidAmount: "",
});

const RefundView = ({ getBookingById, getRefundUpdateApi }: any) => {
  const router = useRouter();
  const { _id = "", slug = "" } = router.query;
  const [userDetails, setUserDetails] = useState();
  const [isSented, setIsSented] = useState<boolean>(false);
  const [loadingFetch, setLoadingFetch] = useState(true);

  const getUserDetails = useCallback(async () => {
    if (_id) {
      const { data } = await getBookingById(_id);
      setUserDetails(data);
      setLoadingFetch(false);
      methods.reset({
        cancelReason: data?.cancelReason,
      });
    }
  }, [_id]);

  useEffect(() => {
    if (_id) {
      getUserDetails();
    }
  }, [_id]);

  const methods = useForm<RefundFormValues>({
    defaultValues: {
      ...resetData(),
    },
    resolver: yupResolver(refundSchema),
  });

  const onSubmit = async (data: any) => {
    if (userDetails) {
      let body = {
        bookingId: _id,
        cancelReason: data?.cancelReason,
      };
      setIsSented(true);
      setLoadingFetch(true);
      try {
        await getRefundUpdateApi(body);
        setLoadingFetch(false);
        setIsSented(false);
        setTimeout(() => {
          router.push("/dashboard/refund");
        }, 2000);
        router.push("/dashboard/refund");
      } catch (error) {
        setIsSented(false);
        setLoadingFetch(false);
      }
    }
  };

  return (
    <>
      {loadingFetch && <LoadingScreen />}
      <div className="gap-5 grid grid-cols-1 md:grid-cols-2">
        <div className="mt-4">
          <h3 className="text-primary_color font-Inter capitalize flex items-center text-xl font-extrabold mb-2 mt-2">
            Refund Details
          </h3>
          <div className="refundscroll border border-solid border-gray-400">
            <table className="border-collapse  w-full">
              <tbody>
                <tr>
                  <th className="px-4 pt-4 text-start w-40">Refund ID:</th>
                  <td className="px-4 pt-4 w-96">
                    {(userDetails as any)?.transactionData?.refundId ||
                      "NA"}
                  </td>
                </tr>
                <tr>
                  <th className="px-4 pt-4 text-start">Total Amount:</th>
                  <td className="px-4 pt-4">
                    {(userDetails as any)?.totalPrice !== undefined &&
                    (userDetails as any)?.totalPrice !== null
                      ? (userDetails as any).totalPrice
                      : "-"}
                  </td>
                </tr>
                <tr>
                  <th className="px-4 pt-4 text-start">Advance Amount:</th>
                  <td className="px-4 pt-4">
                    {(userDetails as any)?.advanceAmount || "-"}
                  </td>
                </tr>
                <tr>
                  <th className="px-4 pt-4 text-start">Refund Amount:</th>
                  <td className="px-4 pt-4">
                    {(userDetails as any)?.cancelCredit
                      ? (userDetails as any)?.cancelCredit
                      : "0"}
                  </td>
                </tr>
                <tr>
                  <th className="px-4 pt-4 text-start">
                    Date Of Cancellation:
                  </th>
                  <td className="px-4 pt-4">
                    {moment((userDetails as any)?.cancelledDate)
                      .utc()
                      .format("DD/MM/YYYY")}
                  </td>
                </tr>
                <tr>
                  <th className="px-4 pt-4 text-start">Payment Method:</th>
                  <td className="px-4 pt-4 capitalize">
                    {(userDetails as any)?.transactionData?.paymentMode || "-"}
                  </td>
                </tr>
                <tr>
                  <th className="px-4 pt-4 text-start">Refund Status:</th>
                  <td className="px-4 pt-4">
                    {(userDetails as any)?.cancelCredit === null
                      ? "No Refund"
                      : (userDetails as any)?.transactionData?.paymentStatus !==
                        null
                      ? PAYMENT_STATUS[
                          (userDetails as any)?.transactionData?.paymentStatus
                        ]
                      : "Yet to Refund"}
                  </td>
                </tr>
                <tr>
                  <th className="px-4 pt-4 text-start">Cancelled By:</th>
                  <td className="px-4 pt-4">
                    {(userDetails as any)?.cancelledByName || "-"}
                  </td>
                </tr>

                <tr>
                  <th className="px-4 py-4 text-start">
                    Reason For Cancellation:
                  </th>
                  <td className="px-4 py-4">
                    <div className="has-tooltip font-Inter font-lg">
                      <span className="tooltip max-w-60 rounded shadow-lg p-1 bg-gray-100 text-primary_color -mt-8">
                        {(userDetails as any)?.cancelReason || "-"}
                      </span>
                      <p className="break-all font-xl font-Inter font-normal">
                        {(userDetails as any)?.cancelReason?.length > 40
                          ? `${(userDetails as any)?.cancelReason.slice(
                              0,
                              40
                            )}...`
                          : (userDetails as any)?.cancelReason || "N/A"}
                      </p>
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        <div className="mt-4">
          <h3 className="text-primary_color font-Inter capitalize flex items-center text-xl font-extrabold mb-2 mt-2">
            Order Details
          </h3>
          <table className="border-collapse w-full border border-solid border-gray-400">
            <tbody>
              <tr>
                <th className="px-4 pt-4 text-start">Pickup Address:</th>
                <td className="px-4 pt-4">
                  <div className="has-tooltip font-Inter font-lg">
                    <span className="tooltip max-w-60 rounded shadow-lg p-1 bg-gray-100 text-primary_color -mt-8">
                      {(userDetails as any)?.pickupAddress || "-"}
                    </span>
                    <p className="break-all font-xl font-Inter font-normal text-grey">
                      {(userDetails as any)?.pickupAddress.length > 40
                        ? `${(userDetails as any)?.pickupAddress.slice(
                            0,
                            40
                          )}...`
                        : (userDetails as any)?.pickupAddress || "N/A"}
                    </p>
                  </div>
                </td>
              </tr>
              <tr>
                <th className="px-4 pt-4 text-start">Drop Address:</th>
                <td className="px-4 pt-4">
                  <div className="has-tooltip font-Inter font-lg">
                    <span className="tooltip max-w-60 rounded shadow-lg p-1 bg-gray-100 text-primary_color -mt-8">
                      {(userDetails as any)?.dropAddress || "-"}
                    </span>
                    <p className=" w-96 break-all font-xl font-Inter font-normal text-grey">
                      {(userDetails as any)?.dropAddress.length > 40
                        ? `${(userDetails as any)?.dropAddress.slice(0, 40)}...`
                        : (userDetails as any)?.dropAddress || "N/A"}
                    </p>
                  </div>
                </td>
              </tr>
              <tr>
                <th className="px-4 pt-4 text-start">Pickup Date:</th>
                <td className="px-4 pt-4">
                  {moment((userDetails as any)?.pickupDateTime).format(
                    "DD/MM/YYYY"
                  ) || "N/A"}
                </td>
              </tr>
              <tr>
                <th className="px-4 pt-4 text-start">Vehicle Capacity:</th>
                <td className="px-4 pt-4">
                  {(userDetails as any)?.vehicleCapacityName || "-"}
                </td>
              </tr>
              <tr>
                <th className="px-4 pt-4 text-start">Vehicle Load Type:</th>
                <td className="px-4 pt-4">
                  {(userDetails as any)?.vehicleLoadTypeName || "-"}
                </td>
              </tr>
              <tr>
                <th className="px-4 py-4 text-start">Vehicle Type:</th>
                <td className="px-4 py-4">
                  {(userDetails as any)?.vehicleTypeName || "-"}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <div className="gap-5 grid grid-cols-1  md:grid-cols-2 mt-5">
        {(userDetails as any)?.ownerId !== null ? (
          <div>
            <h3 className="text-primary_color font-Inter capitalize flex items-center text-xl font-extrabold mb-2 mt-2">
              Owner Details
            </h3>
            <table className="border-collapse w-full border border-solid border-gray-400">
              <tbody>
                <tr>
                  <th className="px-4 pt-4 text-start">Owner Name:</th>
                  <td className="px-4 pt-4">
                    {(userDetails as any)?.ownerName || "-"}
                  </td>
                </tr>
                <tr>
                  <th className="px-4 pt-4 text-start">Owner Mobile:</th>
                  <td className="px-4 pt-4">
                    {(userDetails as any)?.ownerMobile || "-"}
                  </td>
                </tr>
                <tr>
                  <th className="px-4 py-4 text-start">Owner Email:</th>
                  <td className="px-4 py-4">
                    {(userDetails as any)?.ownerEmail || "-"}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        ) : (
          ""
        )}
        {(userDetails as any)?.driverId !== null ? (
          <div className="mt-5 md:mt-0">
            <h3 className="text-primary_color font-Inter capitalize flex items-center text-xl font-extrabold mb-2 mt-2">
              Driver Details
            </h3>
            <table className="border-collapse w-full border border-solid border-gray-400">
              <tbody>
                <tr>
                  <th className="px-4 pt-4 text-start">Driver Name:</th>
                  <td className="px-4 pt-4">
                    {(userDetails as any)?.driverName || "-"}
                  </td>
                </tr>
                <tr>
                  <th className="px-4 pt-4 text-start">Driver Mobile:</th>
                  <td className="px-4 pt-4">
                    {(userDetails as any)?.driverMobile || "-"}
                  </td>
                </tr>
                <tr>
                  <th className="px-4 py-4 text-start">Driver Email:</th>
                  <td className="px-4 py-4">
                    {(userDetails as any)?.driverEmail || "-"}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        ) : (
          ""
        )}
      </div>
      <div className="gap-5 grid grid-cols-1 md:grid-cols-2 mt-5">
        {(userDetails as any)?.truckId !== null ? (
          <div>
            <h3 className="text-primary_color font-Inter capitalize flex items-center text-xl font-extrabold mb-2 mt-2">
              Truck Details
            </h3>
            <table className="border-collapse border border-solid border-gray-400 w-full">
              <tbody>
                <tr>
                  <th className="px-4 pt-4 text-start">Registration Number:</th>
                  <td className="px-4 pt-4">
                    {(userDetails as any)?.registrationNumber || "-"}
                  </td>
                </tr>

                <tr>
                  <th className="px-4 py-4 text-start">Vehicle Model:</th>
                  <td className="px-4 py-4">
                    {(userDetails as any)?.vehicleModelName || "-"}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        ) : (
          ""
        )}
      </div>

      <FormProvider {...methods}>
        <form onSubmit={methods.handleSubmit(onSubmit)}>
          <div className="mt-16 grid grid-row md:grid-col md:grid-cols-2 lg:grid-cols-3 md:gap-x-20 gap-y-8">
            <NormalInput
              name="cancelReason"
              type="text"
              label="Comments"
              placeholder="Please Enter your Comments"
              isrequired={false}
              error={methods.formState.errors.cancelReason?.message}
            />
          </div>
          <div className="border-grey-line border-b mt-10 mb-5" />
          <ButtonContainer
            labelLeft="cancel"
            labelRight="update comments"
            handleClose={() => {
              slug[0] == "add"
                ? methods.reset({ ...resetData() })
                : router.back();
            }}
            btnType="submit"
            isdisabledSubmit={isSented}
          />
        </form>
      </FormProvider>
    </>
  );
};

const mapDispatchToProps = (dispatch: any) => {
  return bindActionCreators({ getBookingById, getRefundUpdateApi }, dispatch);
};
export default connect(null, mapDispatchToProps)(RefundView);

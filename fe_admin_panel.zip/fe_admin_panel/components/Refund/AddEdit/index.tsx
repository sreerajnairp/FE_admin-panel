import { NormalInput } from "@/components/common/Inputs/NormalInput";
import { useForm, FormProvider } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import { RefundFormValues } from "@/types/Admin";
import { refundSchema } from "@/validations/web.schema";
import { useRouter } from "next/router";
import { ButtonContainer } from "@/components/common/ButtonContainer";
import { useCallback, useEffect, useState } from "react";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import moment from "moment";
import {
  getBookingById,
  getRefundUpdateApi,
} from "@/redux/actions/BookingApiAct";
import { DatePicker } from "@/components/common/DatePicker";
import { LoadingScreen } from "@/components/common/Loader";

const resetData = () => ({
  cancelReason: "",
  ownerId: "",
  paidAmount: "",
});

const RefundAddEdit = ({ getBookingById, getRefundUpdateApi }: any) => {
  const router = useRouter();
  const [userDetails, setUserDetails] = useState();
  const [isSented, setIsSented] = useState<boolean>(false);
  const [loadingFetch, setLoadingFetch] = useState<boolean>(false);

  const { _id = "", slug = "" } = router.query;

  const methods = useForm<RefundFormValues>({
    defaultValues: {
      ...resetData(),
    },
    resolver: yupResolver(refundSchema),
  });

  const getUserDetails = useCallback(async () => {
    if (_id) {
      setLoadingFetch(true);
      const { data } = await getBookingById(_id);
      setUserDetails(data);
      methods.reset({
        cancelReason: data?.cancelReason,
        ownerId: data?.ownerId,
        paidAmount: data?.paidAmount,
      });
      setLoadingFetch(false);
    }
  }, [_id]);

  useEffect(() => {
    if (_id) {
      getUserDetails();
    }
  }, [_id]);

  const onSubmit = async (data: any) => {
    setLoadingFetch(true);
    if (userDetails) {
      let body = {
        bookingId: _id,
        cancelReason: data?.cancelReason,
      };
      try {
        await getRefundUpdateApi(body);
        setIsSented(false);
        setTimeout(() => {
          router.push("/dashboard/refund");
        }, 2000);
        router.push("/dashboard/refund");
        setLoadingFetch(false);
      } catch (error) {
        setIsSented(false);
        setLoadingFetch(false);
      }
    }
  };

  return (
    <FormProvider {...methods}>
      <form onSubmit={methods.handleSubmit(onSubmit)}>
        {loadingFetch && <LoadingScreen />}
        <div className="grid grid-row md:grid-col md:grid-cols-2 lg:grid-cols-3 md:gap-x-20 gap-y-8">
          <NormalInput
            disabled
            name="ownerId"
            type="text"
            label="Customer Name"
            placeholder="Please Enter Your Customer Name"
            isrequired={false}
            error={methods.formState.errors.ownerId?.message}
          />
          <NormalInput
            disabled
            name="ownerId"
            type="text"
            label="Order Id"
            placeholder="Please Enter Your Order ID"
            isrequired={false}
          />
          <NormalInput
            isdisabled
            name="ownerId"
            type="text"
            label="Refund Amount"
            placeholder="Please Enter Your Refund Amount"
            isrequired={false}
            error={methods.formState.errors.ownerId?.message}
          />
          <NormalInput
            isdisabled
            name="ownerId"
            type="text"
            label="Reason for Refund"
            placeholder="Please Enter Your Reason For Refund"
            isrequired={false}
            error={methods.formState.errors.ownerId?.message}
          />
          <DatePicker
            name="ownerId"
            type="date"
            value={moment(methods.getValues("ownerId")).format("YYYY-MM-DD")}
            label="Date of Refund Request"
            isrequired={false}
            placeholder="Please select date"
          />
        </div>
        <div className="w-4/5 rounded overflow-hidden border flex justify-between mt-5">
          <div className="px-6 py-4 flex">
            <div>
              <h2 className="font-Inter mr-5 font-xl mb-2 text-dark-grey">
                Customer Name
              </h2>
              <h2 className="font-Inter mr-5 font-xl mb-2 text-dark-grey">
                Mobile No.
              </h2>
            </div>
            <div>
              <div className="font-Inter font-xl mb-2">
                {(userDetails as any)?.receiverName || "-"}
              </div>
              <div className="font-Inter font-xl mb-2">
                {(userDetails as any)?.receiverMobile || "-"}
              </div>
            </div>
          </div>
          <div className="px-6 py-4 flex">
            <div>
              <h2 className="font-Inter mr-5 font-xl mb-2 text-dark-grey">
                Email Id
              </h2>
              <h2 className="font-Inter mr-5 font-xl mb-2 text-dark-grey">
                Order Id
              </h2>
            </div>
            <div>
              <div className="font-Inter font-xl mb-2">
                {(userDetails as any)?.email || "-"}
              </div>
              <div className="font-Inter font-xl mb-2">
                {(userDetails as any)?.orderId || "-"}
              </div>
            </div>
          </div>
          <div className="px-6 py-4 flex">
            <div>
              <h2 className="font-Inter mr-5 font-xl mb-2 text-dark-grey">
                Order Date
              </h2>
              <h2 className="font-Inter mr-5 font-xl mb-2 text-dark-grey">
                Location
              </h2>
            </div>
            <div>
              <div className="font-Inter font-xl mb-2">
                {moment((userDetails as any)?.createdAt).format("YYYY-MM-DD") ||
                  "-"}
              </div>
              <div className="font-Inter font-xl mb-2">
                {(userDetails as any)?.email || "-"}
              </div>
            </div>
          </div>
        </div>
        <div className="grid grid-row md:grid-col md:grid-cols-2 lg:grid-cols-3 md:gap-x-20 gap-y-8 mt-5">
          <NormalInput
            disabled
            name="paidAmount"
            type="text"
            label="Credit Refunds"
            placeholder="Please Enter Your Credit Refunds"
            isrequired={false}
          />
          <NormalInput
            name="cancelReason"
            type="text"
            label="Comments"
            placeholder="Please Enter your Comments"
            isrequired={true}
            error={methods.formState.errors.cancelReason?.message}
          />
        </div>
        <div className="border-grey-line border-b mt-32 mb-5" />
        <ButtonContainer
          labelLeft="cancel"
          labelRight="update comments"
          handleClose={() => {
            slug[0] == "add"
              ? methods.reset({ ...resetData() })
              : router.back();
          }}
          btnType="submit"
          isdisabledSubmit={isSented}
        />
      </form>
    </FormProvider>
  );
};

const mapDispatchToProps = (dispatch: any) => {
  return bindActionCreators(
    {
      getBookingById,
      getRefundUpdateApi,
    },
    dispatch
  );
};
export default connect(null, mapDispatchToProps)(RefundAddEdit);

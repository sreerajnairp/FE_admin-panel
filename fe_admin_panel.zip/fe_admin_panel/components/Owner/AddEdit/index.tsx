import { AddPopup } from "@/components/common/AddModal";
import { NormalInput } from "@/components/common/Inputs/NormalInput";
import { NormalSelect } from "@/components/common/Inputs/NormalSelect";
import { useForm, FormProvider } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import { OwnerFormValues } from "@/types/Admin";
import { ownerSchema } from "@/validations/web.schema";
import { useRouter } from "next/router";
import { ButtonContainer } from "@/components/common/ButtonContainer";
import { useCallback, useEffect, useState } from "react";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import { FileUploadButton } from "@/components/common/ButtonUpload";
import {
  OwnerUpdateApi,
  OwnerAddApi,
  getOwnerById,
  getOwnerListApi,
} from "@/redux/actions/OwnerApiAct";
import { statusOptions, IDoptions } from "@/helpers/constants";
import { Toast } from "@/service/toast";
import { NormalMultiSelect } from "@/components/common/Inputs/NormalMultiSelect";
import pdf from "@/assets/icon/pdf.svg";
import { LoadingScreen } from "@/components/common/Loader";
import TableMatrixInput from "../TableInput";
import view from "@/assets/icon/info.png";
import Image from "next/image";
import {
  getCityByStateApi,
  getStatePermitApi,
  getCountryListApi,
  ImageUploadApi,
  getServicableListApi,
  getCityApi,
} from "@/redux/actions/CommonApiAct";

const resetData = () => ({
  fName: "",
  lName: "",
  mobile: "",
  alternatePhone: null,
  email: "",
  companyName: "",
  baseLocation: null,
  serviceableLocation: [],
  pricePerTon: [],
  pricePerKm: [],
  // noOfTruck: 0,
  gstNo: "",
  idProofType: null,
  document: null,
  profilePicture: null,
  // noOfDriver: 0,
  streetName: "",
  ownerState: null,
  city: null,
  country: "",
  zipCode: "",
  companyAddress: "",
  companyCountry: "",
  companyState: null,
  companyCity: null,
  companyZipcode: null,
  status: 1,
});

const OwnerAddUpdate = ({
  OwnerUpdateApi,
  OwnerAddApi,
  getOwnerById,
  ImageUploadApi,
  getServicableListApi,
  getCountryListApi,
  getStatePermitApi,
  getCityByStateApi,
  getCityApi,
}: any) => {
  const router = useRouter();
  const [popUp, setPopUp] = useState<boolean>(false);
  const [userDetails, setUserDetails] = useState();
  const [isSented, setIsSented] = useState<boolean>(false);
  const [profileImage, setProfileImage] = useState<string>("");
  const [documentData, setDocumentData] = useState<string>("");
  const [servicable, setServicable] = useState([]);
  const [showPrice, setShowPrice] = useState<boolean>(true);
  const [base, setBase] = useState([]);
  const { _id = "", slug = "" } = router.query;
  const [loadingFetch, setLoadingFetch] = useState<boolean>(false);
  const [countryOptions, setCountryOptions] = useState([]);
  const [selectedState, setSelectedState] = useState([]);
  const [cityOptions, setCityOptions] = useState([]);
  const [ownerCity, setOwnerCity] = useState([]);
  const [isOwnerStateMounted, setIsOwnerStateMounted] = useState(false);
  const [isCompanyStateMounted, setIsCompanyStateMounted] = useState(false);
  const [companyState, setCompanyState] = useState([]);

  const methods = useForm<OwnerFormValues>({
    defaultValues: {
      ...resetData(),
    },
    resolver: yupResolver(ownerSchema),
  });
  const pricePerKmWatch = methods.watch<any>("pricePerKm");
  const pricePerTonWatch = methods.watch<any>("pricePerTon");
  const ServiceLocationSelect = methods.watch<any>("serviceableLocation");

  const getServicableFunc = () => {
    const cityIds = methods.getValues("serviceableLocation");
    let query = {
      cityIds: _id ? cityIds.join(",") : null,
    };
    getServicableListApi(query).then(({ data }: any) => {
      setServicable(
        data?.map((res: any) => {
          return {
            value: res.id,
            label: res.city,
          };
        })
      );
    });
  };

  const getBaseFunc = () => {
    let query = {
      id: methods.getValues("baseLocation"),
    };
    getCityApi(query).then(({ data }: any) => {
      setBase(
        data?.map((res: any) => {
          return {
            value: res.id,
            label: res.city,
          };
        })
      );
    });
  };

  const getCountryDropDown = () => {
    getCountryListApi().then(({ data }: any) => {
      setCountryOptions(
        data?.map((res: any) => {
          return {
            value: res.name,
            label: res.name,
          };
        })
      );
    });
  };

  const getstateFunc = () => {
    let query = {
      isGeneral: true,
      id: methods.getValues("ownerState"),
    };
    getStatePermitApi(query).then(({ data }: any) => {
      const states = data?.list?.map((res: any) => {
        return {
          value: res.id,
          label: res.state,
        };
      });
      setSelectedState(states);
    });
  };

  const getCompanyStateFunc = () => {
    let query = {
      isGeneral: true,
      id: methods.getValues("companyState"),
    };
    getStatePermitApi(query).then(({ data }: any) => {
      const states = data?.list?.map((res: any) => {
        return {
          value: res.id,
          label: res.state,
        };
      });
      setCompanyState(states);
    });
  };

  const getOwnerCityFunc = (id: any) => {
    let query = {
      isGeneral: true,
      cityId: methods.getValues("city"),
    };
    getCityByStateApi(id, query).then(({ data }: any) => {
      if (data?.list.length > 0) {
        setOwnerCity(
          data?.list?.map((res: any) => {
            return {
              value: res.id,
              label: res.city,
            };
          })
        );
      } else {
        setOwnerCity([]);
      }
    });
  };
  const getCompanyCityFunc = (id: any) => {
    let query = {
      isGeneral: true,
      cityId: methods.getValues("companyCity"),
    };
    getCityByStateApi(id, query).then(({ data }: any) => {
      setCityOptions(
        data?.list?.map((res: any) => {
          return {
            value: res.id,
            label: res.city,
          };
        })
      );
    });
  };

  const getEnqiureDetails = useCallback(async () => {
    if (_id) {
      setLoadingFetch(true);
      const { data } = await getOwnerById(_id);
      setUserDetails(data);
      methods.reset({
        fName: data?.fName,
        lName: data?.lName,
        mobile: data?.mobile,
        alternatePhone: data?.alternatePhone,
        email: data?.email,
        companyName: data?.companyName,
        baseLocation: data?.baseLocation,
        serviceableLocation: data?.ownerCity.map((a: any) => a.cityId),
        pricePerTon: data?.pricePerTon,
        pricePerKm: data?.pricePerKm,
        gstNo: data?.gstNo,
        idProofType: parseInt(data?.idProofType),
        document: data?.document,
        profilePicture: data?.profilePicture,
        streetName: data?.streetName,
        city: data?.city,
        country: data?.country,
        zipCode: data?.zipCode,
        companyAddress: data?.companyAddress,
        companyCity: data?.companyCity,
        companyZipcode: data?.companyZipcode,
        companyCountry: data?.companyCountry,
        companyState: data?.companyState,
        ownerState: data?.ownerState,
        status: data?.status,
      });
      setDocumentData(data?.document);
      setProfileImage(data?.profilePicture);
      setLoadingFetch(false);
      getstateFunc();
      getCompanyStateFunc();
      getCountryDropDown();
      getBaseFunc();
      getServicableFunc();
    }
  }, [_id]);

  useEffect(() => {
    if (_id) {
      getEnqiureDetails();
    }
  }, [_id]);
  useEffect(() => {
    if (!_id) {
      getstateFunc();
      getCompanyStateFunc();
      getCountryDropDown();
      getBaseFunc();
      getServicableFunc();
    }
  }, []);

  const handleFileUpload = async (e: any) => {
    methods.clearErrors("document");
    let file = e.target.files[0];
    if (file) {
      const fileType = file.type;
      if (
        fileType === "image/jpg" ||
        fileType === "image/jpeg" ||
        fileType === "image/png" ||
        fileType === "image/webp" ||
        fileType === "application/pdf"
      ) {
        const fileSizeInMB = file.size / (1024 * 1024);
        if (fileSizeInMB < 3) {
          const reader = new FileReader();
          reader.onload = (event) => {
            const previewUrl = event.target?.result as string;
            fileType === "application/pdf"
              ? setDocumentData(pdf)
              : setDocumentData(previewUrl);
          };
          reader.readAsDataURL(file);
          methods.setValue("document", file);
        } else {
          Toast({
            type: "error",
            message: "File Size should not exceed 3MB.",
          });
          e.target.value = "";
        }
      } else {
        Toast({
          type: "error",
          message: "Only JPG, JPEG, PDF and PNG files are allowed.",
        });
        e.target.value = "";
      }
    }
  };

  const handleProfileUpload = async (e: any) => {
    methods.clearErrors("profilePicture");
    let file = e.target.files[0];
    if (file) {
      const fileType = file.type;
      if (
        fileType === "image/jpg" ||
        fileType === "image/jpeg" ||
        fileType === "image/png" ||
        fileType === "image/webp"
      ) {
        const fileSizeInMB = file.size / (1024 * 1024);
        if (fileSizeInMB < 3) {
          const reader = new FileReader();
          reader.onload = (event) => {
            const previewUrl = event.target?.result as string;
            setProfileImage(previewUrl);
          };
          reader.readAsDataURL(file);
          methods.setValue("profilePicture", file);
        } else {
          Toast({
            type: "error",
            message: "File Size should not exceed 3MB.",
          });
          e.target.value = "";
        }
      } else {
        Toast({
          type: "error",
          message: "Only JPG, JPEG and PNG files are allowed.",
        });
        e.target.value = "";
      }
    }
  };

  const filterData = (data: any, key: string, ServiceLocationSelect: any) => {
    return data[key]?.filter(
      (item: any) =>
        ServiceLocationSelect?.includes(item?.fromCityId) &&
        ServiceLocationSelect?.includes(item?.toCityId)
    );
  };

  const appendDataToFormData = (
    formData: FormData,
    data: any,
    filteredPricePerKm: any,
    filteredPricePerTon: any
  ) => {
    Object.keys(data).forEach((key) => {
      if (data[key] !== null && data[key] !== undefined) {
        if (key === "serviceableLocation" && Array.isArray(data[key])) {
          data[key].forEach((item: any, index: any) => {
            formData.append(`${key}[${index}]`, item);
          });
        } else if (key === "pricePerKm") {
          formData.append("pricePerKm", JSON.stringify(filteredPricePerKm));
        } else if (key === "pricePerTon") {
          formData.append("pricePerTon", JSON.stringify(filteredPricePerTon));
        } else {
          formData.append(key, data[key]);
        }
      }
    });
  };

  const handleApiCall = async (
    formData: FormData,
    userDetails: any,
    query: any,
    _id: any
  ) => {
    try {
      if (userDetails) {
        formData.append("userId", userDetails?.userId);
        formData.append("userAddressId", userDetails?.userAddressId);
        await OwnerUpdateApi(formData, query);
      } else {
        await OwnerAddApi(formData);
      }
      return true;
    } catch (error) {
      console.log(error);
      return false;
    }
  };

  const onSubmit = async (data: any) => {
    setIsSented(true);
    setLoadingFetch(true);

    const filteredPricePerKm = filterData(
      data,
      "pricePerKm",
      ServiceLocationSelect
    );
    const filteredPricePerTon = filterData(
      data,
      "pricePerTon",
      ServiceLocationSelect
    );
    if (filteredPricePerKm.length !== filteredPricePerTon.length) {
      Toast({
        type: "error",
        message: "Price/Ton Should Not Have Empty Fields",
      });
      setIsSented(false);
      setLoadingFetch(false);
      return;
    }

    const formData = new FormData();
    appendDataToFormData(
      formData,
      data,
      filteredPricePerKm,
      filteredPricePerTon
    );

    const query = { id: _id };
    const apiCallSuccess = await handleApiCall(
      formData,
      userDetails,
      query,
      _id
    );

    if (apiCallSuccess) {
      setPopUp(true);
      setTimeout(() => {
        router.push("/dashboard/owner");
      }, 2000);
    }
    setLoadingFetch(false);
    setIsSented(false);
  };

  useEffect(() => {
    if (methods.getValues("ownerState") && methods.watch("ownerState")) {
      const id = methods.getValues("ownerState");
      const ownerStateID = id.value ? id.value : id;
      if (isOwnerStateMounted) {
        methods.setValue("city", null);
      } else {
        setIsOwnerStateMounted(true);
      }
      getOwnerCityFunc(ownerStateID);
    }
  }, [methods.getValues("ownerState"), methods.watch("ownerState")]);

  useEffect(() => {
    if (methods.getValues("companyState") && methods.watch("companyState")) {
      const id = methods.getValues("companyState");
      const companyStateID = id.value ? id.value : id;
      getCompanyCityFunc(companyStateID);
      if (isCompanyStateMounted) {
        methods.setValue("companyCity", null);
      } else {
        setIsCompanyStateMounted(true);
      }
    }
  }, [methods.getValues("companyState"), methods.watch("companyState")]);
  useEffect(() => {
    if (methods.getValues("idProofType") && methods.watch("idProofType")) {
      if (isOwnerStateMounted) {
        setDocumentData("");
        methods.setValue("document", null);
      } else {
        setIsOwnerStateMounted(true);
      }
    }
  }, [methods.getValues("idProofType"), methods.watch("idProofType")]);
  return (
    <FormProvider {...methods}>
      <form onSubmit={methods.handleSubmit(onSubmit)}>
        {loadingFetch && <LoadingScreen />}
        <div className="grid grid-row md:grid-col md:grid-cols-2 lg:grid-cols-3 md:gap-x-20 gap-y-8">
          <NormalInput
            name="fName"
            type="text"
            label="First Name"
            placeholder="Please Enter First Name"
            isrequired={true}
            error={methods.formState.errors.fName?.message}
          />
          <NormalInput
            name="lName"
            type="text"
            label="Last Name"
            placeholder="Please Enter Last Name"
            isrequired={true}
            error={methods.formState.errors.lName?.message}
          />
          <NormalInput
            name="mobile"
            type="number"
            label="Phone Number"
            placeholder="Please Enter Phone Number"
            isrequired={true}
            error={methods.formState.errors.mobile?.message}
          />
          <NormalInput
            name="alternatePhone"
            type="number"
            label="Alternate Phone Number"
            placeholder="Please Enter Phone Number"
            isrequired={false}
            error={methods.formState.errors.alternatePhone?.message}
          />
          <NormalInput
            name="email"
            type="email"
            label="Email ID"
            placeholder="Please Enter Email ID"
            isrequired={false}
            error={methods.formState.errors.email?.message}
          />
          <NormalInput
            name="companyName"
            type="text"
            label="Company Name"
            placeholder="Please Enter Company Name"
            isrequired={true}
            error={methods.formState.errors.companyName?.message}
          />
          <NormalInput
            name="gstNo"
            type="text"
            label="GST No."
            placeholder="Please Enter GST No."
            isrequired={true}
            inputStyles={"uppercase"}
            error={methods.formState.errors.gstNo?.message}
          />
          <NormalSelect
            options={IDoptions}
            placeholder="Please select ID Proof"
            label="ID Proof"
            name="idProofType"
            isrequired={true}
            error={methods.formState.errors.idProofType?.message}
          />
          <FileUploadButton
            id={"Upload Document"}
            uploadImage={documentData}
            onPerviewClose={() => {
              setDocumentData("");
              methods.setValue("document", null);
            }}
            label={"Document"}
            placeholder="Please Upload document"
            onFileSubmit={(e: any) => handleFileUpload(e)}
            ImageSize={100}
            isrequired={true}
            error={methods.formState.errors.document?.message}
          />
          <FileUploadButton
            id={"Profile Pic"}
            uploadImage={profileImage}
            onPerviewClose={() => {
              setProfileImage("");
              methods.setValue("profilePicture", null);
            }}
            label={"Profile Pic"}
            placeholder="Please Upload Profile Pic"
            onFileSubmit={(e: any) => handleProfileUpload(e)}
            ImageSize={100}
            isrequired={false}
            error={methods.formState.errors.profilePicture?.message}
          />
          <NormalSelect
            options={base}
            placeholder="Please select Base Location"
            label="Base Location"
            name="baseLocation"
            isrequired={true}
            error={methods.formState.errors.baseLocation?.message}
          />
          <NormalMultiSelect
            name="serviceableLocation"
            placeholder="Please Select Service location"
            label="Service Location"
            options={servicable}
            isrequired={true}
            error={methods.formState.errors.serviceableLocation?.message}
          />
        </div>
        <div className="border-b border-grey-line my-5">
          <ul className="flex flex-wrap">
            <li className="">
              <button
                type="button"
                onClick={() => setShowPrice(true)}
                className={`${
                  showPrice &&
                  "text-primary_color border-b-4 border-primary_color rounded-t-lg active "
                } inline-block p-4 rounded-t-lg font-xl font-Inter font-normal text-grey`}
              >
                <div className="flex items-center">
                  Price / Km <span className="text-red-600"> * </span>
                  <div className="has-tooltip">
                    <span className="tooltip rounded shadow-lg p-1 bg-light-grey text-sm text-gray-black -mt-8">
                      Price per km is applicable for Tanker trucks
                    </span>
                    <Image
                      src={view}
                      alt="view"
                      height={20}
                      width={20}
                      className="ml-2 flex justify-center"
                    />
                  </div>
                </div>
              </button>
            </li>
            <li className="me-2">
              <button
                type="button"
                onClick={() => setShowPrice(false)}
                className={`${
                  !showPrice &&
                  "text-primary_color border-b-4 border-primary_color rounded-t-lg active "
                } inline-block p-4 rounded-t-lg font-xl font-Inter font-normal text-grey`}
              >
                <div className="flex items-center">
                  Price / Ton <span className="text-red-600"> * </span>
                  <div className="has-tooltip">
                    <span className="tooltip rounded shadow-lg p-1 bg-light-grey text-sm text-gray-black -mt-8">
                      View Price per Ton is applicable for Box, Semi-trailer,
                      Flatbed & Standard Trucks <br /> based on the truck
                      capacity, the price will be calculated
                    </span>
                    <Image
                      src={view}
                      alt="view"
                      height={20}
                      width={20}
                      className="ml-2 flex justify-center"
                    />
                  </div>
                </div>
              </button>
            </li>
          </ul>
        </div>
        {showPrice ? (
          <TableMatrixInput
            key="price"
            title={"Price / Km"}
            serviceableLocation={ServiceLocationSelect}
            serviceableLocationOption={servicable}
            perkms={pricePerKmWatch}
            onDataChange={(value: any) => methods.setValue("pricePerKm", value)}
          />
        ) : (
          <TableMatrixInput
            key="ton"
            title={"Price / Ton"}
            serviceableLocation={ServiceLocationSelect}
            serviceableLocationOption={servicable}
            perkms={pricePerTonWatch}
            onDataChange={(value: any) =>
              methods.setValue("pricePerTon", value)
            }
          />
        )}
        <div className="mb-5 mt-8 text-primary_color text-xl font-semibold font-Inter">
          Address Details
        </div>
        <div className="grid grid-row md:grid-col md:grid-cols-2 lg:grid-cols-3 md:gap-x-20 gap-y-8">
          <NormalInput
            name="streetName"
            type="text"
            label="Owner Address"
            placeholder="Please Enter Owner Address"
            isrequired={false}
            error={methods.formState.errors.streetName?.message}
          />
          <NormalSelect
            options={countryOptions}
            placeholder="Please Select Your Owner Country"
            label="Country"
            name="country"
            isrequired={true}
            error={methods.formState.errors.country?.message}
          />
          <NormalSelect
            options={selectedState}
            placeholder="Please Select Owner State"
            label="Owner State"
            name="ownerState"
            isrequired={true}
            error={methods.formState.errors.ownerState?.message}
          />
          <NormalSelect
            options={ownerCity}
            placeholder="Please select Owner City / Town"
            label="Owner City / Town"
            name="city"
            isrequired={true}
            error={methods.formState.errors.city?.message}
          />
          <NormalInput
            name="zipCode"
            type="number"
            label="Owner Zip Code"
            placeholder="Please Enter Owner Zip Code"
            isrequired={false}
            error={methods.formState.errors.zipCode?.message}
          />
          <NormalInput
            name="companyAddress"
            type="text"
            label="Company Address"
            placeholder="Please Enter Company Address"
            isrequired={false}
            error={methods.formState.errors.companyAddress?.message}
          />
          <NormalSelect
            options={countryOptions}
            placeholder="Please Select Company Country"
            label="Company Country"
            name="companyCountry"
            isrequired={true}
            error={methods.formState.errors.companyCountry?.message}
          />
          <NormalSelect
            options={companyState}
            placeholder="Please Select Company State"
            label="Company State"
            name="companyState"
            isrequired={true}
            error={methods.formState.errors.companyState?.message}
          />
          <NormalSelect
            options={cityOptions}
            placeholder="Please select company city"
            label="Company City"
            name="companyCity"
            isrequired={true}
            error={methods.formState.errors.companyCity?.message}
          />
          <NormalInput
            name="companyZipcode"
            type="number"
            label="Company Zip Code"
            placeholder="Please Enter Company Zip Code"
            isrequired={false}
            error={methods.formState.errors.companyZipcode?.message}
          />
          <NormalSelect
            options={statusOptions}
            placeholder="Please select status"
            label="Status"
            name="status"
            isrequired={false}
            error={methods.formState.errors.status?.message}
          />
        </div>
        <div className="border-grey-line border-b my-10" />
        <ButtonContainer
          labelLeft="cancel"
          labelRight={slug[0] == "add" ? "add owner" : "update"}
          handleClose={() => router.back()}
          btnType="submit"
          isdisabledSubmit={isSented}
        />
        {popUp && (
          <AddPopup
            title={slug[0] == "add" ? "added!" : "updated!"}
            success={
              slug[0] == "add"
                ? "owner added successfully"
                : "owner Updated successfully"
            }
          />
        )}
      </form>
    </FormProvider>
  );
};

const mapDispatchToProps = (dispatch: any) => {
  return bindActionCreators(
    {
      OwnerUpdateApi,
      OwnerAddApi,
      getOwnerById,
      getOwnerListApi,
      getCountryListApi,
      ImageUploadApi,
      getServicableListApi,
      getStatePermitApi,
      getCityByStateApi,
      getCityApi,
    },
    dispatch
  );
};
export default connect(null, mapDispatchToProps)(OwnerAddUpdate);

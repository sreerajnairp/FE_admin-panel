import React, { useEffect, useState } from 'react';

const TableMatrixInput = ({ title, serviceableLocation, serviceableLocationOption, perkms, onDataChange }: any) => {
  const [servicableList, setServicableList] = useState<any>([]);
  const [data, setData] = useState<any>([]);

  useEffect(() => {
    setServicableList(serviceableLocationOption.filter((option: any) =>
      serviceableLocation?.includes(option.value)
    ));
  }, [serviceableLocation, serviceableLocationOption]);
  useEffect(() => {
    if (perkms.length || servicableList.length) {
      const newData = [];
      for (const location of servicableList) {
        for (const subLocation of servicableList) {
          const existingItem = perkms.find((item: { fromCityId: number; toCityId: any; }) => item.fromCityId === location?.value && item.toCityId === subLocation?.value);
          const price = existingItem ? existingItem.price : '';
          newData.push({
            fromCityId: location?.value,
            toCityId: subLocation?.value,
            price: price
          });
        }
      }
      setData(newData);
    }
  }, [perkms, servicableList]);
  

  const handleInputChange = (fromCityId: number, toCityId: number, value: string) => {
    const newData = [...data];
    const itemIndex = newData.findIndex(item => item.fromCityId === fromCityId && item.toCityId === toCityId);
    if (itemIndex !== -1) {
      newData[itemIndex] = {
        ...newData[itemIndex],
        price: parseInt(value)
      };
      setData(newData);
      onDataChange(newData);
    }
  };
  const numberInputOnWheelPreventChange = (e: any) => {
    e.target.blur()
  }
  const generateInputsForRow = (fromCityId: number, index: number) => {
    return servicableList.map((location: any) => {
      const price = data.find((item: { fromCityId: number; toCityId: any; }) => item.fromCityId === fromCityId && item.toCityId === location.value)?.price || '';
      return (
        <td key={location.value} className="px-4 py-3">
          <input
            type="number"
            className={`h-11 w-full rounded-lg border p-4 font-Inter outline-gray-50 bg-light-grey max-w-32`}
            placeholder="" 
            min="1"
            max="999999"
            required={true}
            value={price}
            onWheel={numberInputOnWheelPreventChange}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => handleInputChange(fromCityId, location.value, e.target.value)}
          />
        </td>
      );
    });
  };

  const generateRows = () => {
    return servicableList.map((location: any, index: number) => (
      <tr key={location.value} className="bg-white">
        <th scope="row" className="sticky left-2 bg-white z-9 px-4 py-3 font-medium text-gray-900">
          {location.label}
        </th>
        {generateInputsForRow(location.value, index)}
      </tr>
    ));
  };

  return (
    <div className="w-full max-h-96 overflow-x-auto overflow-y-auto shadow-md sm:rounded-lg">
      <table className="w-full text-sm text-left text-gray-500">
        <thead className="text-sm font-Inter text-white capitalize bg-primary_color sticky top-0 z-10">
          <tr>
            <th scope="col" className="px-4 py-3 whitespace-nowrap">
              {title}
            </th>
            {servicableList?.length > 0 && (
              servicableList.map((location: any) => (
                <th key={location.value} scope="col" className="py-3 text-center">
                  <p className=" font-xl font-Inter font-normal w-36 break-all">{location.label}</p>
                </th>
              ))
            )}
          </tr>
        </thead>
        <tbody>
          {servicableList?.length > 0 ?
            generateRows()
            :
            <tr className="text-center">
              <td
                colSpan={12}
                className="font-Inter font-normal px-4 py-3 font-lg text-center"
              >
                Please Select Service location !
              </td>
            </tr>
          }
        </tbody>
      </table>
    </div>
  );
};

export default TableMatrixInput;

import { useRouter } from "next/router";
import { useState, useCallback, useEffect } from "react";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import TableWrapper from "@/components/common/TableWrapper";
import edit from "@/assets/icon/edit.png";
import Image from "next/image";
import { getOwnerById } from "@/redux/actions/OwnerApiAct";
import { ownerHeader, driverHeader, IDProofValue } from "@/helpers/constants";
import { PageMeta } from "@/types/common";
import Truck from "@/assets/icon/truckColor.png";
import Driver from "@/assets/icon/tieColor.png";
import trash from "@/assets/icon/trash.svg";
import view from "@/assets/icon/view.svg";
import {
  getTruckListApi,
  TruckUpdateStatusApi,
  TruckDeleteApi,
} from "@/redux/actions/TruckApiAct";
import { DeleteModal } from "@/components/common/DeleteModal";
import {
  DriverDeleteApi,
  DriverUpdateStatusApi,
  getDriverListApi,
} from "@/redux/actions/DriverApiAct";
import { renderDocument } from "@/service/utilities";
import { LoadingScreen } from "@/components/common/Loader";
import Pagination from "@/components/common/Pagination";

const OwnerView = ({
  getOwnerById,
  getTruckListApi,
  getDriverListApi,
  TruckUpdateStatusApi,
  TruckDeleteApi,
  DriverDeleteApi,
  DriverUpdateStatusApi,
}: any) => {
  const router = useRouter();
  const { _id = "" } = router.query;
  const [ownerDetails, setOwnerDetails] = useState(null);
  const [userData, setUserData] = useState([]);
  const [pageMeta, setPageMeta] = useState<PageMeta>();
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [page, setPage] = useState(1);
  const [driverData, setDriverData] = useState([]);
  const [pageMetaDriver, setPageMetaDriver] = useState<PageMeta>();
  const [rowsPerPageDriver, setRowsPerPageDriver] = useState(10);
  const [pageDriver, setPageDriver] = useState(1);
  const [deleteModal, setDeleteModal] = useState(false);
  const [id, setId] = useState("");
  const [deleteTruckModal, setDeleteTruckModal] = useState(false);
  const [truckId, setTruckId] = useState<string>("");
  const [document, setDocument] = useState<string>("");
  const [profilePic, setProfilePic] = useState<string>("");
  const [loadingFetch, setLoadingFetch] = useState(true);
  const [loadingTruck, setLoadingTruck] = useState(true);
  const [loadingDriver, setLoadingDriver] = useState(true);
  const [showPrice, setShowPrice] = useState<boolean>(true);

  const getOwnerDetails = useCallback(async () => {
    if (_id) {
      const { data } = await getOwnerById(_id);
      setOwnerDetails(data);
      setProfilePic(data?.profilePicture);
      setDocument(data?.document);
      setLoadingFetch(false);
    }
  }, [_id]);

  useEffect(() => {
    if (_id) {
      getOwnerDetails();
    }
  }, [_id]);

  useEffect(() => {
    if (_id) {
      getAllTruckApiFunc();
      getAllDriverApiFunc();
    }
  }, [_id, page, rowsPerPage, pageDriver, rowsPerPageDriver]);

  const getAllTruckApiFunc = () => {
    let query: any = {
      page: page,
      size: rowsPerPage,
      ownerId: _id,
    };
    setLoadingTruck(true);
    getTruckListApi(query)
      .then(({ data }: any) => {
        setUserData(data.list);
        setPageMeta(data.pageMeta);
        setLoadingTruck(false);
      })
      .catch((e: any) => {
        console.log(e);
        setLoadingTruck(false);
      });
  };

  const getAllDriverApiFunc = () => {
    let query = {
      page: pageDriver,
      size: rowsPerPageDriver,
      ownerId: _id,
    };
    setLoadingDriver(true);
    getDriverListApi(query)
      .then(({ data }: any) => {
        setDriverData(data.list);
        setPageMetaDriver(data.pageMeta);
        setLoadingDriver(false);
      })
      .catch((e: any) => {
        console.log(e);
        setLoadingDriver(false);
      });
  };

  const handleOpen = (id: string) => {
    setTruckId(id);
    setDeleteTruckModal(true);
  };

  const StatusUpdate = (status: boolean, id: string) => {
    let body = {
      id,
      status: status ? 1 : 0,
    };
    setLoadingTruck(true);
    TruckUpdateStatusApi(body)
      .then(({ data }: any) => {
        getAllTruckApiFunc();
      })
      .catch((e: any) => {
        console.log(e);
        setLoadingTruck(false);
      });
  };

  const handleDeleteModalTruck = () => {
    let body = {
      id: [truckId],
    };
    setLoadingTruck(true);
    TruckDeleteApi(body)
      .then(({ data }: any) => {
        getAllTruckApiFunc();
        setDeleteTruckModal(false);
      })
      .catch((e: any) => {
        console.log(e);
        setLoadingTruck(false);
      });
  };

  const handleDriverOpen = (id: string) => {
    setId(id);
    setDeleteModal(true);
  };
  const StatusUpdateDriver = (status: boolean, id: string) => {
    let body = {
      id,
      status: status ? 1 : 0,
    };
    setLoadingDriver(true);
    DriverUpdateStatusApi(body)
      .then(({ data }: any) => {
        getAllDriverApiFunc();
      })
      .catch((e: any) => {
        console.log(e);
        setLoadingDriver(false);
      });
  };
  const handleDeleteModalSumbit = () => {
    let body = {
      id: [id],
    };
    setLoadingDriver(true);
    DriverDeleteApi(body)
      .then(({ data }: any) => {
        getAllDriverApiFunc();
        setDeleteModal(false);
      })
      .catch((e: any) => {
        console.log(e);
        setLoadingDriver(false);
      });
  };

  const generatePricePer = (fromCityId: number, index: number, priceprevalue : string) => {
    return (ownerDetails as any)?.serviceableLocation?.map((location: any) => {
      const price =
        (ownerDetails as any)?.[priceprevalue]?.find(
          (item: { fromCityId: number; toCityId: any }) =>
            item.fromCityId === fromCityId && item.toCityId === location.id
        )?.price || "";
      return (
        <td key={location.id} className="px-4 py-3  text-center">
          <th>{price}</th>
        </td>
      );
    });
  };

  const isLoading = loadingFetch || loadingDriver || loadingTruck;

  const hasServiceableLocations =
    (ownerDetails as any)?.serviceableLocation?.length > 0;

  const renderServiceableLocationRow = (location: any, index: any, price : string) => (
    <tr key={location.id} className="bg-white">
      <th
        scope="row"
        className="sticky left-2 bg-white z-9 px-4 py-3 font-medium text-gray-900"
      >
        {location.city}
      </th>
      {generatePricePer(location.id, index, price)}
    </tr>
  );

  const truckTable = (userData || router.query.truck) && !router.query.driver;
  const driverTable = (driverData || router.query.driver) && !router.query.truck;

  const renderServiceableLocations = (price: string) => {
    if (hasServiceableLocations) {
      return (ownerDetails as any).serviceableLocation.map(
        (location: any, index: any) =>
          renderServiceableLocationRow(location, index, price)
      );
    } else {
      return (
        <tr className="text-center">
          <td
            colSpan={12}
            className="font-Inter font-normal px-4 py-3 font-lg text-center"
          >
            Please Select Service location!
          </td>
        </tr>
      );
    }
  };

  return (
    <>
      {isLoading && <LoadingScreen />}
      {!router.query.driver && !router.query.truck && (
        <>
          <div className="flex flex-col md:flex-row md:space-x-5">
            <div className="w-full md:w-auto">
              <h3 className="text-primary_color font-Inter capitalize flex items-center text-xl font-extrabold mb-2 mt-2">
                Owner Details
              </h3>
              <table className="border-collapse border border-solid border-gray-400 h-full w-full">
                <tbody>
                  <tr>
                    <th className="px-4 pt-4 text-start">Owner Name:</th>
                    <td className="px-4 pt-4">
                      {(ownerDetails as any)?.fName || "-"}{" "}
                      {(ownerDetails as any)?.lName || "-"}
                    </td>
                  </tr>
                  <tr>
                    <th className="px-4 pt-4 text-start">Owner Address:</th>
                    <td className="px-4 pt-4">
                      {(ownerDetails as any)?.streetName || "-"}
                    </td>
                  </tr>
                  <tr>
                    <th className="px-4 pt-4 text-start">Email:</th>
                    <td className="px-4 pt-4">
                      {" "}
                      {(ownerDetails as any)?.email || "-"}
                    </td>
                  </tr>
                  <tr>
                    <th className="px-4 pt-4 text-start">Mobile Number:</th>
                    <td className="px-4 pt-4">
                      {(ownerDetails as any)?.mobile || "-"}
                    </td>
                  </tr>
                  <tr>
                    <th className="px-4 py-4 text-start">Service Location:</th>
                    <td className="px-4 py-4 break-all w-72">
                      {(ownerDetails as any)?.ownerCity
                        .map((a: any) => a.city.city)
                        .join(", ") || "-"}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
            <div className="mt-5 md:mt-0 flex-grow">
              <h3 className="text-primary_color font-Inter capitalize flex items-center text-xl font-extrabold mb-2 mt-2">
                {IDProofValue[(ownerDetails as any)?.idProofType] || "Document"}
              </h3>
              <table
                aria-hidden="true"
                className="border-collapse w-full h-full border border-solid border-gray-400"
              >
                <tbody>
                  <tr>
                    <td className="p-4">
                      {document
                        ? renderDocument(document)
                        : "Document Not Uploaded"}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
            <div className="mt-5 md:mt-0 flex-grow">
              <h3 className="text-primary_color font-Inter capitalize flex items-center text-xl font-extrabold mb-2 mt-2">
                Profile Picture
              </h3>
              <table
                aria-hidden="true"
                className="border-collapse w-full h-full border border-solid border-gray-400"
              >
                <tbody>
                  <tr>
                    <td className="p-4">
                      {profilePic
                        ? renderDocument(profilePic)
                        : "Profile Not Uploaded"}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
          <div className="gap-5 grid grid-cols-1 md:grid-cols-2 mt-16">
            <div>
              <h3 className="text-primary_color font-Inter capitalize flex items-center text-xl font-extrabold mb-2 mt-2">
                Owner Address
              </h3>
              <table className="border-collapse border border-solid border-gray-400 h-full w-full">
                <tbody>
                  <tr>
                    <th className="px-4 pt-4 text-start">Address:</th>
                    <td className="px-4 pt-4">
                      {(ownerDetails as any)?.streetName || "-"}
                    </td>
                  </tr>
                  <tr>
                    <th className="px-4 pt-4 text-start">Country:</th>
                    <td className="px-4 pt-4">
                      {(ownerDetails as any)?.country || "-"}
                    </td>
                  </tr>
                  <tr>
                    <th className="px-4 pt-4 text-start">State:</th>
                    <td className="px-4 pt-4">
                      {(ownerDetails as any)?.ownerStateName || "-"}
                    </td>
                  </tr>
                  <tr>
                    <th className="px-4 pt-4 text-start">City:</th>
                    <td className="px-4 pt-4">
                      {(ownerDetails as any)?.cityName || "-"}
                    </td>
                  </tr>
                  <tr>
                    <th className="px-4 py-4 text-start">Zip Code:</th>
                    <td className="px-4 py-4">
                      {(ownerDetails as any)?.zipCode || "-"}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
            <div className="mt-5 md:mt-0">
              <h3 className="text-primary_color font-Inter capitalize flex items-center text-xl font-extrabold mb-2 mt-2">
                Company Address
              </h3>
              <table className="border-collapse border border-solid border-gray-400  h-full w-full">
                <tbody>
                  <tr>
                    <th className="px-4 pt-4 text-start">Address:</th>
                    <td className="px-4 pt-4">
                      {(ownerDetails as any)?.companyAddress || "-"}
                    </td>
                  </tr>
                  <tr>
                    <th className="px-4 pt-4 text-start">Country:</th>
                    <td className="px-4 pt-4">
                      {(ownerDetails as any)?.companyCountry || "-"}
                    </td>
                  </tr>
                  <tr>
                    <th className="px-4 pt-4 text-start">State:</th>
                    <td className="px-4 pt-4">
                      {(ownerDetails as any)?.companyStateName || "-"}
                    </td>
                  </tr>
                  <tr>
                    <th className="px-4 pt-4 text-start">City:</th>
                    <td className="px-4 pt-4">
                      {(ownerDetails as any)?.companyCityName || "-"}
                    </td>
                  </tr>
                  <tr>
                    <th className="px-4 py-4 text-start">Zip Code:</th>
                    <td className="px-4 py-4">
                      {(ownerDetails as any)?.companyZipcode || "-"}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
          <div className="border-b border-grey-line mb-5 mt-12">
            <ul className="flex flex-wrap">
              <li className="">
                <button
                  type="button"
                  onClick={() => setShowPrice(true)}
                  className={`${
                    showPrice
                      ? "text-primary_color border-b-4 border-primary_color rounded-t-lg active "
                      : ""
                  } inline-block p-4 rounded-t-lg font-xl font-Inter font-normal text-grey`}
                >
                  Price / Km
                </button>
              </li>
              <li className="me-2">
                <button
                  type="button"
                  onClick={() => setShowPrice(false)}
                  className={`${
                    !showPrice
                      ? "text-primary_color border-b-4 border-primary_color rounded-t-lg active "
                      : ""
                  } inline-block p-4 rounded-t-lg font-xl font-Inter font-normal text-grey`}
                >
                  Price / Ton
                </button>
              </li>
            </ul>
          </div>
          {showPrice ? (
            <div className="w-full max-h-96 overflow-x-auto overflow-y-auto shadow-md sm:rounded-lg">
              <table className="w-full text-sm text-left text-gray-500">
                <thead className="text-sm font-Inter text-white capitalize bg-primary_color sticky top-0 z-10">
                  <tr>
                    <th scope="col" className="px-4 py-3 whitespace-nowrap">
                      {"Price / Km"}
                    </th>
                    {(ownerDetails as any)?.serviceableLocation?.length > 0 &&
                      (ownerDetails as any)?.serviceableLocation
                        ?.sort((a: any, b: any) => a.city.localeCompare(b.city))
                        .map((location: any) => (
                          <th key={location.value} scope="col" className="py-3">
                            <p className=" font-xl font-Inter font-normal w-36 break-all">
                              {location.city}
                            </p>
                          </th>
                        ))}
                  </tr>
                </thead>
                <tbody>{renderServiceableLocations("pricePerKm")}</tbody>
              </table>
            </div>
          ) : (
            <div className="w-full max-h-96 overflow-x-auto overflow-y-auto shadow-md sm:rounded-lg">
              <table className="w-full text-sm text-left text-gray-500">
                <thead className="text-sm font-Inter text-white capitalize bg-primary_color sticky top-0 z-10">
                  <tr>
                    <th scope="col" className="px-4 py-3 whitespace-nowrap">
                      {"Price / Ton"}
                    </th>
                    {(ownerDetails as any)?.serviceableLocation?.length > 0 &&
                      (ownerDetails as any)?.serviceableLocation?.map(
                        (location: any) => (
                          <th key={location.value} scope="col" className="py-3">
                            <p className=" font-xl font-Inter font-normal w-36 break-all">
                              {location.city}
                            </p>
                          </th>
                        )
                      )}
                  </tr>
                </thead>
                <tbody>{renderServiceableLocations("pricePerTon")}</tbody>
              </table>
            </div>
          )}
        </>
      )}
      {truckTable && (
        <>
          <div className="flex flex-row gap-1 rounded pl-4 pr-4 pt-2 pb-2 items-center mt-10 w-28 bg-grey-line text-secondary_color font-normal">
            <Image
              src={Truck}
              alt="truck"
              style={{ width: "30px", height: "30px" }}
            />
            <div>Trucks</div>
          </div>
          <div className="mb-5 text-base font-Inter">
            <TableWrapper
              isStatus={true}
              isAction={true}
              headers={ownerHeader}
              isActionClass={"text-center"}
            >
              {userData.length > 0 ? (
                userData?.map((a: any, index: number) => {
                  return (
                    <tr
                      key={a?.id}
                      className="bg-white border-b  hover:bg-gray-50"
                    >
                      <td className="px-4 py-3">
                        <p className=" font-xl font-Inter font-normal text-grey whitespace-nowrap">
                          {a.registrationNumber}
                        </p>
                      </td>
                      <td className="px-5 py-3">
                        <p className=" font-xl font-Inter font-normal text-grey whitespace-nowrap">
                          {a.vehicleModelName}
                        </p>
                      </td>
                      <td className="px-5 py-3">
                        <p className=" font-xl font-Inter font-normal text-grey whitespace-nowrap">
                          {a.vehicleTypeName}
                        </p>
                      </td>
                      <td className="px-6 py-3">
                        <p className=" font-xl font-Inter font-normal text-grey whitespace-nowrap">
                          {a.vehicleCapacityName}
                        </p>
                      </td>
                      <td className="px-4 py-4">
                        <label
                          className="relative inline-flex items-center cursor-pointer"
                          htmlFor={a?.id}
                        >
                          <input
                            id={a?.id}
                            type="checkbox"
                            name="checkbox"
                            checked={a?.status}
                            onChange={() => StatusUpdate(!a?.status, a?.id)}
                            className="sr-only peer"
                          />
                          <p className="hidden">check</p>
                          <div
                            className="w-11 h-6 flex items-center bg-gray-300 rounded-full peer peer-checked:after:translate-x-full
                        after:absolute after:left-0 peer-checked:after:-left-1 after:bg-gray-300 peer-checked:after:border-white
                        peer-checked:after:border-8 peer-checked:after:bg-green after:border-gray-300 after:rounded-full after:h-7
                        after:w-7 after:transition-all peer-checked:bg-green"
                          />
                          <span className="ms-3 text-sm font-medium text-gray-900 dark:text-gray-300"></span>
                        </label>
                      </td>
                      <td className="p-1">
                        <div className="flex justify-center gap-6">
                          <div className="group flex relative">
                            <button
                              onClick={() =>
                                router.push(
                                  `/dashboard/truck/view?_id=${a?.id}`
                                )
                              }
                              className="rounded-full bg-light-grey"
                            >
                              <Image src={view} alt="view" />
                            </button>
                            <div
                              className="group-hover:opacity-100 transition-opacity bg-light-grey px-2  text-sm text-gray-black rounded-md 
                          absolute left-1/2 -translate-x-1/2 translate-y-full opacity-0 m-4 mx-auto"
                            >
                              View
                            </div>
                          </div>
                          <div className="group flex relative">
                            <button
                              onClick={() =>
                                router.push(
                                  `/dashboard/truck/edit?_id=${a?.id}`
                                )
                              }
                              className="rounded-full bg-light-grey"
                            >
                              <Image src={edit} alt="edit" />
                            </button>
                            <div
                              className="group-hover:opacity-100 transition-opacity bg-light-grey px-2  text-sm text-gray-black rounded-md 
                          absolute left-1/2 -translate-x-1/2 translate-y-full opacity-0 m-4 mx-auto"
                            >
                              Edit
                            </div>
                          </div>
                          <div className="group flex relative">
                            <button
                              onClick={() => handleOpen(a?.id)}
                              className="rounded-full bg-light-grey"
                            >
                              <Image src={trash} alt="trash" />
                            </button>
                            <div
                              className="group-hover:opacity-100 transition-opacity bg-light-grey px-2  text-sm text-gray-black rounded-md 
                          absolute left-1/2 -translate-x-1/2 translate-y-full opacity-0 m-4 mx-auto"
                            >
                              Delete
                            </div>
                          </div>
                        </div>
                      </td>
                    </tr>
                  );
                })
              ) : (
                <tr className="bg-white border-b  hover:bg-gray-50">
                  <td
                    colSpan={8}
                    className="font-normal px-4 py-3 font-lg text-center"
                  >
                    No Data found !!!
                  </td>
                </tr>
              )}
            </TableWrapper>

            {userData.length !== 0 && (
              <Pagination
                pageMeta={pageMeta}
                page={page}
                rowsPerPage={rowsPerPage}
                handlePageChange={({ value }: any) => setPage(value)}
                handleSizeChange={({ value }: any) => setRowsPerPage(value)}
                handleNextPage={() => {
                  pageMeta?.totalPages &&
                    (pageMeta?.totalPages > page
                      ? setPage(page + 1)
                      : setPage(pageMeta?.totalPages));
                }}
                handlePrevPage={() => {
                  setPage(page > 1 ? page - 1 : 1);
                }}
              />
            )}
          </div>
        </>
      )}
      {driverTable && (
        <>
          <div className="flex flex-row gap-1 rounded pl-4 pr-4 pt-2 pb-2 items-center mt-5 w-28 bg-grey-line text-secondary_color font-normal">
            <Image
              src={Driver}
              alt="driver"
              style={{ width: "30px", height: "30px" }}
            />
            <div>Drivers</div>
          </div>
          <div className="mb-5 text-base font-Inter">
            <TableWrapper
              isStatus={true}
              isAction={true}
              headers={driverHeader}
              isActionClass={"text-center"}
            >
              {driverData.length > 0 ? (
                driverData?.map((a: any, index: number) => {
                  return (
                    <tr
                      key={a?.id}
                      className="bg-white border-b  hover:bg-gray-50"
                    >
                      <td className="px-4 py-3">
                        <p className=" font-xl font-Inter font-normal text-grey whitespace-nowrap">
                          {a.fName} {"-"} {a.lName}
                        </p>
                      </td>
                      <td className="px-4 py-3">
                        <p className=" font-xl font-Inter font-normal text-grey whitespace-nowrap">
                          {a.mobile}
                        </p>
                      </td>
                      <td className="px-4 py-3">
                        <p className=" font-xl font-Inter font-normal text-grey whitespace-nowrap">
                          {a.email ? a.email : "-"}
                        </p>
                      </td>
                      <td className="px-4 py-4">
                        <label
                          className="relative inline-flex items-center cursor-pointer"
                          htmlFor={a?.id}
                        >
                          <input
                            id={a?.id}
                            type="checkbox"
                            name="checkbox"
                            checked={a?.status}
                            onChange={() =>
                              StatusUpdateDriver(!a?.status, a?.id)
                            }
                            className="sr-only peer"
                          />
                          <p className="hidden">check</p>
                          <div
                            className="w-11 h-6 flex items-center bg-gray-300 rounded-full peer peer-checked:after:translate-x-full
                        after:absolute after:left-0 peer-checked:after:-left-1 after:bg-gray-300 peer-checked:after:border-white
                        peer-checked:after:border-8 peer-checked:after:bg-green after:border-gray-300 after:rounded-full after:h-7
                        after:w-7 after:transition-all peer-checked:bg-green"
                          />
                          <span className="ms-3 text-sm font-medium text-gray-900 dark:text-gray-300"></span>
                        </label>
                      </td>
                      <td className="p-1">
                        <div className="flex justify-center gap-8">
                          <div className="group flex relative">
                            <button
                              onClick={() =>
                                router.push(
                                  `/dashboard/driver/view?_id=${a?.id}`
                                )
                              }
                              className="rounded-full bg-light-grey"
                            >
                              <Image src={view} alt="view" />
                            </button>
                            <div
                              className="group-hover:opacity-100 transition-opacity bg-light-grey px-2  text-sm text-gray-black rounded-md 
                          absolute left-1/2 -translate-x-1/2 translate-y-full opacity-0 m-4 mx-auto"
                            >
                              View
                            </div>
                          </div>
                          <div className="group flex relative">
                            <button
                              onClick={() =>
                                router.push(
                                  `/dashboard/driver/edit?_id=${a?.id}`
                                )
                              }
                              className="rounded-full bg-light-grey"
                            >
                              <Image src={edit} alt="edit" />
                            </button>
                            <div
                              className="group-hover:opacity-100 transition-opacity bg-light-grey px-2  text-sm text-gray-black rounded-md 
                          absolute left-1/2 -translate-x-1/2 translate-y-full opacity-0 m-4 mx-auto"
                            >
                              Edit
                            </div>
                          </div>
                          <div className="group flex relative">
                            <button
                              onClick={() => handleDriverOpen(a?.id)}
                              className="rounded-full bg-light-grey"
                            >
                              <Image src={trash} alt="trash" />
                            </button>
                            <div
                              className="group-hover:opacity-100 transition-opacity bg-light-grey px-2  text-sm text-gray-black rounded-md 
                          absolute left-1/2 -translate-x-1/2 translate-y-full opacity-0 m-4 mx-auto"
                            >
                              Delete
                            </div>
                          </div>
                        </div>
                      </td>
                    </tr>
                  );
                })
              ) : (
                <tr className="bg-white border-b  hover:bg-gray-50">
                  <td
                    colSpan={8}
                    className="font-normal px-4 py-3 font-lg text-center"
                  >
                    No Data found !!!
                  </td>
                </tr>
              )}
            </TableWrapper>

            {driverData.length !== 0 && (
              <Pagination
                pageMeta={pageMetaDriver}
                page={pageDriver}
                rowsPerPage={rowsPerPageDriver}
                handlePageChange={({ value }: any) => setPageDriver(value)}
                handleSizeChange={({ value }: any) =>
                  setRowsPerPageDriver(value)
                }
                handleNextPage={() => {
                  pageMetaDriver?.totalPages &&
                    (pageMetaDriver?.totalPages > pageDriver
                      ? setPageDriver(pageDriver + 1)
                      : setPageDriver(pageMetaDriver?.totalPages));
                }}
                handlePrevPage={() => {
                  setPageDriver(pageDriver > 1 ? pageDriver - 1 : 1);
                }}
              />
            )}
          </div>
        </>
      )}
      {deleteModal === true && (
        <DeleteModal
          title="Are you Sure?"
          success="Are you sure you want to Delete the Driver ?"
          handleModalClose={() => {
            setDeleteModal(false);
          }}
          handleModalSubmit={handleDeleteModalSumbit}
        />
      )}
      {deleteTruckModal === true && (
        <DeleteModal
          title="Are you Sure?"
          success="Are you sure you want to Delete the Truck ?"
          handleModalClose={() => {
            setDeleteTruckModal(false);
          }}
          handleModalSubmit={handleDeleteModalTruck}
        />
      )}
    </>
  );
};

const mapDispatchToProps = (dispatch: any) => {
  return bindActionCreators(
    {
      getOwnerById,
      getTruckListApi,
      getDriverListApi,
      TruckUpdateStatusApi,
      TruckDeleteApi,
      DriverDeleteApi,
      DriverUpdateStatusApi,
    },
    dispatch
  );
};
export default connect(null, mapDispatchToProps)(OwnerView);

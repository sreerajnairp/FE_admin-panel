import { useRouter } from "next/router";
import { useCallback, useEffect, useState } from "react";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import Image from "next/image";
import { getUserById } from "@/redux/actions/UserApiAct";
import {
  getCityListApi,
  getCountryListApi,
} from "@/redux/actions/CommonApiAct";
import { LoadingScreen } from "@/components/common/Loader";

const UserView = ({ getUserById }: any) => {
  const router = useRouter();
  const { _id = "" } = router.query;
  const [userDetails, setUserDetails] = useState();
  const [profilePic, setProfilePic] = useState("");
  const [loadingFetch, setLoadingFetch] = useState(true);

  const getUserDetails = useCallback(async () => {
    if (_id) {
      const { data } = await getUserById(_id);
      setUserDetails(data);
      setProfilePic(data?.profilePicture);
      setLoadingFetch(false);
    }
  }, [_id]);

  useEffect(() => {
    if (_id) {
      getUserDetails();
    }
  }, [_id]);

  return (
    <>
      {loadingFetch && <LoadingScreen />}
      <div className="gap-5 grid grid-cols-1 md:grid-cols-2">
        <div>
          <h3 className="text-primary_color font-Inter capitalize flex items-center text-xl font-extrabold mb-2 mt-2">
            Customer Details
          </h3>
          <table className="border-collapse border border-solid border-gray-400 h-full w-full">
            <tbody>
              <tr>
                <th className="px-4 pt-4 text-start">Name:</th>
                <td className="px-4 pt-4">
                  {(userDetails as any)?.username || "-"}
                </td>
              </tr>
              <tr>
                <th className="px-4 pt-4 text-start">Email:</th>
                <td className="px-4 pt-4">
                  {(userDetails as any)?.email || "-"}
                </td>
              </tr>
              <tr>
                <th className="px-4 pt-4 text-start">Gender:</th>
                <td className="px-4 pt-4">
                  {(userDetails as any)?.gender || "-"}
                </td>
              </tr>
              <tr>
                <th className="px-4 pt-4 text-start">Mobile Number:</th>
                <td className="px-4 pt-4">
                  {(userDetails as any)?.mobile || "-"}
                </td>
              </tr>
              <tr>
                <th className="px-4 py-4 text-start">Alternate Number:</th>
                <td className="px-4 py-4">
                  {(userDetails as any)?.alternatePhone || "-"}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        <div className="mt-5 md:mt-0">
          <h3 className="text-primary_color font-Inter capitalize flex items-center text-xl font-extrabold mb-2 mt-2">
            Address
          </h3>
          <table className="border-collapse border border-solid border-gray-400  h-full w-full">
            <tbody>
              <tr>
                <th className="px-4 pt-4 text-start">Address:</th>
                <td className="px-4 pt-4">
                  {(userDetails as any)?.streetName || "-"}
                </td>
              </tr>
              <tr>
                <th className="px-4 pt-4 text-start">Country:</th>
                <td className="px-4 pt-4">
                  {(userDetails as any)?.country || "-"}
                </td>
              </tr>
              <tr>
                <th className="px-4 pt-4 text-start">State:</th>
                <td className="px-4 pt-4">
                  {(userDetails as any)?.stateName || "-"}
                </td>
              </tr>
              <tr>
                <th className="px-4 pt-4 text-start">City:</th>
                <td className="px-4 pt-4">
                  {(userDetails as any)?.cityName || "-"}
                </td>
              </tr>
              <tr>
                <th className="px-4 py-4 text-start">Zip Code:</th>
                <td className="px-4 py-4">
                  {(userDetails as any)?.zipCode || "-"}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
      <div className="gap-5 grid grid-cols-1 md:grid-cols-2">
        <div className="mt-16">
          <h3 className="text-primary_color font-Inter capitalize flex items-center text-xl font-extrabold mb-2 mt-2">
            Profile Picture
          </h3>
          <table
            aria-hidden="true"
            className="border-collapse w-full h-full border border-solid border-gray-400"
          >
            <tbody>
              <tr>
                <td className="p-4">
                  {profilePic ? (
                    <a
                      className="rounded-md flex justify-center"
                      href={profilePic}
                      target="_blank"
                    >
                      <Image
                        src={profilePic}
                        alt="Profile Image"
                        className=""
                        width={100}
                        height={100}
                      />
                    </a>
                  ) : (
                    "Profile Not Uploaded"
                  )}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
};

const mapDispatchToProps = (dispatch: any) => {
  return bindActionCreators(
    { getUserById, getCityListApi, getCountryListApi },
    dispatch
  );
};
export default connect(null, mapDispatchToProps)(UserView);

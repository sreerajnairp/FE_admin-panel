import { AddPopup } from "@/components/common/AddModal";
import { NormalInput } from "@/components/common/Inputs/NormalInput";
import { NormalSelect } from "@/components/common/Inputs/NormalSelect";
import { useForm, FormProvider } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import { UserFormValues } from "@/types/Admin";
import { userSchema } from "@/validations/web.schema";
import { useRouter } from "next/router";
import { ButtonContainer } from "@/components/common/ButtonContainer";
import { useCallback, useEffect, useState } from "react";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import { FileUploadButton } from "@/components/common/ButtonUpload";
import {
  UserAddApi,
  UserUpdateApi,
  getUserById,
} from "@/redux/actions/UserApiAct";
import { genderOptions } from "@/helpers/constants";
import {
  getCountryListApi,
  getCityListApi,
  ImageUploadApi,
  getCityByStateApi,
  getStatePermitApi,
} from "@/redux/actions/CommonApiAct";
import { Toast } from "@/service/toast";
import { LoadingScreen } from "@/components/common/Loader";

const resetData = () => ({
  username: "",
  email: null,
  mobile: "",
  gender: "",
  alternatePhone: null,
  profilePicture: null,
  streetName: null,
  city: null,
  country: "",
  state: null,
  zipCode: "",
});

const UserAddEdit = ({
  getUserById,
  UserUpdateApi,
  getCountryListApi,
  getCityListApi,
  ImageUploadApi,
  getStatePermitApi,
  getCityByStateApi,
}: any) => {
  const router = useRouter();
  const [popUp, setPopUp] = useState<boolean>(false);
  const [userDetails, setUserDetails] = useState();
  const [isSented, setIsSented] = useState<boolean>(false);
  const [profileImage, setProfileImage] = useState<string>("");
  const [cityOptions, setCityOptions] = useState([]);
  const [countryOptions, setCountryOptions] = useState([]);
  const [loadingFetch, setLoadingFetch] = useState<boolean>(false);
  const { _id = "", slug = "" } = router.query;
  const [selectedState, setSelectedState] = useState([]);
  const [isOwnerStateMounted, setIsOwnerStateMounted] = useState(false);

  const methods = useForm<UserFormValues>({
    defaultValues: {
      ...resetData(),
    },
    resolver: yupResolver(userSchema),
  });

  const getUserDetails = useCallback(async () => {
    if (_id) {
      setLoadingFetch(true);
      const { data } = await getUserById(_id);
      setUserDetails(data);
      methods.reset({
        username: data?.username,
        email: data?.email ? data?.email : null,
        mobile: data?.mobile,
        alternatePhone: data?.alternatePhone,
        gender: data?.gender,
        profilePicture: data?.profilePicture,
        streetName: data?.streetName,
        city: data?.city,
        country: data?.country,
        state: data?.state,
        zipCode: data?.zipCode,
      });
      setProfileImage(data?.profilePicture);
      setLoadingFetch(false);
    }
  }, [_id]);
  useEffect(() => {
    if (_id) {
      getUserDetails();
    }
  }, [_id]);

  const getCountryDropDown = () => {
    getCountryListApi().then(({ data }: any) => {
      setCountryOptions(
        data?.map((res: any) => {
          return {
            value: res.name,
            label: res.name,
          };
        })
      );
    });
  };
  const getBaseFunc = (id: any) => {
    let query = {
      isGeneral: true,
      cityId: methods.getValues("city"),
    };
    getCityByStateApi(id, query).then(({ data }: any) => {
      setCityOptions(
        data?.list?.map((res: any) => {
          return {
            value: res.id,
            label: res.city,
          };
        })
      );
    });
  };
  const getstateFunc = () => {
    let query = {
      isGeneral: true,
      id: methods.getValues("state"),
    };
    getStatePermitApi(query).then(({ data }: any) => {
      const states = data?.list?.map((res: any) => {
        return {
          value: res.id,
          label: res.state,
        };
      });
      setSelectedState(states);
    });
  };

  useEffect(() => {
    getstateFunc();
  }, [methods.getValues("state")]);
  useEffect(() => {
    getCountryDropDown();
  }, []);

  const handleFileUpload = async (e: any) => {
    methods.clearErrors("profilePicture");
    let file = e.target.files[0];
    if (file) {
      const fileType = file.type;
      if (
        fileType === "image/jpeg" ||
        fileType === "image/jpg" ||
        fileType === "image/png" ||
        fileType === "image/webp"
      ) {
        const fileSizeInMB = file.size / (1024 * 1024);
        if (fileSizeInMB < 3) {
          const reader = new FileReader();
          reader.onload = (event) => {
            const previewUrl = event.target?.result as string;
            setProfileImage(previewUrl);
          };
          reader.readAsDataURL(file);
          methods.setValue("profilePicture", file);
        } else {
          Toast({
            type: "error",
            message: "File Size should not exceed 3MB.",
          });
          e.target.value = "";
        }
      } else {
        Toast({
          type: "error",
          message: "Only JPEG, JPG and PNG files are allowed.",
        });
        e.target.value = "";
      }
    }
  };

  const onSubmit = async (data: any) => {
    setIsSented(true);
    setLoadingFetch(true);

    const formData = new FormData();
    Object.keys(data).forEach((key) => {
      if (data[key] !== null && data[key] !== undefined) {
        formData.append(key, data[key]);
      }
    });
    
    try {
      if (userDetails) {
        let query = {
          id: _id,
        };
        formData.append("userId", (userDetails as any)?.userId);
        formData.append("userAddressId", (userDetails as any)?.userAddressId);
        let body = formData;
        await UserUpdateApi(body, query)
          .then(({ data }: any) => {
            setLoadingFetch(false);
            setIsSented(false);
            setPopUp(true);
            setTimeout(() => {
              router.push("/dashboard/user");
            }, 2000);
          })
          .catch((e: any) => {
            console.log(e);
            setIsSented(false);
            setLoadingFetch(false);
          });
      }
    } catch (error) {
      console.log(error);
      setIsSented(false);
      setLoadingFetch(false);
    }
  };

  useEffect(() => {
    if (methods.getValues("state") && methods.watch("state")) {
      const id = methods.getValues("state");
      const stateID = id.value ? id.value : id;
      if (isOwnerStateMounted) {
        methods.setValue("city", null)
      }else {
        setIsOwnerStateMounted(true);
      }
      getBaseFunc(stateID);
    }
  }, [methods.getValues("state"), methods.watch("state")]);

  return (
    <FormProvider {...methods}>
      <form onSubmit={methods.handleSubmit(onSubmit)}>
        {loadingFetch && <LoadingScreen />}
        <div className="mb-5 text-primary_color text-xl font-semibold font-Inter">
          Customer Details
        </div>
        <div className="grid grid-row md:grid-col md:grid-cols-2 lg:grid-cols-3 md:gap-x-20 gap-y-8">
          <NormalInput
            name="username"
            type="text"
            label="Name"
            placeholder="Please Enter Your Name"
            isrequired={true}
            error={methods.formState.errors.username?.message}
          />
          <NormalInput
            name="email"
            type="email"
            label="Email Id"
            placeholder="Please Enter Your Email ID"
            isrequired={false}
            error={methods.formState.errors.email?.message}
          />
          <NormalInput
            name="mobile"
            type="number"
            label="Phone Number"
            placeholder="Please Enter Your Phone Number"
            isrequired={true}
            error={methods.formState.errors.mobile?.message}
          />
          <NormalInput
            name="alternatePhone"
            type="number"
            label="Alternate Phone Number"
            placeholder="Please Enter Your Phone Number"
            isrequired={false}
            error={methods.formState.errors.alternatePhone?.message}
          />
          <NormalSelect
            options={genderOptions}
            placeholder="Please Select Your Gender"
            label="Gender"
            name="gender"
            isrequired={true}
            error={methods.formState.errors.gender?.message}
          />
          <FileUploadButton
            id={"Profile Pic"}
            uploadImage={profileImage}
            onPerviewClose={() => {
              setProfileImage("");
              methods.setValue("profilePicture", null);
            }}
            label={"Profile Pic"}
            placeholder="Please Upload Profile Pic"
            onFileSubmit={(e: any) => handleFileUpload(e)}
            ImageSize={100}
            isrequired={false}
            error={methods.formState.errors.profilePicture?.message}
          />
        </div>
        <div className="mb-5 mt-8 text-primary_color text-xl font-semibold font-Inter">
          Address Details
        </div>
        <div className="grid grid-row md:grid-col md:grid-cols-2 lg:grid-cols-3 md:gap-x-20 gap-y-8">
          <NormalInput
            name="streetName"
            type="text"
            label="Address"
            placeholder="Please Enter Your Address"
            isrequired={false}
            error={methods.formState.errors.streetName?.message}
          />
          <NormalSelect
            options={countryOptions}
            placeholder="Please Select Your Country"
            label="Country"
            name="country"
            isrequired={true}
            error={methods.formState.errors.country?.message}
          />
          <NormalSelect
            options={selectedState}
            placeholder="Please Select State"
            label="State"
            name="state"
            isrequired={true}
            error={methods.formState.errors.state?.message}
          />
          <NormalSelect
            options={cityOptions}
            placeholder="Please Select Your City / Town"
            label="City / Town"
            name="city"
            isrequired={true}
            error={methods.formState.errors.city?.message}
          />
          <NormalInput
            name="zipCode"
            type="number"
            label="Zip Code"
            placeholder="Please Enter Your Zip Code"
            isrequired={true}
            error={methods.formState.errors.zipCode?.message}
          />
        </div>
        <div className="border-grey-line border-b mt-32 mb-5" />
        <ButtonContainer
          labelLeft="cancel"
          labelRight={slug[0] == "add" ? "add user" : "update"}
          handleClose={() => {
            slug[0] == "add"
              ? methods.reset({ ...resetData() })
              : router.back();
          }}
          btnType="submit"
          isdisabledSubmit={isSented}
        />
        {popUp && (
          <AddPopup
            title={slug[0] == "add" ? "added!" : "updated!"}
            success={
              slug[0] == "add"
                ? "user added successfully"
                : "user Updated successfully"
            }
          />
        )}
      </form>
    </FormProvider>
  );
};

const mapDispatchToProps = (dispatch: any) => {
  return bindActionCreators(
    {
      getUserById,
      UserUpdateApi,
      UserAddApi,
      getCountryListApi,
      getCityListApi,
      ImageUploadApi,
      getStatePermitApi,
      getCityByStateApi,
    },
    dispatch
  );
};
export default connect(null, mapDispatchToProps)(UserAddEdit);

import Image from "next/image";
import { DashboardMenu } from "@/helpers/constants";
import Link from "next/link";
import { useEffect, useState } from "react";
import { usePathname } from "next/navigation";
import Logout from "@/assets/icon/logout.svg";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import Dropdown from "@/assets/svg/dropdown.svg";
import { logout } from "@/service/utilities";
import { DeleteModal } from "../common/DeleteModal";

const Sidebar = ({ sidebarOpen }: any) => {
  const [dropdownChildren, setDropdownChildren] = useState<boolean>(false);
  const [permission, setPermission] = useState("");
  const [deleteModal, setDeleteModal] = useState(false);
  const pathname = usePathname();
  useEffect(() => {
    setDropdownChildren(false);
  }, [pathname]);

  useEffect(() => {
    const storedPermission = localStorage.getItem("permission");
    if (storedPermission) {
      setPermission(storedPermission);
    }
  }, []);
  const filterMenuItems = (userRole: string) => {
    return DashboardMenu.filter((item) => item?.roles?.includes(userRole));
  };
  const visibleMenuItems = filterMenuItems(permission);
  return (
    <>
      <div
        className={`w-11/12 md:w-[300px] xl:w-64 absolute z-50 md:relative top-24 md:top-0 min-h-screen h-full flex flex-col  bg-primary_color rounded-e-[50px] ${
          sidebarOpen ? "hidden" : "block ms-4 md:ms-0"
        }`}
      >
        <div className="flex flex-col">
          <div className="py-4 px-6">
            <ul className="mt-6 flex flex-col gap-1.5">
              {visibleMenuItems?.map((menu, idx) => (
                <>
                  <li
                    key={menu.id}
                    className={`py-2 my-2 ps-4 ${
                      (pathname === menu.link ||
                        pathname?.startsWith(menu.link)) &&
                      menu.link !== "/dashboard"
                        ? "bg-white text-secondary_color"
                        : "text-white"
                    } font-Inter rounded-s-3xl rounded-e-lg`}
                  >
                    <div className="flex flex-row gap-2 items-center">
                      <Image
                        width={28}
                        height={28}
                        src={menu.Icon}
                        priority={true}
                        alt="Icon"
                        style={{
                          filter:
                            (pathname === menu.link ||
                              pathname?.startsWith(menu.link)) &&
                            menu.link !== "/dashboard"
                              ? "brightness(0) saturate(100%) invert(43%) sepia(92%) saturate(4045%) hue-rotate(349deg) brightness(96%) contrast(108%)"
                              : "none",
                        }}
                      />
                      <Link href={menu.link} className="text-md font-Inter">
                        {menu.title}
                      </Link>
                      {dropdownChildren ? (
                        <Image
                          className="cursor-pointer"
                          width={28}
                          height={28}
                          src={Dropdown}
                          alt="Icon"
                        />
                      ) : null}
                    </div>
                  </li>
                  {dropdownChildren &&
                    menu?.children?.map((child, idx) => (
                      <li
                        key={child.id}
                        className={`py-1 ms-6 bg-white bg-opacity-10 text-secondary_color font-Inter rounded-s-3xl rounded-e-lg`}
                      >
                        <Link
                          href={child.link}
                          className="flex flex-row gap-2 items-center"
                        >
                          <h1 className="text-md font-Inter px-6">
                            {child.title}
                          </h1>
                        </Link>
                      </li>
                    ))}
                </>
              ))}
              <div>
                <li
                  className={`py-2 my-2 ps-4 text-white font-Inter rounded-s-3xl`}
                >
                  <button
                    className="flex flex-row gap-3 cursor-pointer"
                    onClick={() => {
                      setDeleteModal(true);
                    }}
                  >
                    <Image
                      width={24}
                      height={24}
                      src={Logout}
                      alt="Icon"
                      priority={true}
                    />
                    <h1>Logout</h1>
                  </button>
                </li>
              </div>
            </ul>
          </div>
        </div>
      </div>
      {deleteModal === true && (
        <DeleteModal
          title="Are you Sure?"
          success="Are you sure you want to Logout ?"
          handleModalClose={() => {
            setDeleteModal(false);
          }}
          handleModalSubmit={() => logout()}
        />
      )}
    </>
  );
};

const mapDispatchToProps = (dispatch: any) => {
  return bindActionCreators({}, dispatch);
};

export default connect(null, mapDispatchToProps)(Sidebar);

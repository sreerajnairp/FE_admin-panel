import { AddPopup } from "@/components/common/AddModal";
import { NormalInput } from "@/components/common/Inputs/NormalInput";
import { NormalSelect } from "@/components/common/Inputs/NormalSelect";
import { useForm, FormProvider } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import { TruckFormValues } from "@/types/Admin";
import { truckSchema } from "@/validations/web.schema";
import { useRouter } from "next/router";
import { ButtonContainer } from "@/components/common/ButtonContainer";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import { FileUploadButton } from "@/components/common/ButtonUpload";
import { DatePicker } from "@/components/common/DatePicker";
import { NormalMultiSelect } from "@/components/common/Inputs/NormalMultiSelect";
import { useCallback, useEffect, useState } from "react";
import {
  TruckUpdateApi,
  TruckAddApi,
  getTruckById,
  getVehicleTypeApi,
  getVehicleLoadTypeApi,
  getVehicleCapacityApi,
  getVehicleSizeApi,
  getVehicleModelApi,
  getVehicleTyreApi,
  getVehicleAxleApi,
} from "@/redux/actions/TruckApiAct";
import { getOwnerListApi } from "@/redux/actions/OwnerApiAct";
import { statusOptions } from "@/helpers/constants";
import moment from "moment";
import {
  ImageUploadApi,
  getPermitListApi,
  getStatePermitApi,
} from "@/redux/actions/CommonApiAct";
import { Toast } from "@/service/toast";
import pdf from "@/assets/icon/pdf.svg";
import { LoadingScreen } from "@/components/common/Loader";

const resetData = () => ({
  ownerId: null,
  registrationNumber: "",
  dateOfRegistration: null,
  registrationValidity: null,
  engineNo: "",
  fuel: "",
  color: "",
  insuranceValidity: null,
  permit: null,
  truckPermit: [],
  permitDocument: null,
  vehicleTypeId: null,
  vehicleLoadTypeId: [],
  vehicleCapacity: null,
  vehicleSizeId: "1",
  vehicleModelId: null,
  // pricePerKm: null,
  vehicleInsurance: null,
  vehicleRegistration: null,
  vehicleTyre: null,
  vehicleAxleId: null,
  status: 1,
});

const TruckAddEdit = ({
  TruckUpdateApi,
  TruckAddApi,
  getTruckById,
  getOwnerListApi,
  getVehicleTypeApi,
  getVehicleLoadTypeApi,
  getVehicleCapacityApi,
  getVehicleSizeApi,
  getVehicleModelApi,
  ImageUploadApi,
  getVehicleTyreApi,
  getPermitListApi,
  getStatePermitApi,
  getVehicleAxleApi,
}: any) => {
  const router = useRouter();
  const [popUp, setPopUp] = useState<boolean>(false);
  const [userDetails, setUserDetails] = useState();
  const [isSent, setIsSent] = useState<boolean>(false);
  const [userData, setUserData] = useState([]);
  const [vehicleType, setVehicleType] = useState([]);
  const [vehicleLoadType, setVehicleLoadType] = useState([]);
  const [vehicleModel, setVehicleModel] = useState([]);
  const [permitTruck, setPermitTruck] = useState([]);
  const [statePermit, setStatePermit] = useState([]);
  const [insurance, setInsurance] = useState<string>("");
  const [registration, setRegistration] = useState<string>("");
  const [permitDoc, setPermitDoc] = useState<string>("");
  const { _id = "", slug = "" } = router.query;
  const [loadingFetch, setLoadingFetch] = useState<boolean>(false);
  const [vehicleAxle, setVehicleAxle] = useState([]);

  const methods = useForm<TruckFormValues>({
    defaultValues: {
      ...resetData(),
    },
    resolver: yupResolver(truckSchema),
  });

  useEffect(() => {
    getAllUserApiFunc();
  }, [methods.getValues("ownerId")]);

  const permitSelect = methods.watch<any>("permit");

  const getAllUserApiFunc = () => {
    let query = {
      status: 1,
      ownerId: methods.getValues("ownerId"),
    };
    getOwnerListApi(query).then(({ data }: any) => {
      const splitData = data?.list?.map((res: any) => {
        return {
          value: res.id,
          label: `${res.fName} - ${res.lName}`,
        };
      });
      setUserData(splitData);
    });
  };

  const getVehicleModelFunc = () => {
    getVehicleModelApi().then(({ data }: any) => {
      const splitData = data?.list?.map((res: any) => {
        return {
          value: res.id,
          label: res.name,
        };
      });
      setVehicleModel(splitData);
    });
  };

  const getVehicleTypeFunc = () => {
    getVehicleTypeApi().then(({ data }: any) => {
      const splitData = data?.list?.map((res: any) => {
        return {
          value: res.id,
          label: res.name,
        };
      });
      setVehicleType(splitData);
    });
  };

  const getPermitFunc = () => {
    getPermitListApi().then(({ data }: any) => {
      setPermitTruck(
        data?.map((res: any) => {
          return {
            value: res.name,
            label: res.name,
          };
        })
      );
    });
  };

  const getStatePermitFunc = () => {
    const StateIds = methods.getValues("truckPermit");
    let query = {
      isGeneral: true,
      stateIds: _id ? StateIds.join(",") : null,
    };
    getStatePermitApi(query).then(({ data }: any) => {
      setStatePermit(
        data?.list?.map((res: any) => {
          return {
            value: res.id,
            label: res.state,
          };
        })
      );
    });
  };



  const getVehicleAxleFunc = () => {
    getVehicleAxleApi().then(({ data }: any) => {
      const splitData = data?.list?.map((res: any) => {
        return {
          value: res.id,
          label: res.name,
        };
      });
      setVehicleAxle(splitData);
    });
  };

  const getVehicleLoadTypeFunc = () => {
    getVehicleLoadTypeApi().then(({ data }: any) => {
      setVehicleLoadType(
        data?.list?.map((res: any) => {
          return {
            value: res.id,
            label: res.name,
          };
        })
      );
    });
  };

  const Fueloptions = [
    { value: "petrol", label: "Petrol" },
    { value: "diesel", label: "Diesel" },
    { value: "gas", label: "Gas" },
  ];

  const handleInsuranceUpload = async (e: any) => {
    methods.clearErrors("vehicleInsurance");
    let file = e.target.files[0];
    if (file) {
      const fileType = file.type;
      if (
        fileType === "image/jpeg" ||
        fileType === "image/jpg" ||
        fileType === "image/png" ||
        fileType === "image/webp" ||
        fileType === "application/pdf"
      ) {
        const fileSizeInMB = file.size / (1024 * 1024);
        if (fileSizeInMB < 3) {
          const reader = new FileReader();
          reader.onload = (event) => {
            const previewUrl = event.target?.result as string;
            fileType === "application/pdf"
              ? setInsurance(pdf)
              : setInsurance(previewUrl);
          };
          reader.readAsDataURL(file);
          methods.setValue("vehicleInsurance", file);
        } else {
          Toast({
            type: "error",
            message: "File Size should not exceed 3MB.",
          });
          e.target.value = "";
        }
      } else {
        Toast({
          type: "error",
          message: "Only JPEG, JPG, PDF and PNG files are allowed.",
        });
        e.target.value = "";
      }
    }
  };
  const handleRegistrationUpload = async (e: any) => {
    methods.clearErrors("vehicleRegistration");
    let file = e.target.files[0];
    if (file) {
      const fileType = file.type;
      if (
        fileType === "image/jpeg" ||
        fileType === "image/jpg" ||
        fileType === "image/png" ||
        fileType === "image/webp" ||
        fileType === "application/pdf"
      ) {
        const fileSizeInMB = file.size / (1024 * 1024);
        if (fileSizeInMB < 3) {
          const reader = new FileReader();
          reader.onload = (event) => {
            const previewUrl = event.target?.result as string;
            fileType === "application/pdf"
              ? setRegistration(pdf)
              : setRegistration(previewUrl);
          };
          reader.readAsDataURL(file);
          methods.setValue("vehicleRegistration", file);
        } else {
          Toast({
            type: "error",
            message: "File Size should not exceed 3MB.",
          });
          e.target.value = "";
        }
      } else {
        Toast({
          type: "error",
          message: "Only JPEG, JPG, PDF and PNG files are allowed.",
        });
        e.target.value = "";
      }
    }
  };
  const handlePermitDocUpload = async (e: any) => {
    methods.clearErrors("permitDocument");
    let file = e.target.files[0];
    if (file) {
      const fileType = file.type;
      if (
        fileType === "image/jpeg" ||
        fileType === "image/jpg" ||
        fileType === "image/png" ||
        fileType === "image/webp" ||
        fileType === "application/pdf"
      ) {
        const fileSizeInMB = file.size / (1024 * 1024);
        if (fileSizeInMB < 3) {
          const reader = new FileReader();
          reader.onload = (event) => {
            const previewUrl = event.target?.result as string;
            fileType === "application/pdf"
              ? setPermitDoc(pdf)
              : setPermitDoc(previewUrl);
          };
          reader.readAsDataURL(file);
          methods.setValue("permitDocument", file);
        } else {
          Toast({
            type: "error",
            message: "File Size should not exceed 3MB.",
          });
          e.target.value = "";
        }
      } else {
        Toast({
          type: "error",
          message: "Only JPEG, JPG, PDF and PNG files are allowed.",
        });
        e.target.value = "";
      }
    }
  };
  const getEnqiureDetails = useCallback(async () => {
    if (_id) {
      setLoadingFetch(true);
      const { data } = await getTruckById(_id);
      setUserDetails(data);
      methods.reset({
        ownerId: data?.ownerId,
        registrationNumber: data?.registrationNumber,
        dateOfRegistration: data?.dateOfRegistration
          ? moment(data?.dateOfRegistration).format("YYYY-MM-DD")
          : null,
        registrationValidity: data?.registrationValidity
          ? moment(data?.registrationValidity).format("YYYY-MM-DD")
          : null,
        engineNo: data?.engineNo,
        fuel: data?.fuel,
        color: data?.color,
        insuranceValidity: moment(data?.insuranceValidity).format("YYYY-MM-DD"),
        permit: data?.permitName,
        truckPermit: data?.truckPermit?.map((a: any) => parseInt(a.state)),
        permitDocument: data?.permitDocument,
        vehicleTypeId: data?.vehicleTypeId,
        vehicleLoadTypeId: data?.vehicleLoadType?.map(
          (a: any) => a.vehicleLoadTypeId
        ),
        vehicleCapacity: data?.vehicleCapacityUnit,
        vehicleSizeId: "1",
        vehicleModelId: data?.vehicleModelId,
        vehicleInsurance: data?.vehicleInsurance,
        vehicleRegistration: data?.vehicleRegistration,
        vehicleTyre: data?.vehicleTyreName?.replace(" TYRE", ""),
        vehicleAxleId: data?.vehicleAxleId,
        status: data?.status,
      });
      setInsurance(data?.vehicleInsurance);
      setRegistration(data?.vehicleRegistration);
      setPermitDoc(data?.permitDocument);
      setLoadingFetch(false);
      getVehicleModelFunc();
      getPermitFunc();
      getVehicleLoadTypeFunc();
      getVehicleTypeFunc();
      getVehicleAxleFunc();
      getStatePermitFunc();
    }
  }, [_id]);
  useEffect(() => {
    if (_id) {
      getEnqiureDetails();
    }
  }, [_id]);
  useEffect(() => {
    if (!_id) {
      getVehicleModelFunc();
      getPermitFunc();
      getVehicleLoadTypeFunc();
      getVehicleTypeFunc();
      getVehicleAxleFunc();
      getStatePermitFunc();
    }
  }, []);

  const onSubmit = async (data: any) => {
    setIsSent(true);
    setLoadingFetch(true);
    const formData = new FormData();
    Object.keys(data).forEach((key) => {
      if (data[key] !== null && data[key] !== undefined) {
        if (Array.isArray(data[key])) {
          data[key].forEach((item: any, index: any) => {
            formData.append(`${key}[${index}]`, item);
          });
        } else {
          formData.append(key, data[key]);
        }
      }
    });

    try {
      if (userDetails) {
        let query = { id: _id };
        let body = formData;
        await TruckUpdateApi(body, query);
      } else {
        let body = formData;
        await TruckAddApi(body);
      }
      setLoadingFetch(false);
      setIsSent(false);
      setPopUp(true);
      setTimeout(() => {
        router.push("/dashboard/truck");
      }, 2000);
    } catch (error) {
      console.log(error);
      setIsSent(false);
      setLoadingFetch(false);
    }
  };
  useEffect(() => {
    if (methods.getValues("permit") && methods.watch("permit")) {
      const permit = methods.getValues("permit");
      
      if (permit !== "State Permit") {
        methods.setValue("truckPermit", null);
      }
    }
  }, [methods.getValues("permit"), methods.watch("permit")]);
  return (
    <FormProvider {...methods}>
      <form onSubmit={methods.handleSubmit(onSubmit)}>
        {loadingFetch && <LoadingScreen />}
        <div className="grid grid-row md:grid-col md:grid-cols-2 lg:grid-cols-3 md:gap-x-20 gap-y-8">
          <NormalSelect
            options={userData}
            placeholder="Please select owner name"
            label="Owner Name"
            name="ownerId"
            isrequired={true}
            error={methods.formState.errors.ownerId?.message}
          />
          <NormalInput
            name="registrationNumber"
            type="text"
            label="Registration Number"
            placeholder="Please Enter Registration Number"
            isrequired={true}
            error={methods.formState.errors.registrationNumber?.message}
            inputStyles={"uppercase"}
          />
          <DatePicker
            max={slug[0] == "add" ? new Date().toJSON().slice(0, 10) : ""}
            name="dateOfRegistration"
            type="date"
            value={moment(methods.getValues("dateOfRegistration")).format(
              "YYYY-MM-DD"
            )}
            label="Date of Registration"
            isrequired={false}
            error={methods.formState.errors.dateOfRegistration?.message}
            placeholder="Please select date"
          />
          <DatePicker
            min={slug[0] == "add" ? new Date().toJSON().slice(0, 10) : ""}
            name="registrationValidity"
            type="date"
            value={moment(methods.getValues("registrationValidity")).format(
              "YYYY-MM-DD"
            )}
            label="Registration Validity"
            isrequired={false}
            error={methods.formState.errors.registrationValidity?.message}
            placeholder="Please select date"
          />
          <FileUploadButton
            id={"Vehicle Registration"}
            uploadImage={registration}
            onPerviewClose={() => {
              setRegistration("");
              methods.setValue("vehicleRegistration", null);
            }}
            label={"Vehicle Registration"}
            placeholder="Please Upload Vehicle Registration"
            onFileSubmit={(e: any) => handleRegistrationUpload(e)}
            ImageSize={100}
            isrequired={false}
            error={methods.formState.errors.vehicleRegistration?.message}
          />
          <NormalInput
            name="engineNo"
            type="text"
            label="Engine Number"
            placeholder="Please Enter Engine Number"
            error={methods.formState.errors.engineNo?.message}
            inputStyles={"uppercase"}
          />
          <NormalSelect
            options={Fueloptions}
            placeholder="Please select fuel"
            label="Fuel"
            name="fuel"
            error={methods.formState.errors.fuel?.message}
          />
          <NormalInput
            name="color"
            type="text"
            label="Color"
            placeholder="Please Enter Color"
            error={methods.formState.errors.color?.message}
          />
          {/* <NormalInput
            name="pricePerKm"
            type="text"
            label="Price Per km"
            placeholder="Please Enter Price Per Km"
            isrequired={true}
            error={methods.formState.errors.pricePerKm?.message}
          /> */}
          <DatePicker
            min={slug[0] == "add" ? new Date().toJSON().slice(0, 10) : ""}
            name="insuranceValidity"
            type="date"
            value={moment(methods.getValues("insuranceValidity")).format(
              "YYYY-MM-DD"
            )}
            label="Insurance Validity"
            isrequired={true}
            error={methods.formState.errors.insuranceValidity?.message}
            placeholder="Enter select date"
          />
          <FileUploadButton
            id={"Vehicle Insurance"}
            uploadImage={insurance}
            onPerviewClose={() => {
              setInsurance("");
              methods.setValue("vehicleInsurance", null);
            }}
            label={"Vehicle Insurance"}
            placeholder="Please Upload Vehicle Insurance"
            onFileSubmit={(e: any) => handleInsuranceUpload(e)}
            ImageSize={100}
            isrequired={false}
            error={methods.formState.errors.vehicleInsurance?.message}
          />
          <NormalSelect
            options={vehicleModel}
            placeholder="Please select vehicle model"
            label="Vehicle Model"
            name="vehicleModelId"
            isrequired={true}
            error={methods.formState.errors.vehicleModelId?.message}
          />
          <NormalSelect
            options={permitTruck}
            placeholder="Please select permit"
            label="Permit"
            name="permit"
            isrequired={true}
            error={methods.formState.errors.permit?.message}
          />
          {(permitSelect?.label === "State Permit" ||
            (methods.getValues("permit") === "State Permit" &&
              permitSelect === "State Permit")) && (
            <NormalMultiSelect
              name="truckPermit"
              placeholder="Please Select State Permit"
              label="State Permit"
              options={statePermit}
              isrequired={true}
              error={methods.formState.errors.truckPermit?.message}
            />
          )}
          <FileUploadButton
            id={"Vehicle Permit"}
            uploadImage={permitDoc}
            onPerviewClose={() => {
              setPermitDoc("");
              methods.setValue("permitDocument", null);
            }}
            label={"Vehicle Permit"}
            placeholder="Please Upload Vehicle Permit"
            onFileSubmit={(e: any) => handlePermitDocUpload(e)}
            ImageSize={100}
            isrequired={false}
            error={methods.formState.errors.permitDocument?.message}
          />
          <NormalSelect
            options={vehicleType}
            placeholder="Please select vehicle type"
            label="Vehicle Type"
            name="vehicleTypeId"
            isrequired={true}
            error={methods.formState.errors.vehicleTypeId?.message}
          />
          <NormalMultiSelect
            options={vehicleLoadType}
            placeholder="Please select vehicle Load Type"
            label="Vehicle Load Type"
            name="vehicleLoadTypeId"
            isrequired={true}
            error={methods.formState.errors.vehicleLoadTypeId?.message}
          />
          {/* <NormalSelect
            options={vehicleCapacity}
            placeholder="Please select vehicle capacity"
            label="Vehicle Capacity"
            name="vehicleCapacity"
            isrequired={true}
            error={methods.formState.errors.vehicleCapacity?.message}
          /> */}
          <NormalInput
            name="vehicleCapacity"
            type="number"
            label="Vehicle Capacity"
            placeholder="Please Enter Vehicle Capacity"
            isrequired={true}
            context={"All values here represent MT units only."}
            error={methods.formState.errors.vehicleCapacity?.message}
          />
          <NormalInput
            name="vehicleTyre"
            type="number"
            label="Vehicle Tyre"
            placeholder="Please Enter Vehicle Tyre"
            isrequired={false}
            error={methods.formState.errors.vehicleTyre?.message}
          />
          {/* <NormalSelect
            options={vehicleTyre}
            placeholder="Please select vehicle tyre"
            label="Vehicle Tyre"
            name="vehicleTyreId"
            isrequired={false}
            error={methods.formState.errors.vehicleTyreId?.message}
          /> */}
          <NormalSelect
            options={vehicleAxle}
            placeholder="Please select vehicle axle"
            label="Vehicle Axle"
            name="vehicleAxleId"
            isrequired={false}
            error={methods.formState.errors.vehicleAxleId?.message}
          />
          <NormalSelect
            options={statusOptions}
            placeholder="Please select status"
            label="Status"
            name="status"
            isrequired={true}
            error={methods.formState.errors.status?.message}
          />
        </div>
        <div className="border-grey-line border-b mt-32 mb-5" />
        <ButtonContainer
          labelLeft="cancel"
          labelRight={slug[0] == "add" ? "add truck" : "update"}
          handleClose={() => router.back()}
          btnType="submit"
          isdisabledSubmit={isSent}
        />
        {popUp && (
          <AddPopup
            title={slug[0] == "add" ? "added!" : "updated!"}
            success={
              slug[0] == "add"
                ? "truck added successfully"
                : "truck Updated successfully"
            }
          />
        )}
      </form>
    </FormProvider>
  );
};

const mapDispatchToProps = (dispatch: any) => {
  return bindActionCreators(
    {
      TruckUpdateApi,
      TruckAddApi,
      getTruckById,
      getOwnerListApi,
      getVehicleTypeApi,
      getVehicleLoadTypeApi,
      getVehicleCapacityApi,
      getVehicleSizeApi,
      getVehicleModelApi,
      ImageUploadApi,
      getVehicleTyreApi,
      getPermitListApi,
      getStatePermitApi,
      getVehicleAxleApi,
    },
    dispatch
  );
};
export default connect(null, mapDispatchToProps)(TruckAddEdit);

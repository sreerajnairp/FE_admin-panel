import { useRouter } from "next/router";
import { useState, useCallback, useEffect } from "react";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import Image from "next/image";
import { getTruckById } from "@/redux/actions/TruckApiAct";
import { getBookingListApi } from "@/redux/actions/BookingApiAct";
import moment from "moment";
import { getImageSrc } from "@/service/utilities";
import { LoadingScreen } from "@/components/common/Loader";

const TruckView = ({ getTruckById, getBookingListApi }: any) => {
  const router = useRouter();
  const { _id = "" } = router.query;
  const [truckDetails, setTruckDetails] = useState(null);
  const [insurance, setInsurance] = useState("");
  const [registration, setRegistration] = useState("");
  const [permit, setPermit] = useState("");
  const [loadingFetch, setLoadingFetch] = useState(true);

  const getTruckDetails = useCallback(async () => {
    if (_id) {
      const { data } = await getTruckById(_id);
      setTruckDetails(data);
      setInsurance(data?.vehicleInsurance);
      setRegistration(data?.vehicleRegistration);
      setPermit(data?.permitDocument);
      setLoadingFetch(false);
    }
  }, [_id]);

  useEffect(() => {
    if (_id) {
      getTruckDetails();
    }
  }, [_id]);


  return (
    <>
     {loadingFetch && <LoadingScreen />}
      <div className="gap-5 grid grid-cols-1">
        <div>
          <h3 className="text-primary_color font-Inter capitalize flex items-center text-xl font-extrabold mb-2 mt-2">
            Truck Details
          </h3>
          <table className="border-collapse border border-solid border-gray-400 h-full">
            <tbody>
              <tr>
                <th className="px-4 pt-4 text-start">Registration Number:</th>
                <td className="px-4 pt-4">
                  {(truckDetails as any)?.registrationNumber || "-"}
                </td>
              </tr>
              <tr>
                <th className="px-4 pt-4 text-start">Insurance Validity:</th>
                <td className="px-4 pt-4">
                  {moment((truckDetails as any)?.insuranceValidity).format(
                    "DD-MM-YYYY"
                  ) || "-"}
                </td>
              </tr>
              <tr>
                <th className="px-4 pt-4 text-start">Truck Load Type:</th>
                <td className="px-4 pt-4  break-all w-64">
                  {(truckDetails as any)?.vehicleLoadType.map((a: any) => a.vehicleLoadTypeName)
                    .join(", ") || "-"}
                </td>
              </tr>
              <tr>
                <th className="px-4 pt-4 text-start">Truck Model:</th>
                <td className="px-4 pt-4">
                  {(truckDetails as any)?.vehicleModelName || "-"}
                </td>
              </tr>
              <tr>
                <th className="px-4 pt-4 text-start">Capacity limit:</th>
                <td className="px-4 pt-4">
                  {(truckDetails as any)?.vehicleCapacityName || "-"}
                </td>
              </tr>
              <tr>
                <th className="px-4 py-4 text-start">Truck Type:</th>
                <td className="px-4 py-4">
                  {(truckDetails as any)?.vehicleTypeName || "-"}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
      <div className="gap-5 grid grid-cols-1 md:grid-cols-3 mt-16 mb-24">
        <div>
          <h3 className="text-primary_color font-Inter capitalize flex items-center text-xl font-extrabold mb-2 mt-2">
            Vehicle Insurance
          </h3>
          <table aria-hidden="true"  className="border-collapse w-full h-full border border-solid border-gray-400">
            <tbody>
              <tr>
                <td className="p-4">
                  {insurance ? (
                    <a
                      className="rounded-md  flex justify-center"
                      href={insurance}
                      target="_blank"
                    >
                      <Image
                        src={getImageSrc(insurance)}
                        alt="doc"
                        width={100}
                        height={100}
                      />
                    </a>
                  ) : (
                    "Insurance Not Uploaded"
                  )}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        <div className="mt-5 md:mt-0">
          <h3 className="text-primary_color font-Inter capitalize flex items-center text-xl font-extrabold mb-2 mt-2">
            Vehicle Registration
          </h3>
          <table aria-hidden="true" className="border-collapse w-full h-full border border-solid border-gray-400">
            <tbody>
              <tr>
                <td className="p-4">
                  {registration ? (
                    <a
                      className="rounded-md flex justify-center"
                      href={registration}
                      target="_blank"
                    >
                      <Image
                        src={getImageSrc(registration)}
                        alt="doc"
                        width={100}
                        height={100}
                      />
                    </a>
                  ) : (
                    "Registration Not Uploaded"
                  )}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        <div className="mt-5 md:mt-0">
          <h3 className="text-primary_color font-Inter capitalize flex items-center text-xl font-extrabold mb-2 mt-2">
            Vehicle Permit
          </h3>
          <table aria-hidden="true" className="border-collapse w-full h-full border border-solid border-gray-400">
            <tbody>
              <tr>
                <td className="p-4">
                  {permit ? (
                    <a
                      className="rounded-md flex justify-center"
                      href={permit}
                      target="_blank"
                    >
                      <Image
                        src={getImageSrc(permit)}
                        alt="doc"
                        width={100}
                        height={100}
                      />
                    </a>
                  ) : (
                    "Permit Not Uploaded"
                  )}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
};

const mapDispatchToProps = (dispatch: any) => {
  return bindActionCreators({ getTruckById, getBookingListApi }, dispatch);
};
export default connect(null, mapDispatchToProps)(TruckView);

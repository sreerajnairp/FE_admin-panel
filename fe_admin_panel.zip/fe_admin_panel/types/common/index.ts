import { MouseEventHandler } from "react";

export interface CustomButtonProps {
    isDisabled?: boolean;
    btnType?: "button" | "submit";
    inputStyles?: string;
    title: string;
    rightIcon?:string;
    leftIcon?:string;
    loading?:boolean;
    loadingStyle?:string;
    loadingSize?:string
    handleClick?: MouseEventHandler<HTMLButtonElement>;
}

export interface TagForm {
    name: string;
    tamilName: string;
}

export interface ColorForm {
    name: string;
    colorCode: string;
    status: boolean;
}

export interface CategoryForm {
    name: string;
    tamilName: string;
    upload_image: any;
    mobile_upload_image: any;
    banner_upload_image: any;
    slug: string;
    status: boolean;
}

export interface BannerForm {
    title: string;
    description: string;
    upload_image: any;
    mobile_upload_image: any;
    status: boolean;
}

export interface BlogForm {
    description: string;
    title: string;
    slug: string;
    upload_image: any;
    status: boolean;
    seoTitle: string;
    seoDescription: string;
    seoKeyword: string; 
}

export interface SettingForm {
    currentpassword: string;
    newPassword: string;
    confirmPassword: string;
}

export interface StaffForm {
    name: string;
    email: string;
    phone_number: number;
    password: string;
    role: string;
}

export interface SchemeForm {
    name: string;
    final_amount: number;
    scheme_benefit: string;
    period: string;
    initial_amount: string;
    more_benefit: string;
    description: string;
    upload_image: string;
}

export interface ProductForm {
    category: string;
    jewellery_type: string;
    brand: string;
    gender: string;
    purity: number;
    occasion: string;
    metalColour: string;
    height: number;
    width: number;
    tag: string;
    slug: string;
    title: string;
    tamilTitle: string;
    status: boolean;
    makingCharges: number;
    jewelleryWeight: number;
    stone: boolean;
    discount: number;
    stoneWeight?: number;
    stonePrice?: number;
    shortDescription: string;
    description: string;
    seoTitle: string;
    seoDescription: string;
    seoKeyword: string;   
    productImages: File;
}
export interface EnquireForm {
   comment : string;
}

export interface RateForm {
    gold_price_gram_18k : number;
    gold_price_gram_22k : number;
    gold_price_gram_24k : number;
    silver_price_gram: number;
    platinum_price_gram: number;
}

export interface PageMeta {
    size: number;
    page: number;
    total: number;
    totalPages: number | undefined;
  }
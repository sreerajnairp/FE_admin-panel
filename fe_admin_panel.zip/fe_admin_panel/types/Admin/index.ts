import { ReactNode } from "react";

export type LayoutProps = {
  children: ReactNode;
};

export interface LoginFormValues {
  email: string;
  password: string;
  rememberMe: boolean;
}
export interface ForgotFormValues {
  emailOrMobile: string;
}
export interface ResetFormValues {
  password: string;
  confirmPassword: string;
}

export interface InputBoxProps {
  isDisabled?: boolean;
  isRequired?: boolean;
  type: "number" | "text" | "hidden" | "email" | "password";
  inputStyles?: string;
  labelStyles?: string;
  placeHolder?: string;
  label?: string;
  icon?: boolean;
  IconStyle?: string;
  name: string;
  error?: any;
  errorStyles?: string;
}
export interface UserFormValues {
  username: string;
  email?: string | null;
  mobile: string;
  alternatePhone?: any;
  gender: string;
  profilePicture?: any;
  streetName?: any;
  city: any;
  country: string;
  state: any;
  zipCode: string;
}
export interface TruckFormValues {
  ownerId: any;
  registrationNumber: string;
  dateOfRegistration?: any;
  registrationValidity?: any;
  engineNo?: string;
  fuel?: string;
  color?: string;
  insuranceValidity: any;
  permit: any;
  truckPermit?: any;
  permitDocument?: any;
  vehicleTypeId: any;
  vehicleLoadTypeId: any;
  vehicleCapacity: any;
  vehicleSizeId?: any;
  vehicleModelId: any;
  // pricePerKm: any;
  vehicleInsurance?: any;
  vehicleRegistration?: any;
  vehicleTyre?: any;
  vehicleAxleId?: any;
  status?: number;
}

export interface OwnerFormValues {
  fName: string;
  lName: string;
  mobile: string;
  alternatePhone?: any;
  email?: any;
  companyName: string;
  baseLocation: any;
  serviceableLocation: any;
  gstNo: string;
  idProofType: any;
  document: any;
  profilePicture?: any;
  streetName?: string;
  city: any;
  country: string;
  zipCode?: any;
  companyAddress?: string;
  companyCity: any;
  companyZipcode?: any;
  companyCountry: any;
  companyState: any;
  ownerState: any;
  pricePerKm: any;
  pricePerTon: any;
  status?: number;
}

export interface DriverFormValues {
  fName: string;
  lName: string;
  mobile: string;
  alternatePhone?: any;
  email?: any;
  idProofType: any;
  document: any;
  profilePicture: any;
  licenseNumber: string;
  licenseExpiry: any;
  licensePhoto: any;
  vehicleInsurance?: any;
  vehicleRegistration?: any;
  experience: any;
  ownerId: any;
  streetName?: any;
  country: any;
  city: any;
  zipCode?: any;
  state: any;
  status?: number;
}

export interface EmployeeFormValues {
  username: string;
  email: string;
  mobile: string;
  gender: string;
  profilePic?: any;
  role: string;
  idProofType: any;
  documents: any;
  streetName?: string;
  city: any;
  country: string;
  state: any;
  zipCode?: any;
  status?: number;
}

export interface RefundFormValues {
  cancelReason: string;
  ownerId?: string;
  paidAmount?: string;
}

export interface StateFormValues {
  state: any;
}

export interface CityFormValues {
  stateId: any;
  city: any;
}

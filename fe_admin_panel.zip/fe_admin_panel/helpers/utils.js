/**
 * Extract the right error message from react-hook-form error object
 *
 * @param {object} errors Errors object from react-hook-form
 * @param {object} fieldArrayError  { index, fieldName: "date", arrayName: "callLogs", }
 * @param {string} name
 */

import { Toast } from "@/service/toast";
import CryptoJS from "crypto-js";

export const urlCombiner = (url) => {
  const protocol = ["h", "t", "t", "p", "s"].join("");

  return `${protocol}://${url}`;
};

// generate Query
export const generateQuery = (query) => {
  let url = "";

  if (query.hasOwnProperty("url_id")) {
    url = `/${query.url_id}`;
  }

  const queryString = Object.keys(query).reduce((accumulator, key) => {
    if (
      query[key] === "" ||
      query[key] == null ||
      key === "url_id" ||
      (query[key] !== null && query[key].toString().trim() === "")
    ) {
      return accumulator;
    }
    return `${accumulator}${accumulator ? "&" : "?"}${key}=${query[key]}`;
  }, "");

  return url + queryString;
};

// add Query
export const addQuery = (dataObject, apiObject) => {
  if (!dataObject) {
    return "";
  }

  const keys = [
    "page",
    "size",
    "search",
    "id",
    "token",
    "countryCode",
    "ownerId",
    "truckId",
    "status",
    "serviceableLocation",
    "isRouteStarted",
    "stateId",
    "cityId",
    "isGeneral",
    "cityIds",
    "stateIds",
  ];

  queryDataValidaionProperty(dataObject, apiObject);
  queryDatavalidation(keys, dataObject, apiObject);
};

function queryDataValidaionProperty(dataObject, apiObject) {
  if (dataObject.hasOwnProperty("status")) {
    apiObject.query.status = dataObject.status;
  }
  if (dataObject.hasOwnProperty("search")) {
    apiObject.query.search = dataObject.search;
  }
  if (dataObject.hasOwnProperty("isRouteStarted")) {
    apiObject.query.isRouteStarted = dataObject.isRouteStarted;
  }
}

function queryDatavalidation(keys, dataObject, apiObject) {
  keys.forEach((key) => {
    if (dataObject.hasOwnProperty(key) && typeof dataObject[key] !== "object") {
      if (apiObject.query.hasOwnProperty(key) && dataObject[key]) {
        apiObject.addQuery = { key, payload: dataObject[key] };
      }
    } else {
      if (dataObject[key]) {
        Object.keys(dataObject[key]).forEach((keyName) => {
          if (apiObject.query.hasOwnProperty(keyName)) {
            apiObject.addQuery = {
              key: keyName,
              payload: dataObject[key][keyName],
            };
          }
        });
      }
      if (!dataObject[key]) {
        apiObject.query[key] = null;
      }
    }
  });
}

//Error Toast
export const errorToast = (message = "Please try again later...!!!") => {
  return Toast({ type: "error", message });
};

// ENCRYPTION FUNCTION
export const encryptData = (text, key) => {
  if (text && key)
    return CryptoJS.AES.encrypt(JSON.stringify(text), key).toString();
};

// DECRYPTION FUNCTION
export const decryptData = (text, key) => {
  if (text && key) {
    const bytes = CryptoJS.AES.decrypt(text, key);
    try {
      return JSON.parse(bytes.toString(CryptoJS.enc.Utf8));
    } catch (err) {
      return null;
    }
  }
};

// store.js
import { configureStore } from '@reduxjs/toolkit';
import { api } from '../service/api';
import { Toast } from '../service/toast';
import rootReducer from '../redux/reducer';

const store = configureStore({
  reducer: rootReducer,
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      thunk: {
        extraArgument: { api, Toast },
      },
    }),
});

export default store;

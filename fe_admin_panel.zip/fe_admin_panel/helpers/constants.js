import Truck from "@/assets/icon/mdi-light_truck.svg";
import User from "@/assets/icon/user.svg";
import Driver from "@/assets/icon/mdi_account-tie-hat-outline.svg";
import line from "@/assets/icon/clarity_employee-line.svg";
import location from "@/assets/icon/tdesign_location-setting.png";
import Booking from "@/assets/icon/delivery.svg";
import credit from "@/assets/icon/tabler_credit-card-refund.svg";
import GrpUser from "@/assets/icon/Grp_User.svg";

export const DashboardMenu = [
  // {
  //   id: 1,
  //   link: "/dashboard",
  //   Icon: Dashboard,
  //   title: "Dashboard",
  //   roles: ["Admin", "Super Admin"],
  // },
  {
    id: 4,
    link: "/dashboard/owner",
    Icon: User,
    title: "Manage Owner",
    roles: ["Admin", "Super Admin"],
  },
  {
    id: 3,
    link: "/dashboard/truck",
    Icon: Truck,
    title: "Manage Truck",
    roles: ["Admin", "Super Admin"],
    children: [
      {
        id: 3.1,
        link: "/dashboard/truck",
        Icon: Truck,
        title: "Vehicle Type",
      },
      {
        id: 3.2,
        link: "/dashboard/truck",
        Icon: Truck,
        title: "Vehicle Load Type",
      },
      {
        id: 3.3,
        link: "/dashboard/truck",
        Icon: Truck,
        title: "Vehicle Model",
      },
      {
        id: 3.4,
        link: "/dashboard/truck",
        Icon: Truck,
        title: "Vehicle Capacity",
      },
      {
        id: 3.5,
        link: "/dashboard/truck",
        Icon: Truck,
        title: "Vehicle Size",
      },
    ],
  },

  {
    id: 5,
    link: "/dashboard/driver",
    Icon: Driver,
    title: "Manage Driver",
    roles: ["Admin", "Super Admin"],
  },
  {
    id: 6,
    link: "/dashboard/employee",
    Icon: line,
    title: "Manage Employee",
    roles: ["Super Admin"],
  },
  {
    id: 2,
    link: "/dashboard/user",
    Icon: GrpUser,
    title: "Manage Customer",
    roles: ["Admin", "Super Admin"],
  },
  {
    id: 7,
    link: "/dashboard/booking",
    Icon: Booking,
    title: "Manage Booking",
    roles: ["Admin", "Super Admin"],
  },
  {
    id: 8,
    link: "/dashboard/refund",
    Icon: credit,
    title: "Manage Refund",
    roles: ["Admin", "Super Admin"],
  },
  // {
  //     id: 9,
  //     link: "/dashboard/fee",
  //     Icon: cash,
  //     title: "Manage Fee"
  // },
  {
    id: 10,
    link: "/dashboard/location",
    Icon: location,
    title: "Manage Location",
    roles: ["Super Admin"],
  },
  // {
  //     id: 11,
  //     link: "/dashboard/payout",
  //     Icon: pay,
  //     title: "Payout"
  // },
  // {
  //     id: 12,
  //     link: "/dashboard/report",
  //     Icon: report,
  //     title: "MIS Report"
  // },
  // {
  //     id: 13,
  //     link: "/dashboard/setting",
  //     Icon: Settings,
  //     title: "Settings"
  // },
  // {
  //     id: 14,
  //     link: "#",
  //     Icon: Logout,
  //     title: "Logout"
  // },
];

export const userTableHeader = [
  { key: "username", label: "Name", sortBy: false },
  { key: "email", label: "Location", sortBy: false },
  { key: "createdAt", label: "Gender", sortBy: false },
  { key: "email", label: "Email", sortBy: false },
  { key: "mobile", label: "Phone Number", sortBy: false },
  { key: "createdAt", label: "Date Joined", sortBy: false },
  { key: "createdAt", label: "Status", sortBy: false },
];

export const ownerTableHeader = [
  { key: "userId", label: "Owner Name", sortBy: false },
  { key: "username", label: "Owner Company", sortBy: false },
  { key: "email", label: "Phone Number", sortBy: false },
  { key: "email", label: "Email", sortBy: false },
  { key: "mobile", label: "Base Location", sortBy: false },
  { key: "createdAt", label: "No. of Trucks", sortBy: false },
  { key: "createdAt", label: "No. of Drivers", sortBy: false },
  { key: "createdAt", label: "Status", sortBy: false },
];

export const truckTableHeader = [
  { key: "userId", label: "Owner Name", sortBy: false },
  { key: "username", label: "Owner Company", sortBy: false },
  { key: "email", label: "Phone Number", sortBy: false },
  { key: "email", label: "Registration Number", sortBy: false },
  { key: "mobile", label: "Truck Model", sortBy: false },
  { key: "createdAt", label: "Truck Type", sortBy: false },
  { key: "createdAt", label: "Capacity", sortBy: false },
  { key: "createdAt", label: "Status", sortBy: false },
];

export const genderOptions = [
  { value: "Male", label: "Male" },
  { value: "Female", label: "Female" },
  { value: "Transgender", label: "Transgender" },
];

export const roleOptions = [
  { value: "Admin", label: "Admin" },
  { value: "Super Admin", label: "Super Admin" },
];

export const permissionOptions = [
  { value: "read", label: "Read" },
  { value: "write", label: "Write" },
];

export const statusOptions = [
  { value: 0, label: "InActive" },
  { value: 1, label: "Active" },
];

export const permitOptions = [
  { value: "National Permit", label: "National Permit" },
  { value: "State Permit", label: "State Permit" },
  { value: "Container Permit", label: "Container Permit" },
];

export const IDoptions = [
  { value: 1, label: "Aadhar Card" },
  { value: 2, label: "Pan Card" },
  { value: 3, label: "Driving License" },
  { value: 4, label: "Voter Id" },
];

export const IDProofOptions = [
  { value: 1, label: "Aadhar Card" },
  { value: 2, label: "Pan Card" },
  { value: 4, label: "Voter Id" },
];

export const IDProofValue = [
  "",
  "Aadhar Card",
  "Pan Card",
  "Driving License",
  "Voter Id",
];
export const numberOptions = [
  { value: 1, label: "1" },
  { value: 2, label: "2" },
  { value: 3, label: "3" },
  { value: 4, label: "4" },
  { value: 5, label: "5" },
  { value: 6, label: "6" },
  { value: 7, label: "7" },
  { value: 8, label: "8" },
  { value: 9, label: "9" },
  { value: 10, label: "10" },
  { value: 11, label: "11" },
  { value: 12, label: "12" },
  { value: 13, label: "13" },
  { value: 14, label: "14" },
  { value: 15, label: "15" },
  { value: 16, label: "16" },
  { value: 17, label: "17" },
  { value: 18, label: "18" },
  { value: 19, label: "19" },
  { value: 20, label: "20" },
];
export const driverTableHeader = [
  { key: "username", label: "Driver Name", sortBy: false },
  { key: "email", label: "Phone Number", sortBy: false },
  { key: "createdAt", label: "License No", sortBy: false },
  { key: "email", label: "License Expiry", sortBy: false },
  { key: "mobile", label: "Location", sortBy: false },
  { key: "createdAt", label: "Owner Name", sortBy: false },
  { key: "createdAt", label: "Company Name", sortBy: false },
  { key: "createdAt", label: "Status", sortBy: false },
];

export const ownerHeader = [
  { key: "email", label: "Registration Number", sortBy: false },
  { key: "mobile", label: "Truck Model", sortBy: false },
  { key: "createdAt", label: "Truck Type", sortBy: false },
  { key: "createdAt", label: "Capacity", sortBy: false },
  { key: "createdAt", label: "Status", sortBy: false },
];

export const driverHeader = [
  { key: "email", label: "Driver Name", sortBy: false },
  { key: "mobile", label: "Mobile No.", sortBy: false },
  { key: "createdAt", label: "Email", sortBy: false },
  { key: "createdAt", label: "Status", sortBy: false },
];

export const employeeTableHeader = [
  { key: "username", label: "Employee Name", sortBy: false },
  { key: "phone", label: "Phone Number", sortBy: false },
  { key: "email", label: "Email Id", sortBy: false },
  { key: "email", label: "Role", sortBy: false },
  { key: "location", label: "Location", sortBy: false },
  { key: "createdAt", label: "Status", sortBy: false },
];

export const bookingOwnerHeader = [
  { key: "userId", label: "Owner Name", sortBy: false },
  { key: "username", label: "Owner Company", sortBy: false },
  { key: "email", label: "Phone Number", sortBy: false },
  { key: "email", label: "Email", sortBy: false },
  { key: "createdAt", label: "Status", sortBy: false },
  { key: "createdAt", label: "", sortBy: false },
];
export const bookingRequestHeader = [
  { key: "username", label: "Username", sortBy: false },
  { key: "email", label: "From", sortBy: false },
  { key: "createdAt", label: "To", sortBy: false },
  { key: "email", label: "Pickup Date", sortBy: false },
  { key: "mobile", label: "Vehicle Load Type", sortBy: false },
  { key: "createdAt", label: "Order Date", sortBy: false },
  { key: "createdAt", label: "Amount", sortBy: false },
  { key: "createdAt", label: "Status", sortBy: false },
];

export const bookingApprovedHeader = [
  // { key: "userId", label: "S.No", sortBy: false },
  { key: "username", label: "Username", sortBy: false },
  { key: "email", label: "Order Id", sortBy: false },
  { key: "createdAt", label: "From", sortBy: false },
  { key: "createdAt", label: "To", sortBy: false },
  { key: "email", label: "Pickup Date", sortBy: false },
  { key: "mobile", label: "Vehicle Load Type", sortBy: false },
  { key: "createdAt", label: "Order Date", sortBy: false },
  { key: "createdAt", label: "Payment", sortBy: false },
  { key: "createdAt", label: "Amount", sortBy: false },
  { key: "createdAt", label: "Status", sortBy: false },
];

export const refundTableHeader = [
  { key: "email", label: "Order Id", sortBy: false },
  { key: "userId", label: "User Name", sortBy: false },
  { key: "username", label: "Credit Date", sortBy: false },
  { key: "email", label: "Cancelled Date", sortBy: false },
  { key: "mobile", label: "Credit Amount", sortBy: false },
  { key: "createdAt", label: "Status", sortBy: false },
];
export const bookingleadHeader = [
  // { key: "userId", label: "S.No", sortBy: false },
  { key: "username", label: "Username", sortBy: false },
  { key: "createdAt", label: "From", sortBy: false },
  { key: "createdAt", label: "To", sortBy: false },
  { key: "email", label: "Pickup Date", sortBy: false },
  { key: "mobile", label: "Vehicle Load Type", sortBy: false },
  { key: "createdAt", label: "Time Stamp", sortBy: false },
  { key: "createdAt", label: "Status", sortBy: false },
];

export const refundDetailsHeader = [
  { key: "userId", label: "Refund ID", sortBy: false },
  { key: "username", label: "Total Amount", sortBy: false },
  { key: "email", label: "Advance Amount", sortBy: false },
  { key: "createdAt", label: "Refund Amount", sortBy: false },
  { key: "email", label: "Date of Cancellation", sortBy: false },
  { key: "mobile", label: "Payment Method", sortBy: false },
  { key: "createdAt", label: "Refund Status", sortBy: false },
  { key: "createdAt", label: "Cancelled By", sortBy: false },
  { key: "createdAt", label: "Reason for Cancellation", sortBy: false },
];

export const orderDetailsHeader = [
  { key: "userId", label: "Pickup Address", sortBy: false },
  { key: "username", label: "Drop Address", sortBy: false },
  { key: "email", label: "Pickup Date", sortBy: false },
  { key: "createdAt", label: " Vehicle Capacity", sortBy: false },
  { key: "email", label: "Vehicle Load Type", sortBy: false },
  { key: "mobile", label: "Vehicle Type", sortBy: false },
];

export const ownerRefundHeader = [
  { key: "userId", label: "Owner Name", sortBy: false },
  { key: "username", label: "Owner Mobile", sortBy: false },
  { key: "email", label: "Owner Email", sortBy: false },
];
export const driverRefundHeader = [
  { key: "userId", label: "Driver Name", sortBy: false },
  { key: "username", label: "Driver Mobile", sortBy: false },
  { key: "email", label: "Driver Email", sortBy: false },
];

export const StateTableHeader = [
  { key: "username", label: "State Name", sortBy: false },
  { key: "phone", label: "General Location", sortBy: false },
  { key: "email", label: "Service Location", sortBy: false },
];

export const truckRefundHeader = [
  { key: "userId", label: "Vehicle Load Type", sortBy: false },
  { key: "username", label: "Vehicle Type", sortBy: false },
  { key: "email", label: "Registration No.", sortBy: false },
];

export const CityTableHeader = [
  { key: "username", label: "City Name", sortBy: false },
  { key: "phone", label: "General Location", sortBy: false },
  { key: "email", label: "Service Location", sortBy: false },
];

export const PAYMENT_STATUS = [
  "Not Paid",
  "Advance paid",
  "Fully paid",
  "Refunded",
  "Not Initiated",
  "Initiated",
  "Completed",
];

export const ORDER_STATUS = [
  "Pending",
  "Approved",
  "Ongoing",
  "Cancelled",
  "Completed",
  "",
  "",
  "",
  "Yet to Confirm",
  "",
  "Inprogress",
];
export const REFUND_STATUS = ["Not Initiated", "Initiated", "Completed"];

export const getColorClass = (status) => {
  switch (status) {
    case 0:
      return "bg-yellow";
    case 1:
      return "bg-dark-grey";
    case 2:
      return "bg-yellow";
    case 3:
      return "bg-red-500";
    case 4:
      return "bg-green";
    default:
      return "bg-gray";
  }
};

export const getRefundColor = (refundStatus) => {
  switch (refundStatus) {
    case 0:
      return "bg-yellow";
    case 1:
      return "bg-dark-grey";
    case 2:
      return "bg-green";
    default:
      return "bg-gray";
  }
};

export const localVariables = {
  userCredentials: "jowrwuraaa",
};

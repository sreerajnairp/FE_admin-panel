import * as yup from "yup";
const stringValidate = yup.string();
const numberValidate = yup.number();
const FileValidate = yup.mixed();
const arrayValidate = yup.array();
const phoneRegExp = /^[6789]\d{9}$/;
const alphabeticRegExp = /^[a-zA-Z\s]+$/;
const LicenseNoRegExp = /^[A-Z]{2}-\d{2}-\d{4}-\d{7}$/;
const GSTRegExp = /^\d{2}[A-Z]{5}\d{4}[A-Z][1-9A-Z]Z[0-9A-Z]$/;
export const userSchema = yup.object({
  username: stringValidate
    .required("Name is required")
    .matches(alphabeticRegExp, "Name must contain only alphabetic characters"),
  email: stringValidate
    .nullable(true)
    .email("Must be a valid emailId")
    .test("valid-email", "Must be a valid mail", (value) => {
      if (!value) return true;
      return /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(value);
    }),
  mobile: stringValidate
    .required("Phone Number is required")
    .matches(/^[6789]\d{9}$/, "Please enter valid phone number")
    .min(10, "Mobile Number should be minimum of 10 numbers")
    .max(10, "Mobile Number should be maximum of 10 numbers"),
  alternatePhone: stringValidate
    .nullable(true)
    .test(
      "valid-phone",
      "Enter a valid Phone Number",
      function (value, context) {
        if (!value || value.trim() === "") {
          return true;
        }
        return phoneRegExp.test(value);
      }
    ),
  gender: stringValidate
    .required("Gender is required")
    .transform(
      (originalValue, originalObject) => originalObject?.value || originalObject
    ),
  profilePicture: FileValidate.nullable(true),
  streetName: stringValidate.nullable(true),
  city: numberValidate
    .required("City / Town is required")
    .transform(
      (originalValue, originalObject) => originalObject?.value || originalObject
    ),
  country: stringValidate
    .required("Country is required")
    .transform(
      (originalValue, originalObject) => originalObject?.value || originalObject
    ),
  state: numberValidate
    .required("State is required")
    .transform(
      (originalValue, originalObject) => originalObject?.value || originalObject
    ),
  zipCode: stringValidate
    .required("Zip Code is required")
    .matches(/^$|^(?!0+$)\d{6}$/, "Please Enter Valid Code")
    .min(6, "Must be at least 6 Characters")
    .max(6, "Must be less than 6 Characters")
    .test("not-zero", "Invalid Zip Code", (value) => value !== "000000"),
});

export const ownerSchema = yup.object({
  fName: stringValidate
    .required("First Name is required")
    .matches(
      alphabeticRegExp,
      "First Name must contain only alphabetic characters"
    ),
  lName: stringValidate
    .required("Last Name is required")
    .matches(
      alphabeticRegExp,
      "Last Name must contain only alphabetic characters"
    ),
  mobile: stringValidate
    .required("Phone Number is required")
    .matches(/^[6789]\d{9}$/, "Please enter valid phone number")
    .min(10, "Mobile Number should be minimum of 10 numbers")
    .max(10, "Mobile Number should be maximum of 10 numbers"),
  alternatePhone: stringValidate
    .nullable(true)
    .test(
      "valid-phone",
      "Enter a valid Phone Number",
      function (value, context) {
        if (!value || value.trim() === "") {
          return true;
        }
        return phoneRegExp.test(value);
      }
    ),
  email: stringValidate
    .nullable(true)
    .test("valid-email", "Must be a valid mail", (value) => {
      if (!value) return true;
      return /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(value);
    }),
  companyName: stringValidate
    .required("Company Name is required")
    .matches(/^[a-zA-Z0-9 ]+$/, "Special characters are not allowed"),
  baseLocation: numberValidate
    .required("Base Location is required")
    .transform(
      (originalValue, originalObject) => originalObject?.value || originalObject
    ),
  serviceableLocation: arrayValidate
    .required("Service Location is required")
    .min(1, "At least one Service Location is required"),
  // noOfTruck: numberValidate
  //   .required("No. of trucks is required")
  //   .transform(
  //     (originalValue, originalObject) => originalObject?.value || originalObject
  //   ),
  pricePerTon: arrayValidate.required("pricePerTon is required"),
  pricePerKm: arrayValidate.required("pricePerTon is required"),
  gstNo: stringValidate
    .required("GST is required")
    // .test(
    //   "no-special-characters",
    //   "Special characters are not allowed",
    //   (value) => {
    //     if (!value) return true;
    //     return /^[a-zA-Z0-9]+$/.test(value);
    //   }
    // ),
    .matches(GSTRegExp, "Invalid GST number")
    .transform((value) => value.toUpperCase()),
  idProofType: numberValidate
    .required("Id Proof is required")
    .transform(
      (originalValue, originalObject) => originalObject?.value || originalObject
    ),
  document: FileValidate.required("Document is required"),
  profilePicture: FileValidate.nullable(true),
  // noOfDriver: numberValidate
  //   .required("No. Of Drivers is required")
  //   .transform(
  //     (originalValue, originalObject) => originalObject?.value || originalObject
  //   ),
  streetName: stringValidate,
  city: numberValidate
    .required("Owner City / Town is required")
    .transform(
      (originalValue, originalObject) => originalObject?.value || originalObject
    ),
  zipCode: stringValidate
    .matches(/^$|^(?!0+$)\d{6}$/, "Please Enter Valid Code")
    .max(6, "Must be 6 Characters")
    .nullable(true),
  companyAddress: stringValidate,
  companyCity: numberValidate
    .required("Company City is required")
    .transform(
      (originalValue, originalObject) => originalObject?.value || originalObject
    ),
  companyZipcode: stringValidate
    .matches(/^$|^(?!0+$)\d{6}$/, "Please Enter Valid Code")
    .max(6, "Must be 6 Characters")
    .nullable(true),
  country: stringValidate
    .required("Country is required")
    .transform(
      (originalValue, originalObject) => originalObject?.value || originalObject
    ),
  ownerState: numberValidate
    .required("Owner State is required")
    .transform(
      (originalValue, originalObject) => originalObject?.value || originalObject
    ),
  companyCountry: stringValidate
    .required("Company Country is required")
    .transform(
      (originalValue, originalObject) => originalObject?.value || originalObject
    ),
  companyState: numberValidate
    .required("Company State is required")
    .transform(
      (originalValue, originalObject) => originalObject?.value || originalObject
    ),
  status: numberValidate.transform((value, originalObject) => {
    if (
      originalObject &&
      typeof originalObject === "object" &&
      "value" in originalObject
    ) {
      return Number(originalObject.value);
    }
    return value;
  }),
});

export const truckSchema = yup.object({
  ownerId: stringValidate
    .required("Owner Name is required")
    .transform(
      (originalValue, originalObject) => originalObject?.value || originalObject
    ),
  registrationNumber: stringValidate
    .required("Registration Number is required")
    .matches(
      /^[A-Za-z]{2}\s\d{2}\s[A-Za-z]{2}\s\d{4}$/,
      "For Eg: TN 00 AA 0000"
    )
    .transform((value) => value.toUpperCase()),
  dateOfRegistration: stringValidate.nullable(true),
  registrationValidity: stringValidate.nullable(true),
  engineNo: stringValidate
    .test(
      "no-special-characters",
      "Special characters are not allowed",
      (value) => {
        if (!value) return true;
        return /^[a-zA-Z0-9]+$/.test(value);
      }
    )
    .transform((value) => value.toUpperCase()),
  fuel: stringValidate.transform(
    (originalValue, originalObject) => originalObject?.value || originalObject
  ),
  color: stringValidate,
  insuranceValidity: stringValidate
    .nullable(true)
    .required("Insurance Validity is required"),
  permit: stringValidate
    .required("Permit is required")
    .typeError("Permit is required")
    .transform(
      (originalValue, originalObject) => originalObject?.value || originalObject
    ),
  truckPermit: arrayValidate
    .nullable(true)
    .test({
      test: function (value) {
        const permitValue = this.parent.permit;
        if (permitValue === "State Permit") {
          return value?.length > 0;
        }
        return true;
      },
      message: "At least one State Permit is required",
    })
    .transform(
      (originalValue, originalObject) => originalObject?.value || originalObject
    ),
  permitDocument: FileValidate.nullable(true),
  vehicleTypeId: stringValidate
    .required("Vehicle Type is required")
    .transform(
      (originalValue, originalObject) => originalObject?.value || originalObject
    ),
  vehicleAxleId: stringValidate
    .nullable(true)
    .transform(
      (originalValue, originalObject) => originalObject?.value || originalObject
    ),
  vehicleLoadTypeId: arrayValidate
    .required("Vehicle Load Type is required")
    .min(1, "At least one Vehicle Load Type is required")
    .transform(
      (originalValue, originalObject) => originalObject?.value || originalObject
    ),
  // vehicleCapacity: numberValidate
  //   .required("Vehicle Capacity is required")
  //   .typeError("Vehicle Capacity is required")
  //   .moreThan(0, "Zero or Negative value is not accepted")
  //   .test("validDigits", "Value should not exceed three digits", (value) => {
  //     if (typeof value !== "number") return false;
  //     const valueStr = value.toString();
  //     return (
  //       valueStr.length === 1 || valueStr.length === 2 || valueStr.length === 3
  //     );
  //   })
  //   .test(
  //     "noEOrSign",
  //     "Number should not contain 'e' or any sign.",
  //     (value) => typeof value === "number" && !/[eE+-]/.test(value.toString())
  //   ),
  vehicleCapacity: numberValidate
    .required("Vehicle Capacity is required")
    .typeError("Vehicle Capacity must be a number")
    .moreThan(0, "Vehicle Capacity must be a positive number")
    .integer("Vehicle Capacity must be an integer")
    .max(999, "Vehicle Capacity cannot exceed three digits")
    .test(
      "noEOrSign",
      "Vehicle Capacity should not contain 'e' or any sign.",
      (value) =>
        typeof value === "number" && !/\b\d+e\d+\b/i.test(value.toString())
    ),
  vehicleSizeId: stringValidate.transform(
    (originalValue, originalObject) => originalObject?.value || originalObject
  ),
  vehicleModelId: stringValidate
    .required("Vehicle Model is required")
    .transform(
      (originalValue, originalObject) => originalObject?.value || originalObject
    ),
  vehicleTyre: numberValidate
    .nullable(true)
    .transform((value) => (Number.isNaN(value) ? null : value))
    .test({
      name: "isNumber",
      message:
        "Vehicle Tyre should be minimum of 4 numbers and maximum of 26 numbers",
      test: (value) => {
        if (
          value === null ||
          value === undefined ||
          value === "" ||
          Number.isNaN(value)
        ) {
          return true;
        }
        return (
          !isNaN(value) &&
          Number.isInteger(value) &&
          value >= 4 &&
          value <= 26 &&
          !/\b\d+e\d+\b/i.test(value.toString())
        );
      },
    }),
  vehicleInsurance: FileValidate.nullable(true),
  vehicleRegistration: FileValidate.nullable(true),
  status: numberValidate.transform((value, originalObject) => {
    if (
      originalObject &&
      typeof originalObject === "object" &&
      "value" in originalObject
    ) {
      return Number(originalObject.value);
    }
    return value;
  }),
});

export const driverSchema = yup.object({
  fName: stringValidate
    .required("First Name is required")
    .matches(
      alphabeticRegExp,
      "First Name must contain only alphabetic characters"
    ),
  lName: stringValidate
    .required("Last Name is required")
    .matches(
      alphabeticRegExp,
      "Last Name must contain only alphabetic characters"
    ),
  mobile: stringValidate
    .required("Phone Number is required")
    .matches(/^[6789]\d{9}$/, "Please enter valid phone number")
    .min(10, "Mobile Number should be minimum of 10 numbers")
    .max(10, "Mobile Number should be maximum of 10 numbers"),
  alternatePhone: stringValidate
    // .matches(/^[6789]\d{9,9}$/, "Please enter valid phone number")
    // .min(10, "Mobile Number should be minimum of 10 numbers")
    // .max(10, "Mobile Number should be maximum of 10 numbers")
    .nullable(true)
    .test(
      "valid-phone",
      "Enter a valid Phone Number",
      function (value, context) {
        if (!value || value.trim() === "") {
          return true;
        }
        return phoneRegExp.test(value);
      }
    ),
  // .matches(phoneRegExp, "Mobile is required"),
  email: stringValidate
    .nullable(true)
    .test("valid-email", "Must be a valid mail", (value) => {
      if (!value) return true;
      return /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(value);
    }),
  idProofType: numberValidate
    .required("Id Proof Type is required")
    .transform(
      (originalValue, originalObject) => originalObject?.value || originalObject
    ),
  document: FileValidate.required("Document is required"),
  profilePicture: FileValidate.required("Profile Picture is required"),
  licenseNumber: stringValidate
    .required("License Number is required")
    .matches(LicenseNoRegExp, "For Eg: AA-11-1234-1234567")
    .transform((value) => value.toUpperCase()),
  licenseExpiry: stringValidate.required("License Expiry is required"),
  licensePhoto: FileValidate.required("License Photo is required"),
  vehicleInsurance: stringValidate.nullable(true),
  vehicleRegistration: stringValidate.nullable(true),
  experience: numberValidate
    .required("Experience is required")
    .typeError("Experience is required")
    .moreThan(0, "Zero or Negative value is not accepted")
    .max(99, "Experience cannot exceed two digits")
    .test(
      "noEOrSign",
      "Number had an 'e' or sign.",
      (value) => typeof value === "number" && !/[eE+-]/.test(value.toString())
    ),
  ownerId: stringValidate
    .required("Owner Name is required")
    .transform(
      (originalValue, originalObject) => originalObject?.value || originalObject
    ),
  streetName: stringValidate.nullable(true),
  country: stringValidate
    .required("Country is required")
    .transform(
      (originalValue, originalObject) => originalObject?.value || originalObject
    ),
  city: numberValidate
    .required("City / Town is required")
    .transform(
      (originalValue, originalObject) => originalObject?.value || originalObject
    ),
  zipCode: stringValidate
    .matches(/^$|^(?!0+$)\d{6}$/, "Please Enter Valid Code")
    .max(6, "Must be 6 Characters")
    .nullable(true),
  state: numberValidate
    .required("State is required")
    .transform(
      (originalValue, originalObject) => originalObject?.value || originalObject
    ),
  status: numberValidate.transform((value, originalObject) => {
    if (
      originalObject &&
      typeof originalObject === "object" &&
      "value" in originalObject
    ) {
      return Number(originalObject.value);
    }
    return value;
  }),
});

export const employeeSchema = yup.object({
  username: stringValidate
    .required("Name is required")
    .matches(alphabeticRegExp, "Name must contain only alphabetic characters"),
  email: stringValidate
    .nullable()
    .email("Must be a valid emailId")
    .required("Email Id is required")
    .matches(
      /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
      "Must be a valid email"
    ),
  mobile: stringValidate
    .required("Phone Number is required")
    .matches(/^[6789]\d{9}$/, "Please enter valid phone number")
    .min(10, "Mobile Number should be minimum of 10 numbers")
    .max(10, "Mobile Number should be maximum of 10 numbers"),
  gender: stringValidate
    .required("Gender is required")
    .transform(
      (originalValue, originalObject) => originalObject?.value || originalObject
    ),
  profilePic: FileValidate.nullable(true),
  role: stringValidate
    .required("Role is required")
    .transform(
      (originalValue, originalObject) => originalObject?.value || originalObject
    ),
  idProofType: arrayValidate
    .required("Id Proof is required")
    .min(1, "At least one Id Proof is required"),
  documents: arrayValidate.required("Document is required"),
  streetName: stringValidate,
  city: numberValidate
    .required("City / Town is required")
    .transform(
      (originalValue, originalObject) => originalObject?.value || originalObject
    ),
  country: stringValidate
    .required("Country is required")
    .transform(
      (originalValue, originalObject) => originalObject?.value || originalObject
    ),
  state: numberValidate
    .required("State is required")
    .transform(
      (originalValue, originalObject) => originalObject?.value || originalObject
    ),
  zipCode: stringValidate
    .matches(/^$|^(?!0+$)\d{6}$/, "Please Enter Valid Code")
    .max(6, "Must be 6 Characters")
    .nullable(true),
});

export const refundSchema = yup.object({
  cancelReason: stringValidate
    .required("Comments is required")
    .min(1, "Comments should not exceed 100 characters")
    .max(100, "Comments should not exceed 100 characters"),
  ownerId: stringValidate,
  paidAmount: stringValidate,
});

export const stateSchema = yup.object({
  state: stringValidate.required("State is required"),
});

export const citySchema = yup.object({
  stateId: numberValidate.required("State Id required"),
  city: stringValidate.required("City is required"),
});

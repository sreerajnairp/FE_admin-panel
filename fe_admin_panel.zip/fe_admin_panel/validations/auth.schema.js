import * as yup from "yup";
const stringValidate = yup.string();
export const EMAIL_REGX = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i;
const PASSWORD_REGX =
  /^(?=.*[a-z])(?=.*\d)(?=.*[@$!_#%*?&])[A-Za-z\d@_#$!%*?&]*$/;

const PHONE_REGX = /^(1\s?)?((\(\d{3}\))|\d{3})[\s-]?\d{3}[\s-]?\d{4}$/;

export const loginSchema = yup.object({
  email: yup
    .string()
    .required("Email is required")
    .email("Must be a valid Email")
    .matches(EMAIL_REGX, "Must be a valid Email")
    .max(255, "Email should be maximum 255 characters"),
  password: yup
    .string()
    .required("Password is required")
    .min(8, "Must be 8 Characters or more")
    .matches(
      /[a-z]+/,
      "At least one uppercase one lowercase one number and special character required"
    )
    .matches(
      /[A-Z]+/,
      "At least one uppercase one lowercase one number and special character required"
    )
    .matches(
      /[@$!%*#?&]+/,
      "At least one uppercase one lowercase one number and special character required"
    )
    .matches(
      /\d+/,
      "At least one uppercase one lowercase one number and special character required"
    ),
  rememberMe: yup.bool().default(true),
});

export const forgotSchema = yup.object({
  emailOrMobile: yup
    .string()
    .required("Email or Phone Number is required")
    .test(
      "is-email-or-phone",
      "Must be a valid Email or Phone Number",
      (value) =>
        yup
          .string()
          .matches(EMAIL_REGX, "Must be a valid Email")
          .isValidSync(value) ||
        yup
          .string()
          .matches(PHONE_REGX, "Must be valid Phone")
          .isValidSync(value)
    ),
});

export const resetSchema = yup.object({
  password: yup
    .string()
    .required("Password is required")
    .min(8, "Must be 8 Characters or more")
    .matches(
      /[a-z]+/,
      "At least one uppercase one lowercase one number and special character required"
    )
    .matches(
      /[A-Z]+/,
      "At least one uppercase one lowercase one number and special character required"
    )
    .matches(
      /[@$!%*#?&]+/,
      "At least one uppercase one lowercase one number and special character required"
    )
    .matches(
      /\d+/,
      "At least one uppercase one lowercase one number and special character required"
    ),
  confirmPassword: yup
    .string()
    .required("Confirm Password is required")
    .min(8, "confirmPassword should be minimum 8 characters")
    .max(15, "confirmPassword should be maximum 15 characters")
    .oneOf([yup.ref("password"), null], "Passwords must match"),
});
